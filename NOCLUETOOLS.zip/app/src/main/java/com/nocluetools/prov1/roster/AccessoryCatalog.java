package com.nocluetools.prov1.roster;

import com.nocluetools.prov1.roster.RosterEditor;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class AccessoryCatalog {
    public static final String CAT_SHOES = "SHOES";
    public static final String CAT_HEAD_TORSO = "HEAD / TORSO";
    public static final String CAT_ARMS = "ARMS / WRISTS / HANDS";
    public static final String CAT_LEGS = "LEGS / KNEES / ANKLES";
    public static final String CAT_COLORS = "COLORS / LOGOS";
    public static final String[] CATEGORIES = {CAT_SHOES, CAT_HEAD_TORSO, CAT_ARMS, CAT_LEGS, CAT_COLORS};
    private static final String[] SHOE_BRAND = {"Generic / No Brand", "Nike", "Adidas", "Jordan", "Converse", "Reebok", "Under Armour", "Spalding"};
    private static final String[] UNDERSHIRT = {"None", "Body Shirt", "Short-Sleeve Shirt", "Long-Sleeve Shirt"};
    private static final String[] ELBOW = {"None", "Elbow Pad", "Elbow Sleeve", "Small Elbow Band", "Elbow Band", "Large Elbow Band", "Elbow Brace", "Elbow Strap"};
    private static final String[] WRIST = {"None", "Forearm Band", "Wristband", "Protective Wristband", "Double Wristband", "Rubber Band", "Double Rubber Band", "I Promise Band", "Powerband", "Wrist Tape Wrap", "Hand Wrap", "Arm Sleeve 11", "Arm Sleeve 2", "Arm Sleeve 8", "Arm Sleeve 9", "Arm Sleeve 21"};
    private static final String[] ARM = {"None", "Arm Sleeve", "Arm Sleeve w/ Pad", "Short Sleeve", "Shoulder Sleeve", "Full Arm Sleeve", "Adidas Arm Sleeve"};
    private static final String[] LEG = {"None", "Leg Sleeve", "Calf Sleeve", "Full Padded Calf Sleeve", "Half Calf Sleeve", "Hex-Pad Half Calf Sleeve", "Jordan Calf Sleeve", "Mid Calf Sleeve"};
    private static final String[] FINGER = {"None", "Finger Strap", "Double Finger Strap", "Long Index Finger Strap", "Long Middle Finger Strap"};
    private static final String[] KNEE = {"None", "Knee Pad", "Hex Knee Pad", "Knee Brace", "Knee Sleeve", "Knee Strap"};
    private static final String[] ANKLE = {"None", "Ankle Brace", "Ankle Wrap"};
    private static final String[] SOCK = {"Ankle Socks", "Low Socks", "Double Low Socks", "Medium Socks", "Double Medium Socks", "Medium-Long Socks", "High Socks", "Striped Socks"};

    public static boolean usesChoice(RosterEditor.AccessoryField accessoryField) {
        return (accessoryField == null || "Shoe Model".equals(accessoryField.label)) ? false : true;
    }

    public static String categoryOf(RosterEditor.AccessoryField accessoryField) {
        if (accessoryField == null) {
            return CAT_COLORS;
        }
        String str = accessoryField.label;
        return (str.startsWith("Shoe") || str.contains("Shoe Trim")) ? CAT_SHOES : (str.contains("Color") || str.contains("Logo")) ? CAT_COLORS : (str.equals("Headband") || str.equals("Undershirt") || str.equals("Shorts")) ? CAT_HEAD_TORSO : (str.contains("Elbow") || str.contains("Wrist") || str.contains("Finger") || str.contains("Arm")) ? CAT_ARMS : CAT_LEGS;
    }

    public static String[] optionsFor(RosterEditor.AccessoryField accessoryField) {
        String string;
        if (accessoryField == null) {
            return new String[]{"0"};
        }
        int iMaxValue = accessoryField.maxValue();
        ArrayList arrayList = new ArrayList();
        String str = accessoryField.label;
        int i = 0;
        while (i <= iMaxValue) {
            if ("Headband".equals(str)) {
                string = i == 0 ? "Off (0)" : "On (1)";
            } else if ("Shorts".equals(str)) {
                string = i == 0 ? "Normal Shorts (0)" : "Short Shorts (1)";
            } else if ("Shoe Brand".equals(str)) {
                string = nativeName(SHOE_BRAND, i, "Brand Slot");
            } else if (str.contains("Shoe Trim")) {
                string = i == 0 ? "Default Trim (0)" : new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append("Trim Slot ").append(i).toString()).append(" (").toString()).append(i).toString()).append(")").toString();
            } else if (str.contains("Color")) {
                string = i == 0 ? "Default / Team (0)" : new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append("Color Slot ").append(i).toString()).append(" (").toString()).append(i).toString()).append(")").toString();
            } else if ("Headband Logo".equals(str)) {
                string = i == 0 ? "No Logo (0)" : new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append("Logo Slot ").append(i).toString()).append(" (").toString()).append(i).toString()).append(")").toString();
            } else if (str.endsWith("Elbow")) {
                string = nativeName(ELBOW, i, "Elbow Style");
            } else if (str.endsWith("Wrist")) {
                string = nativeName(WRIST, i, "Wrist Style");
            } else if (str.endsWith("Arm")) {
                string = nativeName(ARM, i, "Arm Style");
            } else if (str.endsWith("Leg")) {
                string = nativeName(LEG, i, "Leg Style");
            } else if (str.endsWith("Fingers")) {
                string = nativeName(FINGER, i, "Finger Style");
            } else if (str.endsWith("Knee")) {
                string = nativeName(KNEE, i, "Knee Style");
            } else if (str.endsWith("Ankle")) {
                string = nativeName(ANKLE, i, "Ankle Style");
            } else if ("Socks".equals(str)) {
                string = nativeName(SOCK, i, "Sock Style");
            } else if ("Undershirt".equals(str)) {
                string = nativeName(UNDERSHIRT, i, "Undershirt Style");
            } else {
                string = i == 0 ? "None (0)" : new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append("Style ").append(i).toString()).append(" (").toString()).append(i).toString()).append(")").toString();
            }
            arrayList.add(string);
            i++;
        }
        return (String[]) arrayList.toArray(new String[arrayList.size()]);
    }

    private static String nativeName(String[] strArr, int i, String str) {
        return (i < 0 || i >= strArr.length) ? new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(str).append(" ").toString()).append(i).toString()).append(" (").toString()).append(i).toString()).append(")").toString() : new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(strArr[i]).append(" (").toString()).append(i).toString()).append(")").toString();
    }

    public static String displayNameForValue(String str, int i) {
        int iIndexOf = indexOf(str);
        if (iIndexOf < 0) {
            return String.valueOf(i);
        }
        String[] strArrOptionsFor = optionsFor(RosterEditor.ACCESSORY_FIELDS[iIndexOf]);
        return (i < 0 || i >= strArrOptionsFor.length) ? new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(str).append(" ").toString()).append(i).toString()).append(" (").toString()).append(i).toString()).append(")").toString() : strArrOptionsFor[i];
    }

    public static int indexOf(String str) {
        if (str == null) {
            return -1;
        }
        for (int i = 0; i < RosterEditor.ACCESSORY_FIELDS.length; i++) {
            if (str.equals(RosterEditor.ACCESSORY_FIELDS[i].label)) {
                return i;
            }
        }
        return -1;
    }

    public static int mirrorIndex(int i) {
        if (i < 0 || i >= RosterEditor.ACCESSORY_FIELDS.length) {
            return -1;
        }
        String str = RosterEditor.ACCESSORY_FIELDS[i].label;
        String string = (String) null;
        if (str.startsWith("Left ")) {
            string = new StringBuffer().append("Right ").append(str.substring(5)).toString();
        } else if (str.startsWith("Right ")) {
            string = new StringBuffer().append("Left ").append(str.substring(6)).toString();
        }
        if (string == null) {
            return -1;
        }
        return indexOf(string);
    }

    public static boolean isWearableStyle(int i) {
        if (i < 0 || i >= RosterEditor.ACCESSORY_FIELDS.length) {
            return false;
        }
        String str = RosterEditor.ACCESSORY_FIELDS[i].label;
        return (str.startsWith("Shoe") || str.contains("Color") || str.contains("Logo")) ? false : true;
    }

    public static int[] cleanPreset(int[] iArr) {
        int[] iArr2 = iArr == null ? new int[RosterEditor.ACCESSORY_FIELDS.length] : (int[]) iArr.clone();
        for (int i = 0; i < iArr2.length; i++) {
            if (isWearableStyle(i)) {
                iArr2[i] = 0;
            }
        }
        return iArr2;
    }

    AccessoryCatalog() {
    }
}
