package com.nocluetools.prov1.roster;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes.dex */
public final class OnlineRatingsClient {
    private static final String BASE = "https://www.2kratings.com/";
    private static final int CONNECT_TIMEOUT_MS = 12000;
    public static final String GAME_VERSION = "NBA 2K27";
    private static final int MAX_HTML_CHARS = 2500000;
    public static final String PROVIDER_NAME = "2KRatings.com + 2kAuction • NBA 2K27";
    public static final String PROVIDER_NOTE = "Ratings + direct-safe tendencies • independent fan sources";
    private static final int READ_TIMEOUT_MS = 18000;
    private static final String TENDENCY_BASE = "https://2kauction.com/mynba/2k27/players/";
    private static final String[][] MAP = {new String[]{"Close Shot", "Close Shot"}, new String[]{"Mid-Range Shot", "Mid-Range Shot"}, new String[]{"Ball Handle", "Ball Handle"}, new String[]{"Three-Point Shot", "Three-Point Shot"}, new String[]{"Free Throw", "Free Throw"}, new String[]{"Layup", "Layup"}, new String[]{"Driving Dunk", "Dunk"}, new String[]{"Standing Dunk", "Standing Dunk"}, new String[]{"Hustle", "Hustle"}, new String[]{"Pass Accuracy", "Passing"}, new String[]{"Interior Defense", "Low Post Defense"}, new String[]{"Post Control", "Low Post Offense"}, new String[]{"Block", "Block"}, new String[]{"Hands", "Hands"}, new String[]{"Steal", "Steal"}, new String[]{"Speed", "Speed"}, new String[]{"Stamina", "Stamina"}, new String[]{"Vertical", "Vertical"}, new String[]{"Offensive Rebound", "Offensive Rebound"}, new String[]{"Defensive Rebound", "Defensive Rebound"}, new String[]{"Overall Durability", "Durability"}, new String[]{"Offensive Consistency", "Consistency"}, new String[]{"Perimeter Defense", "On Ball Defense"}, new String[]{"Agility", "Quickness"}, new String[]{"Strength", "Strength"}, new String[]{"Post Fade", "Post Fadeaway"}, new String[]{"Post Hook", "Post Hook"}};
    private static final String[][] TENDENCY_MAP = {new String[]{"Shot", "Shot"}, new String[]{"Shot Close", "Shot Close"}, new String[]{"shot midrange t", "Shot Medium"}, new String[]{"shot three t", "Shot Three"}, new String[]{"Drive", "Drive"}, new String[]{"Drive Right", "Drive Right"}, new String[]{"TT Pump Fake", "Triple Threat Pump Fake"}, new String[]{"TT Jab Step", "Triple Threat Jab Step"}, new String[]{"triple threat nothing t", "Triple Threat Nothing"}, new String[]{"TT Shoot", "Triple Threat Shoot"}, new String[]{"setup sizeup t", "Setup Sizeup"}, new String[]{"setup hesitation t", "Setup Hesitation"}, new String[]{"setup nothing t", "Setup Nothing"}, new String[]{"dribble crossover t", "Dribble Crossover"}, new String[]{"dribble spin t", "Dribble Spin"}, new String[]{"dribble step back t", "Dribble Step Back"}, new String[]{"dribble half spin t", "Dribble Half Spin"}, new String[]{"dribble double cross t", "Dribble Double Cross"}, new String[]{"dribble behind back t", "Dribble Behind Back"}, new String[]{"dribble hesitation t", "Dribble Hesitation"}, new String[]{"dribble in and out t", "Dribble In And Out"}, new String[]{"dribble nothing t", "Dribble Nothing"}, new String[]{"finish attack t", "Finish Attack"}, new String[]{"Crash", "Crash"}, new String[]{"touch t", "Touch"}, new String[]{"Post Up", "Post Up"}, new String[]{"roll vs fade t", "Roll Vs Fade"}, new String[]{"Post Spin", "Post Spin"}, new String[]{"Post Shimmy Shot", "Post Shimmy Shot"}, new String[]{"Post Face Up", "Post Face Up"}, new String[]{"Post Back Down", "Post Back Down"}, new String[]{"post aggressive back down t", "Post Aggressive Back Down"}, new String[]{"post shoot t", "Post Shoot"}, new String[]{"Post Drive", "Post Drive"}, new String[]{"Post Hop Shot", "Post Hop Shot"}, new String[]{"Putback", "Putback"}, new String[]{"Flashy Pass", "Flashy Pass"}, new String[]{"Alley-Oop", "Alley Oop"}, new String[]{"interception t", "Interception"}, new String[]{"Take Charge", "Take Charge"}, new String[]{"On-Ball Steal", "On Ball Steal"}, new String[]{"Contest Shot", "Contest Shot"}, new String[]{"Foul", "Foul"}, new String[]{"Hard Foul", "Hard Foul"}, new String[]{"Use Glass", "Use Glass"}, new String[]{"Spin Jumper", "Spin Jumper"}, new String[]{"Alley-Oop Pass", "Alley Oop Pass"}};
    private static final Object[][] LEGACY_BADGE_MAP = {new Object[]{"Posterizer", 1}, new Object[]{"Acrobat", 4}, new Object[]{"Deadeye", 7}, new Object[]{"Corner Specialist", 8}, new Object[]{"Dimer", 12}, new Object[]{"Break Starter", 13}, new Object[]{"Brick Wall", 15}, new Object[]{"Interceptor", 18}, new Object[]{"Bruiser", 23}};

    public static final class RatingSnapshot {
        public String enrichmentWarning;
        public String requestedName;
        public String resolvedName;
        public String sourceUrl;
        public String tendencySourceUrl;
        public int overall = -1;
        public final LinkedHashMap<String, Integer> localRatings = new LinkedHashMap<>();
        public final LinkedHashMap<String, Integer> sourceRatings = new LinkedHashMap<>();
        public final LinkedHashMap<String, Integer> localTendencies = new LinkedHashMap<>();
        public final ArrayList<Integer> compatibleLegacyBadgeIds = new ArrayList<>();
        public final ArrayList<String> compatibleLegacyBadgeNames = new ArrayList<>();

        public int mappedCount() {
            return this.localRatings.size();
        }

        public int tendencyMappedCount() {
            return this.localTendencies.size();
        }

        public int compatibleBadgeCount() {
            return this.compatibleLegacyBadgeIds.size();
        }
    }

    public static RatingSnapshot fetch(String str) throws IOException {
        if (str == null || str.trim().length() == 0) {
            throw new IOException("Player name is empty.");
        }
        String strSlugify = slugify(str);
        if (strSlugify.length() == 0) {
            throw new IOException("Could not build player URL.");
        }
        String string = new StringBuffer().append(BASE).append(strSlugify).toString();
        RatingSnapshot html = parseHtml(str, string, download(string));
        if (html.mappedCount() < 3) {
            throw new IOException("Online page found, but not enough rating fields were recognized.");
        }
        try {
            enrichFrom2kAuction(html, str);
        } catch (Exception e) {
            html.enrichmentWarning = e.getMessage() == null ? "Tendency/badge enrichment unavailable." : e.getMessage();
        }
        return html;
    }

    static RatingSnapshot parseHtml(String str, String str2, String str3) throws IOException {
        if (str3 == null || str3.length() == 0) {
            throw new IOException("Empty online response.");
        }
        String strHtmlToText = htmlToText(str3);
        RatingSnapshot ratingSnapshot = new RatingSnapshot();
        ratingSnapshot.requestedName = str;
        ratingSnapshot.sourceUrl = str2;
        ratingSnapshot.resolvedName = extractHeading(str3, str);
        ratingSnapshot.overall = extractOverall(strHtmlToText);
        for (int i = 0; i < MAP.length; i++) {
            String str4 = MAP[i][0];
            String str5 = MAP[i][1];
            int iExtractRating = extractRating(strHtmlToText, str4);
            if (iExtractRating >= 25 && iExtractRating <= 99) {
                if (!ratingSnapshot.sourceRatings.containsKey(str4)) {
                    ratingSnapshot.sourceRatings.put(str4, Integer.valueOf(iExtractRating));
                }
                if (!ratingSnapshot.localRatings.containsKey(str5)) {
                    ratingSnapshot.localRatings.put(str5, Integer.valueOf(iExtractRating));
                }
            }
        }
        return ratingSnapshot;
    }

    static void enrichFrom2kAuction(RatingSnapshot ratingSnapshot, String str) throws IOException {
        String strSlugify = slugify(str);
        if (strSlugify.length() == 0) {
            throw new IOException("Could not build tendency URL.");
        }
        String string = new StringBuffer().append(TENDENCY_BASE).append(strSlugify).toString();
        parse2kAuctionHtml(ratingSnapshot, string, download(string));
    }

    static void parse2kAuctionHtml(RatingSnapshot ratingSnapshot, String str, String str2) throws IOException {
        String strHtmlToText = htmlToText(str2);
        if (strHtmlToText.length() == 0) {
            throw new IOException("Empty tendency response.");
        }
        String strExtractTendencySection = extractTendencySection(strHtmlToText);
        if (strExtractTendencySection.length() == 0) {
            throw new IOException("Current-player tendency section was not recognized.");
        }
        for (int i = 0; i < TENDENCY_MAP.length; i++) {
            String str3 = TENDENCY_MAP[i][0];
            String str4 = TENDENCY_MAP[i][1];
            int iExtractRangeValue = extractRangeValue(strExtractTendencySection, str3, 0, 100);
            if (iExtractRangeValue >= 0 && !ratingSnapshot.localTendencies.containsKey(str4)) {
                ratingSnapshot.localTendencies.put(str4, Integer.valueOf(iExtractRangeValue));
            }
        }
        String strExtractBadgeSection = extractBadgeSection(strHtmlToText);
        if (strExtractBadgeSection.length() > 0) {
            for (int i2 = 0; i2 < LEGACY_BADGE_MAP.length; i2++) {
                String str5 = (String) LEGACY_BADGE_MAP[i2][0];
                int iIntValue = ((Integer) LEGACY_BADGE_MAP[i2][1]).intValue();
                if (containsPhrase(strExtractBadgeSection, str5)) {
                    ratingSnapshot.compatibleLegacyBadgeIds.add(Integer.valueOf(iIntValue));
                    ratingSnapshot.compatibleLegacyBadgeNames.add(str5);
                }
            }
        }
        ratingSnapshot.tendencySourceUrl = str;
    }

    static String extractTendencySection(String str) {
        int i;
        int iIndexOfIgnoreCase = indexOfIgnoreCase(str, "Hot Zones", 0);
        int iIndexOfIgnoreCase2 = indexOfIgnoreCase(str, "Badges", iIndexOfIgnoreCase >= 0 ? iIndexOfIgnoreCase : 0);
        if (iIndexOfIgnoreCase2 >= 0) {
            i = iIndexOfIgnoreCase2;
        } else {
            i = iIndexOfIgnoreCase >= 0 ? iIndexOfIgnoreCase : 0;
        }
        int iIndexOfLine = indexOfLine(str, "Shot", i);
        if (iIndexOfLine < 0) {
            return "";
        }
        int iIndexOfIgnoreCase3 = indexOfIgnoreCase(str, "Release Timing", iIndexOfLine);
        if (iIndexOfIgnoreCase3 < 0) {
            iIndexOfIgnoreCase3 = indexOfIgnoreCase(str, "Player information", iIndexOfLine);
        }
        if (iIndexOfIgnoreCase3 < 0) {
            iIndexOfIgnoreCase3 = str.length();
        }
        return str.substring(iIndexOfLine, iIndexOfIgnoreCase3);
    }

    static String extractBadgeSection(String str) {
        int iIndexOfIgnoreCase;
        int iIndexOfIgnoreCase2 = indexOfIgnoreCase(str, "Hot Zones", 0);
        if (iIndexOfIgnoreCase2 >= 0 && (iIndexOfIgnoreCase = indexOfIgnoreCase(str, "Badges", iIndexOfIgnoreCase2)) >= 0) {
            int iIndexOfLine = indexOfLine(str, "Shot", iIndexOfIgnoreCase);
            return (iIndexOfLine < 0 || iIndexOfLine <= iIndexOfIgnoreCase) ? "" : str.substring(iIndexOfIgnoreCase, iIndexOfLine);
        }
        return "";
    }

    private static int indexOfLine(String str, String str2, int i) {
        String strReplace = str.replace("\r\n", "\n").replace('\r', '\n');
        int iIndexOf = strReplace.toLowerCase(Locale.US).indexOf(new StringBuffer().append(new StringBuffer().append("\n").append(str2).toString()).append("\n").toString().toLowerCase(Locale.US), Math.max(0, i));
        return iIndexOf >= 0 ? iIndexOf + 1 : (i > 0 || !strReplace.regionMatches(true, 0, new StringBuffer().append(str2).append("\n").toString(), 0, str2.length() + 1)) ? -1 : 0;
    }

    private static int indexOfIgnoreCase(String str, String str2, int i) {
        if (str == null || str2 == null) {
            return -1;
        }
        return str.toLowerCase(Locale.US).indexOf(str2.toLowerCase(Locale.US), Math.max(0, i));
    }

    private static int extractRangeValue(String str, String str2, int i, int i2) {
        int i3 = 0;
        Matcher matcher = Pattern.compile(new StringBuffer().append(new StringBuffer().append("(?is)(?:^|\\n|\\s)").append(Pattern.quote(str2)).toString()).append("\\s+(\\d{1,3})(?:\\s|$)").toString()).matcher(str);
        while (matcher.find()) {
            try {
                i3 = Integer.parseInt(matcher.group(1));
            } catch (Exception e) {
            }
            if (i3 >= i && i3 <= i2) {
                return i3;
            }
        }
        return -1;
    }

    private static boolean containsPhrase(String str, String str2) {
        if (str == null || str2 == null) {
            return false;
        }
        return Pattern.compile(new StringBuffer().append(new StringBuffer().append("(?i)(?:^|[^A-Za-z0-9])").append(Pattern.quote(str2)).toString()).append("(?:$|[^A-Za-z0-9])").toString()).matcher(str).find();
    }

    public static String slugify(String str) {
        return Normalizer.normalize(str, Normalizer.Form.NFD).replaceAll("\\p{M}+", "").toLowerCase(Locale.US).replace((char) 8217, '\'').replace((char) 8216, '\'').replace('&', ' ').replace("'", "").replace(".", "").replaceAll("[^a-z0-9]+", "-").replaceAll("^-+|-+$", "");
    }

    private static String download(String str) throws IOException {
        int i;
        HttpURLConnection httpURLConnection = (HttpURLConnection) null;
        InputStream inputStream = (InputStream) null;
        try {
            HttpURLConnection httpURLConnection2 = (HttpURLConnection) new URL(str).openConnection();
            httpURLConnection2.setConnectTimeout(CONNECT_TIMEOUT_MS);
            httpURLConnection2.setReadTimeout(READ_TIMEOUT_MS);
            httpURLConnection2.setInstanceFollowRedirects(true);
            httpURLConnection2.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36 AkoSiMC/1.0");
            httpURLConnection2.setRequestProperty("Accept", "text/html,application/xhtml+xml");
            httpURLConnection2.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
            httpURLConnection2.connect();
            int responseCode = httpURLConnection2.getResponseCode();
            if (responseCode < 200 || responseCode >= 300) {
                throw new IOException(new StringBuffer().append(new StringBuffer().append("Online provider returned HTTP ").append(responseCode).toString()).append(".").toString());
            }
            InputStream inputStream2 = httpURLConnection2.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream2, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            char[] cArr = new char[8192];
            while (sb.length() < MAX_HTML_CHARS && (i = bufferedReader.read(cArr)) >= 0) {
                int iMin = Math.min(i, MAX_HTML_CHARS - sb.length());
                sb.append(cArr, 0, iMin);
                if (iMin < i) {
                    break;
                }
            }
            String string = sb.toString();
            if (inputStream2 != null) {
                try {
                    inputStream2.close();
                } catch (Exception e) {
                }
            }
            if (httpURLConnection2 != null) {
                httpURLConnection2.disconnect();
            }
            return string;
        } catch (Throwable th) {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (Exception e2) {
                }
            }
            if (httpURLConnection != null) {
                httpURLConnection.disconnect();
            }
            throw th;
        }
    }

    private static String extractHeading(String str, String str2) {
        Matcher matcher = Pattern.compile("(?is)<h1[^>]*>(.*?)</h1>").matcher(str);
        if (matcher.find()) {
            String strTrim = htmlToText(matcher.group(1)).trim();
            if (strTrim.length() > 0 && strTrim.length() < 100) {
                return strTrim;
            }
        }
        return str2;
    }

    private static int extractOverall(String str) {
        int iRegexInt = regexInt(str, "(?i)\\b(\\d{2})\\s+OVERALL\\b");
        if (iRegexInt < 0) {
            iRegexInt = regexInt(str, "(?i)Overall\\s+2K\\s+Rating\\s+of\\s+(\\d{2})\\b");
        }
        if (iRegexInt < 0) {
            iRegexInt = regexInt(str, "(?i)2K\\s+Rating\\s+is\\s+(\\d{2})\\b");
        }
        return validRatingOrMinusOne(iRegexInt);
    }

    private static int extractRating(String str, String str2) {
        String strQuote = Pattern.quote(str2);
        int iRegexInt = regexInt(str, new StringBuffer().append(new StringBuffer().append("(?i)\\b").append(strQuote).toString()).append("\\s+(\\d{1,3})\\b").toString());
        if (iRegexInt < 0) {
            iRegexInt = regexInt(str, new StringBuffer().append(new StringBuffer().append("(?i)\\b(\\d{1,3})\\s+").append(strQuote).toString()).append("\\b").toString());
        }
        return validRatingOrMinusOne(iRegexInt);
    }

    private static int regexInt(String str, String str2) {
        Matcher matcher = Pattern.compile(str2).matcher(str);
        if (!matcher.find()) {
            return -1;
        }
        try {
            return Integer.parseInt(matcher.group(1));
        } catch (Exception e) {
            return -1;
        }
    }

    private static int validRatingOrMinusOne(int i) {
        return (i < 25 || i > 99) ? -1 : i;
    }

    static String htmlToText(String str) {
        return decodeEntities(str.replaceAll("(?is)<script[^>]*>.*?</script>", " ").replaceAll("(?is)<style[^>]*>.*?</style>", " ").replaceAll("(?is)<(?:br|/p|/li|/div|/h[1-6]|tr)[^>]*>", "\n").replaceAll("(?is)<[^>]+>", " ")).replace((char) 160, ' ').replaceAll("[\\t\\x0B\\f\\r ]+", " ").replaceAll(" *\\n+ *", "\n").trim();
    }

    private static String decodeEntities(String str) {
        int i;
        String str2;
        int i2;
        String str3;
        Matcher matcher = Pattern.compile("&#(\\d{1,7});").matcher(str.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'").replace("&lt;", "<").replace("&gt;", ">"));
        StringBuffer stringBuffer = new StringBuffer();
        while (matcher.find()) {
            try {
                i2 = Integer.parseInt(matcher.group(1));
            } catch (Exception e) {
                i2 = 32;
            }
            try {
                str3 = str;
                String str4 = new String(Character.toChars(i2));
            } catch (Exception e2) {
                str3 = " ";
            }
            matcher.appendReplacement(stringBuffer, Matcher.quoteReplacement(str3));
        }
        matcher.appendTail(stringBuffer);
        Matcher matcher2 = Pattern.compile("&#x([0-9a-fA-F]{1,6});").matcher(stringBuffer.toString());
        StringBuffer stringBuffer2 = new StringBuffer();
        while (matcher2.find()) {
            try {
                i = Integer.parseInt(matcher2.group(1), 16);
            } catch (Exception e3) {
                i = 32;
            }
            try {
                str2 = str;
                String str5 = new String(Character.toChars(i));
            } catch (Exception e4) {
                str2 = " ";
            }
            matcher2.appendReplacement(stringBuffer2, Matcher.quoteReplacement(str2));
        }
        matcher2.appendTail(stringBuffer2);
        return stringBuffer2.toString();
    }

    public static String compactSummary(RatingSnapshot ratingSnapshot) {
        String str;
        StringBuilder sb = new StringBuilder();
        if (ratingSnapshot.resolvedName == null) {
            str = ratingSnapshot.requestedName;
        } else {
            str = ratingSnapshot.resolvedName;
        }
        sb.append(str);
        if (ratingSnapshot.overall > 0) {
            sb.append(" • OVR ").append(ratingSnapshot.overall);
        }
        sb.append("\n");
        int i = 0;
        for (Map.Entry<String, Integer> entry : ratingSnapshot.localRatings.entrySet()) {
            if (i > 0) {
                sb.append("  •  ");
            }
            sb.append(entry.getKey()).append(' ').append(entry.getValue().intValue());
            i++;
            if (i == 7) {
                break;
            }
        }
        if (ratingSnapshot.localRatings.size() > i) {
            sb.append("  •  +").append(ratingSnapshot.localRatings.size() - i).append(" ratings");
        }
        sb.append("\nReady: ").append(ratingSnapshot.localRatings.size()).append(" ratings");
        sb.append(" • ").append(ratingSnapshot.localTendencies.size()).append(" tendencies");
        sb.append(" • ").append(ratingSnapshot.compatibleLegacyBadgeIds.size()).append(" exact legacy badges");
        if (ratingSnapshot.enrichmentWarning != null && ratingSnapshot.enrichmentWarning.length() > 0) {
            sb.append("\nTendency/badge source: unavailable");
        }
        return sb.toString();
    }

    OnlineRatingsClient() {
    }
}
