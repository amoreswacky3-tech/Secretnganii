package com.nocluetools.prov1.roster;

import com.nocluetools.prov1.roster.RosterPlayerMap;
import com.nocluetools.prov1.roster.RosterProbe;
import java.util.HashSet;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class CyberfaceAllocator {
    public static final int CUSTOM_END = 9999;
    public static final int CUSTOM_START = 9000;

    public static final class Result {
        public final int cfId;
        public final boolean mainScanned;
        public final Set<Integer> mainUsed;
        public final boolean patchScanned;
        public final Set<Integer> patchUsed;
        public final Set<Integer> rosterUsed;

        Result(int i, Set<Integer> set, Set<Integer> set2, Set<Integer> set3, boolean z, boolean z2) {
            this.cfId = i;
            this.rosterUsed = set;
            this.mainUsed = set2;
            this.patchUsed = set3;
            this.mainScanned = z;
            this.patchScanned = z2;
        }

        public boolean fullyVerified() {
            return this.mainScanned && this.patchScanned;
        }
    }

    CyberfaceAllocator() {
    }

    public static Set<Integer> rosterUsed(RosterProbe.Result result) {
        HashSet hashSet = new HashSet();
        if (result == null || result.players == null) {
            return hashSet;
        }
        for (RosterPlayerMap.PlayerRecord playerRecord : result.players) {
            if (playerRecord != null && playerRecord.hasUsableCyberfaceId()) {
                hashSet.add(Integer.valueOf(playerRecord.cyberfaceId));
            }
        }
        return hashSet;
    }

    public static int findNextFree(Set<Integer> set, Set<Integer> set2, Set<Integer> set3) {
        for (int i = 9000; i <= 9999; i++) {
            Integer numValueOf = Integer.valueOf(i);
            if ((set == null || !set.contains(numValueOf)) && ((set2 == null || !set2.contains(numValueOf)) && (set3 == null || !set3.contains(numValueOf)))) {
                return i;
            }
        }
        return -1;
    }
}
