package com.nocluetools.prov1;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class HeadHairActivity extends Activity {

    TextView headTitle, headStatus, headClose;
    EditText headSearch;
    ListView headList;
    TextView btnOpenIffStandalone, btnOpenIffInObb;

    ArrayAdapter<String> adapter;
    List<String> headFiles = new ArrayList<>();
    String currentObbSession = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_head_hair); // Make sure this matches your XML filename

        initViews();
        setupListeners();

        // Check if we opened this from an OBB
        currentObbSession = getIntent().getStringExtra("OBB_SESSION");
        
        if (currentObbSession != null && !currentObbSession.isEmpty()) {
            headStatus.setText("Ready to scan OBB for cyberfaces...");
            // Optionally, auto-scan here:
            // scanCyberfacesFromPython();
        } else {
            headStatus.setText("Select a standalone IFF or open an OBB first.");
        }
    }

    private void initViews() {
        headTitle = findViewById(R.id.headTitle);
        headStatus = findViewById(R.id.headStatus);
        headClose = findViewById(R.id.headClose);
        headSearch = findViewById(R.id.headSearch);
        headList = findViewById(R.id.headList);
        btnOpenIffStandalone = findViewById(R.id.btnOpenIffStandalone);
        btnOpenIffInObb = findViewById(R.id.btnOpenIffInObb);

        // Setup Search Bar
        headSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (adapter != null) adapter.getFilter().filter(s);
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // Setup List Item Click (Selecting a head/hair)
        headList.setOnItemClickListener((parent, view, position, id) -> {
            String selected = adapter.getItem(position);
            headStatus.setText("Selected: " + selected);
            // Here you would normally open the 3D Viewer or trigger an export!
            Toast.makeText(this, "Selected: " + selected, Toast.LENGTH_SHORT).show();
        });
    }

    private void setupListeners() {
        headClose.setOnClickListener(v -> finish());

        btnOpenIffStandalone.setOnClickListener(v -> {
            // TODO: Launch a File Picker (Intent.ACTION_GET_CONTENT) to pick a standalone .iff
            Toast.makeText(this, "Opening standalone IFF Picker...", Toast.LENGTH_SHORT).show();
        });

        btnOpenIffInObb.setOnClickListener(v -> {
            if (currentObbSession == null || currentObbSession.isEmpty()) {
                Toast.makeText(this, "No OBB session active. Please open an OBB first.", Toast.LENGTH_SHORT).show();
            } else {
                scanCyberfacesFromPython();
            }
        });
    }

    private void scanCyberfacesFromPython() {
        headStatus.setText("Scanning OBB for cyberfaces...");
        headFiles.clear();

        // Run in background thread to prevent UI freezing
        new Thread(() -> {
            try {
                if (!Python.isStarted()) {
                    Python.start(new AndroidPlatform(this));
                }
                Python py = Python.getInstance();
                PyObject bridge = py.getModule("noclue2k_bridge");

                // 🚨 CALLING YOUR PYTHON FUNCTION 🚨
                PyObject result = bridge.callAttr("scan_obb_cyberfaces_bridge", currentObbSession, getCacheDir().getAbsolutePath());
                String jsonString = result.toString();

                JSONObject json = new JSONObject(jsonString);
                
                if (json.getBoolean("ok")) {
                    // Parse the JSON array of cyberfaces
                    JSONArray rows = json.optJSONArray("rows"); // Assuming your python returns "rows" or "cyberfaces"
                    if (rows != null) {
                        for (int i = 0; i < rows.length(); i++) {
                            JSONObject row = rows.getJSONObject(i);
                            String name = row.optString("name", "Unknown Head");
                            headFiles.add(name);
                        }
                    }
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Python Error: " + json.optString("error"), Toast.LENGTH_LONG).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Exception: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }

            // Update UI
            runOnUiThread(() -> {
                if (headFiles.isEmpty()) {
                    headStatus.setText("No cyberfaces found.");
                } else {
                    headStatus.setText("Found " + headFiles.size() + " cyberfaces.");
                }
                
                adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, headFiles);
                headList.setAdapter(adapter);
            });
        }).start();
    }
}