package com.nocluetools.prov1;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class PlayerEditorActivity extends Activity {

    TextView pepTitle, pepSubtitle, pepClose, pepSave, pepDone;
    LinearLayout pepTabRow, pepContent;

    String currentPlayerId = "";
    String currentTab = "ATTRIBUTES";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_editor_pro); // Use your XML name here

        // Link UI
        pepTitle = findViewById(R.id.pepTitle);
        pepSubtitle = findViewById(R.id.pepSubtitle);
        pepClose = findViewById(R.id.pepClose);
        pepSave = findViewById(R.id.pepSave);
        pepDone = findViewById(R.id.pepDone);
        pepTabRow = findViewById(R.id.pepTabRow);
        pepContent = findViewById(R.id.pepContent);

        // Get Player ID from the previous screen
        currentPlayerId = getIntent().getStringExtra("PLAYER_ID");
        String playerName = getIntent().getStringExtra("PLAYER_NAME");

        if (playerName != null) {
            pepTitle.setText("EDIT: " + playerName.toUpperCase());
            pepSubtitle.setText("ID: " + currentPlayerId + " · ROSTER PRO");
        }

        setupClickListeners();
        createTabs(); // 🚨 Build the Tab Row in Java
        loadTabContent(currentTab); // 🚨 Build the Text Fields in Java
    }

    private void setupClickListeners() {
        pepClose.setOnClickListener(v -> finish());
        pepDone.setOnClickListener(v -> finish());

        pepSave.setOnClickListener(v -> {
            pepSave.setText("SAVING...");
            pepSave.setEnabled(false);

            // 🚨 Call Python to save the updated player data
            new Thread(() -> {
                try {
                    if (!Python.isStarted()) {
                        Python.start(new AndroidPlatform(this));
                    }
                    Python py = Python.getInstance();
                    PyObject bridge = py.getModule("noclue2k_bridge");

                    // Example: bridge.callAttr("update_player_bridge", sessionId, playerId, jsonOfUpdatedStats)
                    // For now, we just simulate a save
                    Thread.sleep(1000); 

                    runOnUiThread(() -> {
                        Toast.makeText(this, "Player Saved Successfully!", Toast.LENGTH_SHORT).show();
                        pepSave.setText("💾  SAVE");
                        pepSave.setEnabled(true);
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        Toast.makeText(this, "Save Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        pepSave.setText("💾  SAVE");
                        pepSave.setEnabled(true);
                    });
                }
            }).start();
        });
    }

    // ─── DYNAMIC TAB CREATION ───
    private void createTabs() {
        String[] tabs = {"ATTRIBUTES", "TENDENCIES", "CONTRACT", "GEAR"};
        
        for (String tabName : tabs) {
            TextView tab = new TextView(this);
            tab.setText(tabName);
            tab.setTextSize(11f);
            tab.setTextColor(Color.parseColor("#6B7280"));
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(40, 25, 40, 25);
            tab.setBackgroundResource(R.drawable.bg_btn_secondary);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(0, 0, 10, 0);
            tab.setLayoutParams(params);

            tab.setOnClickListener(v -> {
                currentTab = tabName;
                // Reset all tab colors
                for (int i = 0; i < pepTabRow.getChildCount(); i++) {
                    TextView t = (TextView) pepTabRow.getChildAt(i);
                    t.setBackgroundResource(R.drawable.bg_btn_secondary);
                    t.setTextColor(Color.parseColor("#6B7280"));
                }
                // Highlight active tab
                tab.setBackgroundResource(R.drawable.bg_btn_primary);
                tab.setTextColor(Color.parseColor("#FFFFFF"));
                
                loadTabContent(currentTab);
            });

            pepTabRow.addView(tab);
        }

        // Highlight the first tab by default
        if (pepTabRow.getChildCount() > 0) {
            TextView firstTab = (TextView) pepTabRow.getChildAt(0);
            firstTab.setBackgroundResource(R.drawable.bg_btn_primary);
            firstTab.setTextColor(Color.parseColor("#FFFFFF"));
        }
    }

    // ─── DYNAMIC CONTENT CREATION ───
    private void loadTabContent(String tabName) {
        pepContent.removeAllViews(); // Clear old fields

        // In your real app, you would fetch the stats from Python using the currentPlayerId here!
        // For now, we generate dummy fields based on the tab name.
        String[] fieldsToGenerate;
        
        switch (tabName) {
            case "ATTRIBUTES":
                fieldsToGenerate = new String[]{"Overall Rating", "3PT Shot", "Dunk", "Speed", "Strength"};
                break;
            case "TENDENCIES":
                fieldsToGenerate = new String[]{"Shot Tendency", "Drive Tendency", "Pass Tendency"};
                break;
            case "CONTRACT":
                fieldsToGenerate = new String[]{"Salary ($)", "Years Remaining", "Player Option"};
                break;
            default:
                fieldsToGenerate = new String[]{"Accessories", "Shoes"};
                break;
        }

        for (String field : fieldsToGenerate) {
            addStatRow(field, "99"); // Passing "99" as a default dummy value
        }
    }

    private void addStatRow(String labelText, String defaultValue) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 20, 0, 20);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView label = new TextView(this);
        label.setText(labelText);
        label.setTextColor(Color.parseColor("#FFFFFF"));
        label.setTextSize(14f);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        label.setLayoutParams(labelParams);

        EditText input = new EditText(this);
        input.setText(defaultValue);
        input.setTextColor(Color.parseColor("#2196F3"));
        input.setTextSize(16f);
        input.setGravity(Gravity.END);
        input.setBackgroundResource(R.drawable.bg_input);
        input.setPadding(20, 10, 20, 10);
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(150, LinearLayout.LayoutParams.WRAP_CONTENT);
        input.setLayoutParams(inputParams);

        row.addView(label);
        row.addView(input);

        // Add a subtle divider line below the row
        View divider = new View(this);
        divider.setBackgroundColor(Color.parseColor("#141A22"));
        LinearLayout.LayoutParams divParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 2);
        divider.setLayoutParams(divParams);

        pepContent.addView(row);
        pepContent.addView(divider);
    }
}