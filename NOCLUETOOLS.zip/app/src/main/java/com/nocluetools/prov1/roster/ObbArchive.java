package com.nocluetools.prov1.roster;

import android.content.ContentResolver;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.zip.CRC32;

/* JADX INFO: loaded from: classes.dex */
public final class ObbArchive {
    private static final int BIN_DESCRIPTOR_SIZE = 208;
    private static final int ENTRY_SIZE = 16;
    private static final int HEADER_SIZE = 40;
    public static final long MAGIC = 2852172735L;
    private final int binCount;
    private final long blockSize;
    private final FileChannel channel;
    private final int entryCount;
    private final FileInputStream input;
    private final ParcelFileDescriptor pfd;
    private final long tocOffset;

    public static final class Entry {
        public final long blockIndex;
        public final long dataOffset;
        public final int index;
        public final long logicalSize;
        public final long nameHash;

        Entry(int i, long j, long j2, long j3, long j4) {
            this.index = i;
            this.logicalSize = j;
            this.nameHash = j2;
            this.blockIndex = j3;
            this.dataOffset = j4;
        }
    }

    public static final class ArchiveInfo {
        public final int binCount;
        public final List<String> binDescriptorPrefixes;
        public final long blockSize;
        public final int entryCount;
        public final long fileSize;
        public final long firstDataOffset;
        public final long gapAfterToc;
        public final long tocEnd;
        public final long tocOffset;
        public final int zeroHashEntries;
        public final int zeroSizeEntries;

        ArchiveInfo(long j, long j2, int i, int i2, long j3, long j4, long j5, long j6, int i3, int i4, List<String> list) {
            this.fileSize = j;
            this.blockSize = j2;
            this.binCount = i;
            this.entryCount = i2;
            this.tocOffset = j3;
            this.tocEnd = j4;
            this.firstDataOffset = j5;
            this.gapAfterToc = j6;
            this.zeroHashEntries = i3;
            this.zeroSizeEntries = i4;
            this.binDescriptorPrefixes = list;
        }
    }

    public static final class RealnameCoverage {
        public final int knownEntries;
        public final int totalEntries;
        public final List<Entry> unknownEntries;

        RealnameCoverage(int i, int i2, List<Entry> list) {
            this.totalEntries = i;
            this.knownEntries = i2;
            this.unknownEntries = list;
        }
    }

    public ObbArchive(ContentResolver contentResolver, Uri uri) throws IOException {
        ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor = contentResolver.openFileDescriptor(uri, "r");
        if (parcelFileDescriptorOpenFileDescriptor == null) {
            throw new IOException("Could not open OBB.");
        }
        this.pfd = parcelFileDescriptorOpenFileDescriptor;
        this.input = new FileInputStream(this.pfd.getFileDescriptor());
        this.channel = this.input.getChannel();
        ByteBuffer at = readAt(0, HEADER_SIZE);
        long jU32 = u32(at.getInt(0));
        if (jU32 != MAGIC) {
            throw new IOException(String.format(Locale.US, "Unsupported OBB magic: 0x%08X", new Long(jU32)));
        }
        this.blockSize = u32(at.getInt(4));
        this.binCount = at.getInt(8);
        this.entryCount = at.getInt(24);
        if (this.blockSize <= 0 || this.binCount <= 0 || this.binCount > 1024 || this.entryCount <= 0 || this.entryCount > 1000000) {
            throw new IOException("Invalid OBB header values.");
        }
        this.tocOffset = ((long) HEADER_SIZE) + (((long) this.binCount) * ((long) BIN_DESCRIPTOR_SIZE));
        long j = this.tocOffset + (((long) this.entryCount) * ((long) ENTRY_SIZE));
        if (this.tocOffset < HEADER_SIZE || j < this.tocOffset || j > this.channel.size()) {
            throw new IOException("OBB table points outside the file.");
        }
    }

    public int getEntryCount() {
        return this.entryCount;
    }

    public int getBinCount() {
        return this.binCount;
    }

    public long getBlockSize() {
        return this.blockSize;
    }

    public long getTocOffset() {
        return this.tocOffset;
    }

    public Entry findByHash(long j) throws IOException {
        long j2 = this.tocOffset;
        int i = 0;
        while (i < this.entryCount) {
            int iMin = Math.min(512, this.entryCount - i);
            ByteBuffer at = readAt(j2, iMin * ENTRY_SIZE);
            for (int i2 = 0; i2 < iMin; i2++) {
                int i3 = i2 * ENTRY_SIZE;
                long j3 = at.getLong(i3);
                long jU32 = u32(at.getInt(i3 + 8));
                long jU322 = u32(at.getInt(i3 + 12));
                if (jU32 == j) {
                    return checkedEntry(i + i2, j3, jU32, jU322);
                }
            }
            i += iMin;
            j2 += ((long) iMin) * ((long) ENTRY_SIZE);
        }
        return (Entry) null;
    }

    public RealnameCoverage scanRealnameCoverage(Set<Long> set) throws IOException {
        if (set == null) {
            throw new IllegalArgumentException("Known hash set is required.");
        }
        int i = 0;
        ArrayList arrayList = new ArrayList();
        long j = this.tocOffset;
        int i2 = 0;
        while (i2 < this.entryCount) {
            int iMin = Math.min(1024, this.entryCount - i2);
            ByteBuffer at = readAt(j, iMin * ENTRY_SIZE);
            for (int i3 = 0; i3 < iMin; i3++) {
                int i4 = i3 * ENTRY_SIZE;
                long j2 = at.getLong(i4);
                long jU32 = u32(at.getInt(i4 + 8));
                long jU322 = u32(at.getInt(i4 + 12));
                if (set.contains(Long.valueOf(jU32))) {
                    i++;
                } else {
                    arrayList.add(checkedEntry(i2 + i3, j2, jU32, jU322));
                }
            }
            i2 += iMin;
            j += ((long) iMin) * ((long) ENTRY_SIZE);
        }
        return new RealnameCoverage(this.entryCount, i, arrayList);
    }

    public Set<Integer> scanCyberfaceIds(int i, int i2) throws IOException {
        if (i < 0 || i2 < i || i2 > 9999) {
            throw new IllegalArgumentException("CFID scan range must be within 0-9999.");
        }
        HashMap map = new HashMap();
        for (int i3 = i; i3 <= i2; i3++) {
            map.put(Long.valueOf(hashFileName(String.format(Locale.US, "png%04d.iff", new Integer(i3)))), Integer.valueOf(i3));
        }
        HashSet hashSet = new HashSet();
        long j = this.tocOffset;
        int i4 = 0;
        while (i4 < this.entryCount) {
            int iMin = Math.min(1024, this.entryCount - i4);
            ByteBuffer at = readAt(j, iMin * ENTRY_SIZE);
            for (int i5 = 0; i5 < iMin; i5++) {
                Integer num = (Integer) map.get(Long.valueOf(u32(at.getInt((i5 * ENTRY_SIZE) + 8))));
                if (num != null) {
                    hashSet.add(num);
                }
            }
            i4 += iMin;
            j += ((long) iMin) * ((long) ENTRY_SIZE);
        }
        return hashSet;
    }

    public ArchiveInfo inspectLayout() throws IOException {
        long size = this.channel.size();
        long j = this.tocOffset + (((long) this.entryCount) * ((long) ENTRY_SIZE));
        long j2 = Long.MAX_VALUE;
        int i = 0;
        int i2 = 0;
        long j3 = this.tocOffset;
        int i3 = 0;
        while (i3 < this.entryCount) {
            int iMin = Math.min(1024, this.entryCount - i3);
            ByteBuffer at = readAt(j3, iMin * ENTRY_SIZE);
            for (int i4 = 0; i4 < iMin; i4++) {
                int i5 = i4 * ENTRY_SIZE;
                long j4 = at.getLong(i5);
                long jU32 = u32(at.getInt(i5 + 8));
                long jU322 = u32(at.getInt(i5 + 12));
                if (jU32 == 0) {
                    i++;
                }
                if (j4 == 0) {
                    i2++;
                }
                if (j4 > 0) {
                    try {
                        long jMultiplyExact = Math.multiplyExact(jU322, this.blockSize);
                        if (jMultiplyExact >= 0 && jMultiplyExact < j2) {
                            j2 = jMultiplyExact;
                        }
                    } catch (ArithmeticException e) {
                        throw new IOException("OBB data offset overflow.");
                    }
                }
            }
            i3 += iMin;
            j3 += ((long) iMin) * ((long) ENTRY_SIZE);
        }
        if (j2 == Long.MAX_VALUE) {
            j2 = -1;
        }
        long j5 = j2 >= ((long) 0) ? j2 - j : -1;
        ArrayList arrayList = new ArrayList();
        for (int i6 = 0; i6 < this.binCount; i6++) {
            ByteBuffer at2 = readAt(((long) HEADER_SIZE) + (((long) i6) * ((long) BIN_DESCRIPTOR_SIZE)), 32);
            StringBuilder sb = new StringBuilder(64);
            for (int i7 = 0; i7 < 32; i7++) {
                if (i7 > 0) {
                    sb.append(' ');
                }
                sb.append(String.format(Locale.US, "%02X", new Integer(at2.get(i7) & 255)));
            }
            arrayList.add(sb.toString());
        }
        return new ArchiveInfo(size, this.blockSize, this.binCount, this.entryCount, this.tocOffset, j, j2, j5, i, i2, arrayList);
    }

    private Entry checkedEntry(int i, long j, long j2, long j3) throws IOException {
        try {
            long jMultiplyExact = Math.multiplyExact(j3, this.blockSize);
            long size = this.channel.size();
            if (j < 0 || jMultiplyExact < 0 || j > size || jMultiplyExact > size - j) {
                throw new IOException("OBB entry points outside the file.");
            }
            return new Entry(i, j, j2, j3, jMultiplyExact);
        } catch (ArithmeticException e) {
            throw new IOException("OBB data offset overflow.");
        }
    }

    public void copyEntryTo(Entry entry, FileChannel fileChannel) throws IOException {
        long j = entry.logicalSize;
        long j2 = entry.dataOffset;
        ByteBuffer byteBufferAllocateDirect = ByteBuffer.allocateDirect(1048576);
        while (j > 0) {
            int iMin = (int) Math.min(byteBufferAllocateDirect.capacity(), j);
            byteBufferAllocateDirect.clear();
            byteBufferAllocateDirect.limit(iMin);
            int i = this.channel.read(byteBufferAllocateDirect, j2);
            if (i <= 0) {
                throw new IOException("Unexpected EOF while exporting IFF.");
            }
            byteBufferAllocateDirect.flip();
            while (byteBufferAllocateDirect.hasRemaining()) {
                fileChannel.write(byteBufferAllocateDirect);
            }
            j2 += (long) i;
            j -= (long) i;
        }
        fileChannel.force(true);
    }

    private ByteBuffer readAt(long j, int i) throws IOException {
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(i).order(ByteOrder.LITTLE_ENDIAN);
        long j2 = j;
        while (byteBufferOrder.hasRemaining()) {
            int i2 = this.channel.read(byteBufferOrder, j2);
            if (i2 < 0) {
                throw new IOException("Unexpected EOF in OBB table.");
            }
            if (i2 != 0) {
                j2 += (long) i2;
            }
        }
        byteBufferOrder.flip();
        return byteBufferOrder;
    }

    public static long hashFileName(String str) throws UnsupportedEncodingException {
        byte[] bytes;
        CRC32 crc32 = new CRC32();
        try {
            bytes = str.toUpperCase(Locale.US).getBytes("US-ASCII");
        } catch (Exception e) {
            bytes = str.toUpperCase(Locale.US).getBytes();
        }
        crc32.update(bytes, 0, bytes.length);
        return crc32.getValue() & 4294967295L;
    }

    private static long u32(int i) {
        return ((long) i) & 4294967295L;
    }

    public void close() throws IOException {
        IOException iOException = (IOException) null;
        try {
            this.channel.close();
        } catch (IOException e) {
            iOException = e;
        }
        try {
            this.input.close();
        } catch (IOException e2) {
            if (iOException == null) {
                iOException = e2;
            }
        }
        try {
            this.pfd.close();
        } catch (IOException e3) {
            if (iOException == null) {
                iOException = e3;
            }
        }
        if (iOException != null) {
            throw iOException;
        }
    }
}
