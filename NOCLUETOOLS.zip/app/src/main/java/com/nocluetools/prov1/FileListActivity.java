package com.nocluetools.prov1;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class FileListActivity extends Activity {

    // UI Elements
    TextView fileListTitle, fileListSubtitle, fileListCount;
    EditText fileListSearch;
    ListView fileList;
    ProgressBar progressBar;
    TextView fileListClose, fileListAudio, fileListHeadMesh, fileListExtract, fileListSaveObb, fileListRefreshBtn;

    // Data
    ArrayAdapter<String> adapter;
    List<String> fileNames = new ArrayList<>();
    String currentObbSession = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_list); // Make sure this matches your XML filename

        initViews();
        setupClickListeners();

        // Get the OBB Session ID passed from the Main Menu
        currentObbSession = getIntent().getStringExtra("OBB_SESSION");
        if (currentObbSession == null) {
            currentObbSession = "dummy_session"; // Fallback for testing
        }

        // Load the files
        loadFilesFromPython();
    }

    private void initViews() {
        fileListTitle = findViewById(R.id.fileListTitle);
        fileListSubtitle = findViewById(R.id.fileListSubtitle);
        fileListCount = findViewById(R.id.fileListCount);
        fileListSearch = findViewById(R.id.fileListSearch);
        fileList = findViewById(R.id.fileList);
        progressBar = findViewById(R.id.progressBar);

        fileListClose = findViewById(R.id.fileListClose);
        fileListAudio = findViewById(R.id.fileListAudio);
        fileListHeadMesh = findViewById(R.id.fileListHeadMesh);
        fileListExtract = findViewById(R.id.fileListExtract);
        fileListSaveObb = findViewById(R.id.fileListSaveObb);
        fileListRefreshBtn = findViewById(R.id.fileListRefreshBtn);
        
        // Setup Search Bar
        fileListSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (adapter != null) adapter.getFilter().filter(s);
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void setupClickListeners() {
        fileListClose.setOnClickListener(v -> finish());

        fileListRefreshBtn.setOnClickListener(v -> {
            fileNames.clear();
            loadFilesFromPython();
        });

        // Open Audio Screen (Passing the OBB Session)
        fileListAudio.setOnClickListener(v -> {
            Intent intent = new Intent(FileListActivity.this, AudioListActivity.class);
            intent.putExtra("OBB_SESSION", currentObbSession);
            startActivity(intent);
        });

        // Placeholder for Head Mesh (As requested)
        fileListHeadMesh.setOnClickListener(v -> {
            Toast.makeText(this, "Head Mesh Beta Feature", Toast.LENGTH_SHORT).show();
        });

        fileListSaveObb.setOnClickListener(v -> {
            Toast.makeText(this, "Calling Python to Save OBB...", Toast.LENGTH_SHORT).show();
            // Future: Call bridge.callAttr("save_obb_bridge", currentObbSession)
        });

        // When a file is clicked, open the IFF Viewer (if it's an IFF)
        fileList.setOnItemClickListener((parent, view, position, id) -> {
            String selectedFile = adapter.getItem(position);
            if (selectedFile.toLowerCase().endsWith(".iff") || selectedFile.toLowerCase().endsWith(".cdf")) {
                Intent intent = new Intent(FileListActivity.this, IffViewerActivity.class);
                // Pass the file index and name to the viewer
                intent.putExtra("FILE_INDEX", position);
                intent.putExtra("FILE_NAME", selectedFile);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Selected: " + selectedFile, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadFilesFromPython() {
        // Show loading state
        progressBar.setVisibility(View.VISIBLE);
        fileListTitle.setText("LOADING FILES...");
        fileListSubtitle.setText("Please wait");
        
        // Run Python in the background so the UI doesn't freeze
        new Thread(() -> {
            try {
                if (!Python.isStarted()) {
                    Python.start(new AndroidPlatform(this));
                }
                Python py = Python.getInstance();
                PyObject bridge = py.getModule("noclue2k_bridge");

                // 🚨 CALLING PYTHON 🚨
                PyObject result = bridge.callAttr("obb_rows_bridge", currentObbSession);
                String jsonString = result.toString();

                JSONObject json = new JSONObject(jsonString);
                
                if (json.getBoolean("ok")) {
                    JSONArray rows = json.optJSONArray("rows");
                    if (rows != null) {
                        for (int i = 0; i < rows.length(); i++) {
                            JSONObject row = rows.getJSONObject(i);
                            // Try to get 'name', fallback to 'filename' or hash
                            String name = row.optString("name", row.optString("filename", "Unknown.iff"));
                            fileNames.add(name);
                        }
                    }
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Python Error: " + json.optString("error"), Toast.LENGTH_LONG).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Exception: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }

            // Update UI on the main thread
            runOnUiThread(() -> {
                progressBar.setVisibility(View.GONE);
                fileListTitle.setText("FILES IN OBB");
                fileListSubtitle.setText("Browse files · search by name, hash, or type");
                fileListCount.setText(fileNames.size() + " OBB entries");
                
                adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, fileNames);
                fileList.setAdapter(adapter);
                
                if (fileNames.isEmpty()) {
                    Toast.makeText(this, "No files found in OBB.", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }
}