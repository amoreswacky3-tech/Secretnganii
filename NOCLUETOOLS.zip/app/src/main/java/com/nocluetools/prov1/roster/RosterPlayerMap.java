package com.nocluetools.prov1.roster;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class RosterPlayerMap {
    private static final int ACTIVE_NBA_TEAM_COUNT = 30;
    private static final int PLAYER_BODY_TYPE_BITS = 1461;
    private static final int PLAYER_CF_BITS = 528;
    private static final int PLAYER_EYE_COLOR_BITS = 1477;
    private static final int PLAYER_FIRST_CRC_BITS = 96;
    private static final int PLAYER_FIRST_REF_BITS = 32;
    private static final int PLAYER_JERSEY_BITS = 301;
    private static final int PLAYER_LAST_CRC_BITS = 64;
    private static final int PLAYER_LAST_REF_BITS = 0;
    private static final int PLAYER_MUSCLE_TYPE_BITS = 1463;
    private static final int PLAYER_PORTRAIT_BITS = 256;
    private static final int PLAYER_SKIN_TONE_BITS = 1464;
    private static final int PLAYER_STRIDE_BITS = 4075;
    private static final long PLAYER_TAG_BASE = 543162368;
    private static final int PLAYER_TAG_BITS = 32;
    private static final int TEAM_ABBREV_REF_BITS = 672;
    private static final int TEAM_CITY_REF_BITS = 704;
    private static final int TEAM_DISPLAY_REF_BITS = 736;
    private static final int TEAM_NAME_CRC_BITS = 768;
    private static final int TEAM_NAME_REF_BITS = 640;
    private static final int TEAM_PLAYER_COUNT_BITS = 1000;
    private static final int TEAM_PLAYER_REF_BITS = 0;
    private static final int TEAM_PLAYER_REF_COUNT = 20;
    private static final int TEAM_SHORT_NAME_CRC_BITS = 800;
    private static final int TEAM_STRIDE_BITS = 6356;
    private static final long TEAM_TAG_BASE = 557842432;
    private static final int TEAM_TAG_BITS = 32;

    public static final class PlayerRecord {
        public final int bodyType;
        public final int cyberfaceId;
        public final int eyeColor;
        public final long firstNameCrc;
        public final long firstNameRef;
        public final int jerseyNumber;
        public final long lastNameCrc;
        public final long lastNameRef;
        public final int muscleType;
        public final int portraitId;
        public final int skinTone;
        public final int slot;
        public int activeTeamSlot = -1;
        public String firstName = "";
        public String lastName = "";
        public String displayName = "";

        PlayerRecord(int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, long j, long j2, long j3, long j4) {
            this.slot = i;
            this.cyberfaceId = i2;
            this.portraitId = i3;
            this.jerseyNumber = i4;
            this.bodyType = i5;
            this.muscleType = i6;
            this.skinTone = i7;
            this.eyeColor = i8;
            this.lastNameRef = j;
            this.firstNameRef = j2;
            this.lastNameCrc = j3;
            this.firstNameCrc = j4;
        }

        public boolean hasUsableCyberfaceId() {
            return this.cyberfaceId > 0 && this.cyberfaceId < 65280;
        }
    }

    public static final class TeamRecord {
        public final long abbreviationRef;
        public final long cityRef;
        public final long displayRef;
        public final int playerCount;
        public final int[] playerSlots;
        public final long shortNameCrc;
        public final int slot;
        public final long teamNameCrc;
        public final long teamNameRef;
        public String teamName = "";
        public String abbreviation = "";
        public String cityName = "";
        public String fullName = "";

        TeamRecord(int i, int i2, int[] iArr, long j, long j2, long j3, long j4, long j5, long j6) {
            this.slot = i;
            this.playerCount = i2;
            this.playerSlots = iArr;
            this.teamNameRef = j;
            this.abbreviationRef = j2;
            this.cityRef = j3;
            this.displayRef = j4;
            this.teamNameCrc = j5;
            this.shortNameCrc = j6;
        }
    }

    public static final class Result {
        public final List<TeamRecord> activeTeams;
        public final long playerTableBitOffset;
        public final List<PlayerRecord> players;
        public final int serializedTeamCount;
        public final long teamTableBitOffset;

        Result(long j, long j2, List<PlayerRecord> list, List<TeamRecord> list2, int i) {
            this.playerTableBitOffset = j;
            this.teamTableBitOffset = j2;
            this.players = Collections.unmodifiableList(list);
            this.activeTeams = Collections.unmodifiableList(list2);
            this.serializedTeamCount = i;
        }
    }

    public static Result parse(byte[] bArr) throws IOException {
        if (bArr == null || bArr.length < 1024) {
            throw new IOException("Decoded roster payload is empty.");
        }
        long jFindSequentialTable = findSequentialTable(bArr, PLAYER_TAG_BASE, PLAYER_STRIDE_BITS, 3);
        if (jFindSequentialTable < 0) {
            throw new IOException("PLAYERDATA table signature was not found.");
        }
        int iCountSequentialRecords = countSequentialRecords(bArr, jFindSequentialTable, PLAYER_TAG_BASE, PLAYER_STRIDE_BITS, 10000);
        if (iCountSequentialRecords < 100) {
            throw new IOException(new StringBuffer().append("PLAYERDATA table is too small: ").append(iCountSequentialRecords).toString());
        }
        ArrayList arrayList = new ArrayList(iCountSequentialRecords);
        for (int i = 0; i < iCountSequentialRecords; i++) {
            long j = jFindSequentialTable + (((long) i) * ((long) PLAYER_STRIDE_BITS)) + ((long) 32);
            int i2 = i;
            arrayList.add(new PlayerRecord(i2, (int) readBits(bArr, j + ((long) PLAYER_CF_BITS), 16), (int) readBits(bArr, j + ((long) PLAYER_PORTRAIT_BITS), 16), (int) readBits(bArr, j + ((long) PLAYER_JERSEY_BITS), 7), (int) readBits(bArr, j + ((long) PLAYER_BODY_TYPE_BITS), 2), (int) readBits(bArr, j + ((long) PLAYER_MUSCLE_TYPE_BITS), 1), (int) readBits(bArr, j + ((long) PLAYER_SKIN_TONE_BITS), 3), (int) readBits(bArr, j + ((long) PLAYER_EYE_COLOR_BITS), 3), readBits(bArr, j + ((long) 0), 32), readBits(bArr, j + ((long) 32), 32), readBits(bArr, j + ((long) PLAYER_LAST_CRC_BITS), 32), readBits(bArr, j + ((long) PLAYER_FIRST_CRC_BITS), 32)));
        }
        long jFindSequentialTable2 = findSequentialTable(bArr, TEAM_TAG_BASE, TEAM_STRIDE_BITS, 4);
        if (jFindSequentialTable2 < 0) {
            throw new IOException("TEAMDATA table signature was not found.");
        }
        int iCountSequentialRecords2 = countSequentialRecords(bArr, jFindSequentialTable2, TEAM_TAG_BASE, TEAM_STRIDE_BITS, 1024);
        if (iCountSequentialRecords2 < 30) {
            throw new IOException(new StringBuffer().append("TEAMDATA table is too small: ").append(iCountSequentialRecords2).toString());
        }
        ArrayList arrayList2 = new ArrayList(30);
        for (int i3 = 0; i3 < 30; i3++) {
            long j2 = jFindSequentialTable2 + (((long) i3) * ((long) TEAM_STRIDE_BITS)) + ((long) 32);
            int bits = (int) readBits(bArr, j2 + ((long) TEAM_PLAYER_COUNT_BITS), 8);
            if (bits < 0) {
                bits = 0;
            }
            if (bits > TEAM_PLAYER_REF_COUNT) {
                bits = TEAM_PLAYER_REF_COUNT;
            }
            int[] iArr = new int[bits];
            int i4 = 0;
            for (int i5 = 0; i5 < bits; i5++) {
                int iPlayerSlotFromRef = playerSlotFromRef(readBits(bArr, j2 + ((long) 0) + (((long) i5) * 32), 32), iCountSequentialRecords);
                if (iPlayerSlotFromRef >= 0) {
                    int i6 = i4;
                    i4++;
                    iArr[i6] = iPlayerSlotFromRef;
                    PlayerRecord playerRecord = (PlayerRecord) arrayList.get(iPlayerSlotFromRef);
                    if (playerRecord.activeTeamSlot < 0) {
                        playerRecord.activeTeamSlot = i3;
                    }
                }
            }
            if (i4 != iArr.length) {
                int[] iArr2 = new int[i4];
                System.arraycopy(iArr, 0, iArr2, 0, i4);
                iArr = iArr2;
            }
            arrayList2.add(new TeamRecord(i3, iArr.length, iArr, readBits(bArr, j2 + ((long) TEAM_NAME_REF_BITS), 32), readBits(bArr, j2 + ((long) TEAM_ABBREV_REF_BITS), 32), readBits(bArr, j2 + ((long) TEAM_CITY_REF_BITS), 32), readBits(bArr, j2 + ((long) TEAM_DISPLAY_REF_BITS), 32), readBits(bArr, j2 + ((long) TEAM_NAME_CRC_BITS), 32), readBits(bArr, j2 + ((long) TEAM_SHORT_NAME_CRC_BITS), 32)));
        }
        RosterNameResolver.resolve(bArr, arrayList, arrayList2);
        return new Result(jFindSequentialTable, jFindSequentialTable2, arrayList, arrayList2, iCountSequentialRecords2);
    }

    private static int playerSlotFromRef(long j, int i) {
        long j2 = j - PLAYER_TAG_BASE;
        if (j2 < 0 || j2 >= i) {
            return -1;
        }
        return (int) j2;
    }

    private static int countSequentialRecords(byte[] bArr, long j, long j2, int i, int i2) {
        int i3 = 0;
        long length = ((long) bArr.length) * 8;
        while (i3 < i2) {
            long j3 = j + (((long) i3) * ((long) i));
            if (j3 + 32 > length) {
                break;
            }
            if (readBits(bArr, j3, 32) != (j2 | (((long) i3) & 1048575))) {
                break;
            }
            i3++;
        }
        return i3;
    }

    private static long findSequentialTable(byte[] bArr, long j, int i, int i2) {
        byte[] bArr2 = {(byte) ((j >>> 24) & ((long) 255)), (byte) ((j >>> 16) & ((long) 255)), (byte) ((j >>> 8) & ((long) 255)), (byte) (j & ((long) 255))};
        for (int i3 = 0; i3 <= bArr.length - 4; i3++) {
            if (bArr[i3] == bArr2[0] && bArr[i3 + 1] == bArr2[1] && bArr[i3 + 2] == bArr2[2] && bArr[i3 + 3] == bArr2[3]) {
                long j2 = ((long) i3) * 8;
                if (verifySequence(bArr, j2, j, i, i2)) {
                    return j2;
                }
            }
        }
        int length = bArr.length;
        for (int i4 = 1; i4 < 8; i4++) {
            for (int i5 = 0; i5 < length - 4; i5++) {
                if (shiftedByte(bArr, i5, i4) == (bArr2[0] & 255) && shiftedByte(bArr, i5 + 1, i4) == (bArr2[1] & 255) && shiftedByte(bArr, i5 + 2, i4) == (bArr2[2] & 255) && shiftedByte(bArr, i5 + 3, i4) == (bArr2[3] & 255)) {
                    long j3 = (((long) i5) * 8) + ((long) i4);
                    if (verifySequence(bArr, j3, j, i, i2)) {
                        return j3;
                    }
                }
            }
        }
        return -1L;
    }

    private static boolean verifySequence(byte[] bArr, long j, long j2, int i, int i2) {
        long length = ((long) bArr.length) * 8;
        for (int i3 = 0; i3 < i2; i3++) {
            long j3 = j + (((long) i3) * ((long) i));
            if (j3 + 32 > length) {
                return false;
            }
            if (readBits(bArr, j3, 32) != (j2 | (((long) i3) & 1048575))) {
                return false;
            }
        }
        return true;
    }

    private static int shiftedByte(byte[] bArr, int i, int i2) {
        return (((bArr[i] & 255) << i2) & 255) | ((bArr[i + 1] & 255) >>> (8 - i2));
    }

    public static long readBits(byte[] bArr, long j, int i) {
        if (i < 1 || i > 32) {
            throw new IllegalArgumentException("width");
        }
        long length = ((long) bArr.length) * 8;
        if (j < 0 || j + ((long) i) > length) {
            throw new IllegalArgumentException("bitPosition");
        }
        long j2 = 0;
        for (int i2 = 0; i2 < i; i2++) {
            long j3 = j + ((long) i2);
            j2 = (j2 << 1) | ((long) (((bArr[(int) (j3 >>> 3)] & 255) >>> (7 - (((int) j3) & 7))) & 1));
        }
        return j2 & 4294967295L;
    }

    RosterPlayerMap() {
    }
}
