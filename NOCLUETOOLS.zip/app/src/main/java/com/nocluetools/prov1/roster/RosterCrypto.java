package com.nocluetools.prov1.roster;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.zip.CRC32;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

/* JADX INFO: loaded from: classes.dex */
public final class RosterCrypto {
    private static final int[] BASE_SCHEDULE = {-2080324580, 1187958024, 339253324, 33999628, 10794140, -2142795003, -1333481328, 210521920, -1875858348, 1158466240, 205058268, 17401478, 1220573344, -2079749179, -2133793560, 244091080, 341324896, 1078576840, 606629060, -2077520763, 545316008, -2004155199, -2146677656, 1283477440, 337177708, 1090995459, 1277171772, -2012281081, 1086340120, -930723448, 1347721276, 1174490432};
    private static final int[] SP = {34080768, 524288, 33554434, 34080770, 33554432, 526338, 524290, 33554434, 526338, 34080768, 34078720, 2050, 33556482, 33554432, 0, 524290, 524288, 2, 33556480, 526336, 34080770, 34078720, 2050, 33556480, 2, 2048, 526336, 34078722, 2048, 33556482, 34078722, 0, 0, 34080770, 33556480, 524290, 34080768, 524288, 2050, 33556480, 34078722, 2048, 526336, 33554434, 526338, 2, 33554434, 34078720, 34080770, 526336, 34078720, 33556482, 33554432, 2050, 524290, 0, 524288, 33554432, 33556482, 34080768, 2, 34078722, 2048, 526338, 1074823184, 0, 1081344, 1074790400, 1073741840, 32784, 1073774592, 1081344, 32768, 1074790416, 16, 1073774592, 1048592, 1074823168, 1074790400, 16, 1048576, 1073774608, 1074790416, 32768, 1081360, 1073741824, 0, 1048592, 1073774608, 1081360, 1074823168, 1073741840, 1073741824, 1048576, 32784, 1074823184, 1048592, 1074823168, 1073774592, 1081360, 1074823184, 1048592, 1073741840, 0, 1073741824, 32784, 1048576, 1074790416, 32768, 1073741824, 1081360, 1073774608, 1074823168, 32768, 0, 1073741840, 16, 1074823184, 1081344, 1074790400, 1074790416, 1048576, 32784, 1073774592, 1073774608, 16, 1074790400, 1081344, 67108865, 67371264, 256, 67109121, 262145, 67108864, 67109121, 262400, 67109120, 262144, 67371008, 1, 67371265, 257, 1, 67371009, 0, 262145, 67371264, 256, 257, 67371265, 262144, 67108865, 67371009, 67109120, 262401, 67371008, 262400, 0, 67108864, 262401, 67371264, 256, 1, 262144, 257, 262145, 67371008, 67109121, 0, 67371264, 262400, 67371009, 262145, 67108864, 67371265, 1, 262401, 67108865, 67108864, 67371265, 262144, 67109120, 67109121, 262400, 67109120, 0, 67371009, 257, 67108865, 262401, 256, 67371008, 4198408, 268439552, 8, 272633864, 0, 272629760, 268439560, 4194312, 272633856, 268435464, 268435456, 4104, 268435464, 4198408, 4194304, 268435456, 272629768, 4198400, 4096, 8, 4198400, 268439560, 272629760, 4096, 4104, 0, 4194312, 272633856, 268439552, 272629768, 272633864, 4194304, 272629768, 4104, 4194304, 268435464, 4198400, 268439552, 8, 272629760, 268439560, 0, 4096, 4194312, 0, 272629768, 272633856, 4096, 268435456, 272633864, 4198408, 4194304, 272633864, 8, 268439552, 4198408, 4194312, 4198400, 272629760, 268439560, 4104, 268435456, 268435464, 272633856, 134217728, 65536, 1024, 134284320, 134283296, 134218752, 66592, 134283264, 65536, 32, 134217760, 66560, 134218784, 134283296, 134284288, 0, 66560, 134217728, 65568, 1056, 134218752, 66592, 0, 134217760, 32, 134218784, 134284320, 65568, 134283264, 1024, 1056, 134284288, 134284288, 134218784, 65568, 134283264, 65536, 32, 134217760, 134218752, 134217728, 66560, 134284320, 0, 66592, 134217728, 1024, 65568, 134218784, 1024, 0, 134284320, 134283296, 134284288, 1056, 65536, 66560, 134283296, 134218752, 1056, 32, 66592, 134283264, 134217760, -2147483584, 2097216, 0, -2145378304, 2097216, 8192, -2147475392, 2097152, 8256, -2145378240, 2105344, Integer.MIN_VALUE, -2147475456, -2147483584, -2145386496, 2105408, 2097152, -2147475392, -2145386432, 0, 8192, 64, -2145378304, -2145386432, -2145378240, -2145386496, Integer.MIN_VALUE, 8256, 64, 2105344, 2105408, -2147475456, 8256, Integer.MIN_VALUE, -2147475456, 2105408, -2145378304, 2097216, 0, -2147475456, Integer.MIN_VALUE, 8192, -2145386432, 2097152, 2097216, -2145378240, 2105344, 64, -2145378240, 2105344, 2097152, -2147475392, -2147483584, -2145386496, 2105408, 0, 8192, -2147483584, -2147475392, -2145378304, -2145386496, 8256, 64, -2145386432, 16384, 512, 16777728, 16777220, 16794116, 16388, 16896, 0, 16777216, 16777732, 516, 16793600, 4, 16794112, 16793600, 516, 16777732, 16384, 16388, 16794116, 0, 16777728, 16777220, 16896, 16793604, 16900, 16794112, 4, 16900, 16793604, 512, 16777216, 16900, 16793600, 16793604, 516, 16384, 512, 16777216, 16793604, 16777732, 16900, 16896, 0, 512, 16777220, 4, 16777728, 0, 16777732, 16777728, 16896, 516, 16384, 16794116, 16777216, 16794112, 4, 16388, 16794116, 16777220, 16794112, 16793600, 16388, 545259648, 545390592, 131200, 0, 537001984, 8388736, 545259520, 545390720, 128, 536870912, 8519680, 131200, 8519808, 537002112, 536871040, 545259520, 131072, 8519808, 8388736, 537001984, 545390720, 536871040, 0, 8519680, 536870912, 8388608, 537002112, 545259648, 8388608, 131072, 545390592, 128, 8388608, 131072, 536871040, 545390720, 131200, 536870912, 0, 8519680, 545259648, 537002112, 537001984, 8388736, 545390592, 128, 8388736, 537001984, 545390720, 8388608, 545259520, 536871040, 8519680, 131200, 537002112, 545259520, 128, 545390592, 8519808, 0, 536870912, 545259648, 131072, 8519808};
    private static final byte[][] MASKS = {new byte[64], paddedAscii("Nikzworldofficial"), paddedAscii("89bbd133503c996c"), paddedAscii("JAMESGAMING01"), paddedAscii("2khuslherz")};
    private static final String[] MODE_NAMES = {"ORIGINAL", "NIKZ", "LEGACY", "JAMES", "2KHUZLERS"};

    public static final class Decoded {
        public final int compressedSize;
        public final int containerTag;
        public final byte[] cryptoMask;
        public final String cryptoMode;
        public final int formatVersion;
        public final int payloadSize;
        public final byte[] raw;
        public final String rawSha256;
        public final int rosterUid;
        public final long storedChecksum;

        Decoded(int i, int i2, int i3, int i4, long j, int i5, String str, byte[] bArr, byte[] bArr2, String str2) {
            this.containerTag = i;
            this.formatVersion = i2;
            this.payloadSize = i3;
            this.rosterUid = i4;
            this.storedChecksum = j;
            this.compressedSize = i5;
            this.cryptoMode = str;
            this.cryptoMask = bArr == null ? new byte[64] : (byte[]) bArr.clone();
            this.raw = bArr2;
            this.rawSha256 = str2;
        }
    }

    private static boolean hasModWrapper(byte[] bArr) {
        return bArr != null && bArr.length >= 40 && readBe32(bArr, 16) == 305419947 && (readBe32(bArr, 12) ^ 305419947) == bArr.length + (-24);
    }

    private static byte[] toggleModWrapper(byte[] bArr) {
        byte[] bArr2 = (byte[]) bArr.clone();
        int[] iArr = {18, 52, 86, 171};
        for (int i = 0; i < bArr2.length; i++) {
            int i2 = i;
            bArr2[i2] = (byte) (bArr2[i2] ^ iArr[i & 3]);
        }
        return bArr2;
    }

    public static Decoded decode(byte[] bArr) throws IOException {
        return decode(bArr, (String[]) null);
    }

    public static Decoded decode(byte[] bArr, String... strArr) throws IOException {
        Decoded decodedTryDecodeCandidate;
        byte[] bArr2 = bArr;
        if (hasModWrapper(bArr2)) {
            bArr2 = toggleModWrapper(bArr2);
        }
        if (bArr2 == null || bArr2.length < 40) {
            throw new IOException("Roster file is too small.");
        }
        int be32 = readBe32(bArr2, 4);
        int be322 = readBe32(bArr2, 8);
        int be323 = readBe32(bArr2, 12);
        int be324 = readBe32(bArr2, 16);
        int be325 = readBe32(bArr2, 20);
        if (be323 != bArr2.length - 24) {
            throw new IOException("Roster/Career payload length does not match the file header.");
        }
        if (be324 != 0) {
            throw new IOException("Unsupported roster/career header variant.");
        }
        if (be323 < 16 || (be323 & 7) != 0) {
            throw new IOException("Encrypted roster/career payload is not 8-byte aligned.");
        }
        byte[] bArrCopyOfRange = Arrays.copyOfRange(bArr2, 24, bArr2.length);
        for (int i = 0; i < MASKS.length; i++) {
            Decoded decodedTryDecodeCandidate2 = tryDecodeCandidate(be32, be322, be323, be325, bArrCopyOfRange, MASKS[i], MODE_NAMES[i]);
            if (decodedTryDecodeCandidate2 != null) {
                return decodedTryDecodeCandidate2;
            }
        }
        if (strArr != null) {
            for (String str : strArr) {
                if (str != null) {
                    String strTrim = str.trim();
                    if (strTrim.length() != 0) {
                        if (strTrim.length() > 64) {
                            strTrim = strTrim.substring(0, 64);
                        }
                        byte[] bArrPaddedAscii = paddedAscii(strTrim);
                        if (!isBuiltInMask(bArrPaddedAscii) && (decodedTryDecodeCandidate = tryDecodeCandidate(be32, be322, be323, be325, bArrCopyOfRange, bArrPaddedAscii, "ANDROID_ID")) != null) {
                            return decodedTryDecodeCandidate;
                        }
                    } else {
                        continue;
                    }
                }
            }
        }
        throw new IOException("Could not identify the roster crypto schedule.");
    }

    private static boolean isBuiltInMask(byte[] bArr) {
        for (int i = 0; i < MASKS.length; i++) {
            if (Arrays.equals(MASKS[i], bArr)) {
                return true;
            }
        }
        return false;
    }

    private static Decoded tryDecodeCandidate(int i, int i2, int i3, int i4, byte[] bArr, byte[] bArr2, String str) {
        Decoded decoded;
        try {
            byte[] bArrDecryptCbc = decryptCbc(bArr, BASE_SCHEDULE, BASE_SCHEDULE, applyMask(BASE_SCHEDULE, bArr2));
            if (bArrDecryptCbc.length < 18 || !looksLikeZlib(bArrDecryptCbc[16] & 255, bArrDecryptCbc[17] & 255)) {
                decoded = (Decoded) null;
            } else {
                long le32Unsigned = readLe32Unsigned(bArrDecryptCbc, 8);
                int le32 = readLe32(bArrDecryptCbc, 12);
                if (le32 <= 0 || le32 > bArrDecryptCbc.length - 16) {
                    decoded = (Decoded) null;
                } else {
                    byte[] bArrInflate = inflate(bArrDecryptCbc, 16, le32);
                    decoded = bArrInflate.length == 0 ? (Decoded) null : new Decoded(i, i2, i3, i4, le32Unsigned, le32, str, bArr2, bArrInflate, sha256(bArrInflate));
                }
            }
            return decoded;
        } catch (Exception e) {
            return (Decoded) null;
        }
    }

    public static byte[] encode(byte[] bArr, byte[] bArr2) throws IOException {
        return encode(bArr, bArr2, decode(bArr).cryptoMask);
    }

    public static byte[] encode(byte[] bArr, byte[] bArr2, byte[] bArr3) throws IOException {
        if (hasModWrapper(bArr)) {
            return toggleModWrapper(encode(toggleModWrapper(bArr), bArr2, bArr3));
        }
        if (bArr == null || bArr.length < 40) {
            throw new IOException("Original roster file is missing.");
        }
        if (bArr2 == null || bArr2.length < 1024) {
            throw new IOException("Edited roster payload is empty.");
        }
        if (bArr3 == null || bArr3.length != 64) {
            throw new IOException("Roster crypto mask is missing.");
        }
        int be32 = readBe32(bArr, 4);
        int be322 = readBe32(bArr, 8);
        int be323 = readBe32(bArr, 12);
        int be324 = readBe32(bArr, 20);
        if (be323 != bArr.length - 24) {
            throw new IOException("Roster/Career payload length does not match the file header.");
        }
        if (tryDecodeCandidate(be32, be322, be323, be324, Arrays.copyOfRange(bArr, 24, bArr.length), bArr3, "SOURCE") == null) {
            throw new IOException("Roster crypto mask no longer matches the source file.");
        }
        int[] iArrApplyMask = applyMask(BASE_SCHEDULE, bArr3);
        byte[] bArrDeflateLevel9 = deflateLevel9(bArr2);
        int iAlign32 = align32(16 + bArrDeflateLevel9.length);
        if (iAlign32 < 32) {
            throw new IOException("Rebuilt roster/career payload is too small.");
        }
        byte[] bArr4 = new byte[iAlign32];
        System.arraycopy(bArr, 24, bArr4, 0, 8);
        writeLe32(bArr4, 12, bArrDeflateLevel9.length);
        System.arraycopy(bArrDeflateLevel9, 0, bArr4, 16, bArrDeflateLevel9.length);
        CRC32 crc32 = new CRC32();
        crc32.update(bArr4, 12, bArr4.length - 12);
        writeLe32(bArr4, 8, (int) crc32.getValue());
        byte[] bArrEncryptCbc = encryptCbc(bArr4, BASE_SCHEDULE, BASE_SCHEDULE, iArrApplyMask);
        byte[] bArr5 = new byte[24 + bArrEncryptCbc.length];
        System.arraycopy(bArr, 0, bArr5, 0, 24);
        writeBe32(bArr5, 12, bArrEncryptCbc.length);
        writeBe32(bArr5, 16, 0);
        System.arraycopy(bArrEncryptCbc, 0, bArr5, 24, bArrEncryptCbc.length);
        CRC32 crc322 = new CRC32();
        crc322.update(bArr5, 4, bArrEncryptCbc.length - 4);
        writeBe32(bArr5, 0, (int) crc322.getValue());
        Decoded decodedTryDecodeCandidate = tryDecodeCandidate(readBe32(bArr5, 4), readBe32(bArr5, 8), readBe32(bArr5, 12), readBe32(bArr5, 20), Arrays.copyOfRange(bArr5, 24, bArr5.length), bArr3, "SOURCE");
        if (decodedTryDecodeCandidate == null || !Arrays.equals(decodedTryDecodeCandidate.raw, bArr2)) {
            throw new IOException("Roster/Career save verification failed after re-decode.");
        }
        return bArr5;
    }

    private static byte[] deflateLevel9(byte[] bArr) throws IOException {
        Deflater deflater = new Deflater(9, false);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(Math.max(1024, bArr.length / 3));
        try {
            deflater.setInput(bArr);
            deflater.finish();
            byte[] bArr2 = new byte[65536];
            while (true) {
                if (deflater.finished()) {
                    break;
                }
                int iDeflate = deflater.deflate(bArr2);
                if (iDeflate > 0) {
                    byteArrayOutputStream.write(bArr2, 0, iDeflate);
                } else if (!deflater.needsInput()) {
                    throw new IOException("Roster compression stalled.");
                }
            }
            if (!deflater.finished()) {
                throw new IOException("Roster compression ended early.");
            }
            byte[] byteArray = byteArrayOutputStream.toByteArray();
            deflater.end();
            try {
                byteArrayOutputStream.close();
            } catch (Exception e) {
            }
            return byteArray;
        } catch (Throwable th) {
            deflater.end();
            try {
                byteArrayOutputStream.close();
            } catch (Exception e2) {
            }
            throw th;
        }
    }

    private static byte[] encryptCbc(byte[] bArr, int[] iArr, int[] iArr2, int[] iArr3) throws IOException {
        if (bArr.length < 16 || (bArr.length & 7) != 0) {
            throw new IOException("Invalid plain roster payload.");
        }
        byte[] bArr2 = (byte[]) bArr.clone();
        byte[] bArrCopyOfRange = Arrays.copyOfRange(bArr, 0, 8);
        byte[] bArr3 = new byte[8];
        int i = 8;
        while (true) {
            int i2 = i;
            if (i2 < bArr.length) {
                for (int i3 = 0; i3 < 8; i3++) {
                    bArr3[i3] = (byte) (bArr[i2 + i3] ^ bArrCopyOfRange[i3]);
                }
                byte[] bArrEncrypt3Block = encrypt3Block(bArr3, iArr, iArr2, iArr3);
                System.arraycopy(bArrEncrypt3Block, 0, bArr2, i2, 8);
                System.arraycopy(bArrEncrypt3Block, 0, bArrCopyOfRange, 0, 8);
                i = i2 + 8;
            } else {
                return bArr2;
            }
        }
    }

    private static byte[] encrypt3Block(byte[] bArr, int[] iArr, int[] iArr2, int[] iArr3) {
        int[] iArrIp = ip(readLe32(bArr, 0), readLe32(bArr, 4));
        int[] iArrEnc2 = enc2(iArrIp[0], iArrIp[1], iArr, true);
        int[] iArrEnc22 = enc2(iArrEnc2[0], iArrEnc2[1], iArr2, false);
        int[] iArrEnc23 = enc2(iArrEnc22[0], iArrEnc22[1], iArr3, true);
        int[] iArrFp = fp(iArrEnc23[0], iArrEnc23[1]);
        byte[] bArr2 = new byte[8];
        writeLe32(bArr2, 0, iArrFp[0]);
        writeLe32(bArr2, 4, iArrFp[1]);
        return bArr2;
    }

    private static int modeIndex(String str) throws IOException {
        for (int i = 0; i < MODE_NAMES.length; i++) {
            if (MODE_NAMES[i].equals(str)) {
                return i;
            }
        }
        throw new IOException(new StringBuffer().append("Unknown roster crypto mode: ").append(str).toString());
    }

    private static int align32(int i) {
        return (i + 31) & (-32);
    }

    private static byte[] decryptCbc(byte[] bArr, int[] iArr, int[] iArr2, int[] iArr3) throws IOException {
        if (bArr.length < 16 || (bArr.length & 7) != 0) {
            throw new IOException("Invalid encrypted roster payload.");
        }
        byte[] bArr2 = (byte[]) bArr.clone();
        byte[] bArrCopyOfRange = Arrays.copyOfRange(bArr, 0, 8);
        byte[] bArr3 = new byte[8];
        int i = 8;
        while (true) {
            int i2 = i;
            if (i2 < bArr.length) {
                System.arraycopy(bArr, i2, bArr3, 0, 8);
                byte[] bArrDecrypt3Block = decrypt3Block(bArr3, iArr, iArr2, iArr3);
                for (int i3 = 0; i3 < 8; i3++) {
                    bArr2[i2 + i3] = (byte) ((bArrDecrypt3Block[i3] ^ bArrCopyOfRange[i3]) & 255);
                }
                System.arraycopy(bArr3, 0, bArrCopyOfRange, 0, 8);
                i = i2 + 8;
            } else {
                return bArr2;
            }
        }
    }

    private static byte[] decrypt3Block(byte[] bArr, int[] iArr, int[] iArr2, int[] iArr3) {
        int[] iArrIp = ip(readLe32(bArr, 0), readLe32(bArr, 4));
        int[] iArrEnc2 = enc2(iArrIp[0], iArrIp[1], iArr3, false);
        int[] iArrEnc22 = enc2(iArrEnc2[0], iArrEnc2[1], iArr2, true);
        int[] iArrEnc23 = enc2(iArrEnc22[0], iArrEnc22[1], iArr, false);
        int[] iArrFp = fp(iArrEnc23[0], iArrEnc23[1]);
        byte[] bArr2 = new byte[8];
        writeLe32(bArr2, 0, iArrFp[0]);
        writeLe32(bArr2, 4, iArrFp[1]);
        return bArr2;
    }

    private static int f(int i, int i2, int i3) {
        int i4 = i ^ i2;
        int iRotateRight = Integer.rotateRight(i ^ i3, 4);
        return ((((((SP[(i4 >>> 2) & 63] ^ SP[128 + ((i4 >>> 10) & 63)]) ^ SP[256 + ((i4 >>> 18) & 63)]) ^ SP[384 + ((i4 >>> 26) & 63)]) ^ SP[64 + ((iRotateRight >>> 2) & 63)]) ^ SP[192 + ((iRotateRight >>> 10) & 63)]) ^ SP[320 + ((iRotateRight >>> 18) & 63)]) ^ SP[448 + ((iRotateRight >>> 26) & 63)];
    }

    private static int[] enc2(int i, int i2, int[] iArr, boolean z) {
        int iRotateRight = Integer.rotateRight(i, 29);
        int iRotateRight2 = Integer.rotateRight(i2, 29);
        boolean z2 = false;
        if (z) {
            for (int i3 = 0; i3 < 16; i3++) {
                if (!z2) {
                    iRotateRight2 ^= f(iRotateRight, iArr[i3 * 2], iArr[(i3 * 2) + 1]);
                } else {
                    iRotateRight ^= f(iRotateRight2, iArr[i3 * 2], iArr[(i3 * 2) + 1]);
                }
                z2 = !z2;
            }
        } else {
            for (int i4 = 15; i4 >= 0; i4--) {
                if (!z2) {
                    iRotateRight2 ^= f(iRotateRight, iArr[i4 * 2], iArr[(i4 * 2) + 1]);
                } else {
                    iRotateRight ^= f(iRotateRight2, iArr[i4 * 2], iArr[(i4 * 2) + 1]);
                }
                z2 = !z2;
            }
        }
        return new int[]{Integer.rotateRight(iRotateRight2, 3), Integer.rotateRight(iRotateRight, 3)};
    }

    private static int[] ip(int i, int i2) {
        int i3 = (i ^ (i2 >>> 4)) & 252645135;
        int i4 = i ^ i3;
        int i5 = i2 ^ (i3 << 4);
        int i6 = (i5 ^ (i4 >>> 16)) & 65535;
        int i7 = i5 ^ i6;
        int i8 = i4 ^ (i6 << 16);
        int i9 = (i8 ^ (i7 >>> 2)) & 858993459;
        int i10 = i8 ^ i9;
        int i11 = i7 ^ (i9 << 2);
        int i12 = (i11 ^ (i10 >>> 8)) & 16711935;
        int i13 = i11 ^ i12;
        int i14 = i10 ^ (i12 << 8);
        int i15 = (i14 ^ (i13 >>> 1)) & 1431655765;
        return new int[]{i14 ^ i15, i13 ^ (i15 << 1)};
    }

    private static int[] fp(int i, int i2) {
        int i3 = (i ^ (i2 >>> 1)) & 1431655765;
        int i4 = i ^ i3;
        int i5 = i2 ^ (i3 << 1);
        int i6 = (i5 ^ (i4 >>> 8)) & 16711935;
        int i7 = i5 ^ i6;
        int i8 = i4 ^ (i6 << 8);
        int i9 = (i8 ^ (i7 >>> 2)) & 858993459;
        int i10 = i8 ^ i9;
        int i11 = i7 ^ (i9 << 2);
        int i12 = (i11 ^ (i10 >>> 16)) & 65535;
        int i13 = i11 ^ i12;
        int i14 = i10 ^ (i12 << 16);
        int i15 = (i14 ^ (i13 >>> 4)) & 252645135;
        return new int[]{i14 ^ i15, i13 ^ (i15 << 4)};
    }

    private static int[] applyMask(int[] iArr, byte[] bArr) {
        int[] iArr2 = (int[]) iArr.clone();
        for (int i = 0; i < 16; i++) {
            int le32 = readLe32(bArr, i * 4);
            iArr2[i * 2] = iArr[i * 2] ^ le32;
            iArr2[(i * 2) + 1] = iArr[(i * 2) + 1] ^ le32;
        }
        return iArr2;
    }

    private static byte[] inflate(byte[] bArr, int i, int i2) throws IOException {
        Inflater inflater = new Inflater();
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(Math.min(i2 * 3, 8388608));
        try {
            inflater.setInput(bArr, i, i2);
            byte[] bArr2 = new byte[65536];
            int i3 = 0;
            do {
                if (!inflater.finished()) {
                    try {
                        int iInflate = inflater.inflate(bArr2);
                        if (iInflate > 0) {
                            byteArrayOutputStream.write(bArr2, 0, iInflate);
                            i3 += iInflate;
                        } else {
                            if (inflater.needsDictionary()) {
                                throw new IOException("Roster payload requires an unsupported zlib dictionary.");
                            }
                            if (!inflater.needsInput()) {
                                throw new IOException("Roster decompression stalled.");
                            }
                        }
                    } catch (DataFormatException e) {
                        throw new IOException("Invalid compressed roster payload.");
                    }
                }
                if (!inflater.finished()) {
                    throw new IOException("Roster zlib stream ended early.");
                }
                byte[] byteArray = byteArrayOutputStream.toByteArray();
                inflater.end();
                try {
                    byteArrayOutputStream.close();
                } catch (Exception e2) {
                }
                return byteArray;
            } while (i3 <= 67108864);
            throw new IOException("Decoded roster payload is unexpectedly large.");
        } catch (Throwable th) {
            inflater.end();
            try {
                byteArrayOutputStream.close();
            } catch (Exception e3) {
            }
            throw th;
        }
    }

    private static boolean looksLikeZlib(int i, int i2) {
        return i == 120 && (i2 == 218 || i2 == 156 || i2 == 1 || i2 == 94);
    }

    private static byte[] paddedAscii(String str) {
        byte[] bArr = new byte[64];
        try {
            byte[] bytes = str.getBytes("US-ASCII");
            System.arraycopy(bytes, 0, bArr, 0, Math.min(bytes.length, bArr.length));
        } catch (Exception e) {
        }
        return bArr;
    }

    private static void writeBe32(byte[] bArr, int i, int i2) {
        bArr[i] = (byte) (i2 >>> 24);
        bArr[i + 1] = (byte) (i2 >>> 16);
        bArr[i + 2] = (byte) (i2 >>> 8);
        bArr[i + 3] = (byte) i2;
    }

    private static int readBe32(byte[] bArr, int i) {
        return ((bArr[i] & 255) << 24) | ((bArr[i + 1] & 255) << 16) | ((bArr[i + 2] & 255) << 8) | (bArr[i + 3] & 255);
    }

    private static int readLe32(byte[] bArr, int i) {
        return (bArr[i] & 255) | ((bArr[i + 1] & 255) << 8) | ((bArr[i + 2] & 255) << 16) | ((bArr[i + 3] & 255) << 24);
    }

    private static long readLe32Unsigned(byte[] bArr, int i) {
        return ((long) readLe32(bArr, i)) & 4294967295L;
    }

    private static void writeLe32(byte[] bArr, int i, int i2) {
        bArr[i] = (byte) i2;
        bArr[i + 1] = (byte) (i2 >>> 8);
        bArr[i + 2] = (byte) (i2 >>> 16);
        bArr[i + 3] = (byte) (i2 >>> 24);
    }

    private static String sha256(byte[] bArr) throws IOException {
        try {
            byte[] bArrDigest = MessageDigest.getInstance("SHA-256").digest(bArr);
            StringBuilder sb = new StringBuilder(bArrDigest.length * 2);
            for (byte b : bArrDigest) {
                sb.append(String.format("%02x", new Integer(b & 255)));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new IOException("SHA-256 is not available.");
        }
    }

    RosterCrypto() {
    }
}
