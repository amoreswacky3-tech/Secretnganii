package com.nocluetools.prov1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TextureListActivity extends Activity {

    TextView texListTitle;
    ListView texList;
    Button texListClose;

    List<String> textureNames = new ArrayList<>();
    ArrayAdapter<String> adapter;
    
    String sessionId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_texture_list); // Use your XML filename here

        texListTitle = findViewById(R.id.texListTitle);
        texList = findViewById(R.id.texList);
        texListClose = findViewById(R.id.texListClose);

        // Get the session ID passed from the previous screen
        sessionId = getIntent().getStringExtra("SESSION_ID");

        if (sessionId == null) {
            Toast.makeText(this, "Error: No session ID provided", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Setup buttons
        texListClose.setOnClickListener(v -> finish());

        // 🚨 When a user taps a texture, send the result back
        texList.setOnItemClickListener((parent, view, position, id) -> {
            String selectedTextureName = adapter.getItem(position);
            
            Intent returnIntent = new Intent();
            returnIntent.putExtra("SELECTED_TEXTURE_INDEX", position);
            returnIntent.putExtra("SELECTED_TEXTURE_NAME", selectedTextureName);
            
            setResult(Activity.RESULT_OK, returnIntent);
            finish(); // Close the list and return to the previous screen
        });

        // Load the data from Python
        loadTexturesFromPython();
    }

    private void loadTexturesFromPython() {
        texListTitle.setText("LOADING TEXTURES...");

        new Thread(() -> {
            try {
                if (!Python.isStarted()) {
                    Python.start(new AndroidPlatform(this));
                }
                Python py = Python.getInstance();
                PyObject bridge = py.getModule("noclue2k_bridge");

                // 🚨 Call your Python function to get the texture list for this session
                // (Assuming you have a function like 'session_summary_bridge' or 'list_textures_bridge')
                PyObject result = bridge.callAttr("session_summary_bridge", sessionId);
                String jsonString = result.toString();

                JSONObject json = new JSONObject(jsonString);
                
                if (json.getBoolean("ok")) {
                    JSONArray texturesArray = json.optJSONArray("textures");
                    
                    if (texturesArray != null) {
                        for (int i = 0; i < texturesArray.length(); i++) {
                            JSONObject tex = texturesArray.getJSONObject(i);
                            // Format it nicely: "#0 · 128x128 · ETC2"
                            String displayName = "#" + i + " · " + 
                                    tex.optString("width", "?") + "x" + tex.optString("height", "?") + 
                                    " · " + tex.optString("format", "UNKNOWN");
                            
                            // If the python returns a real name, use that instead
                            if (tex.has("name") && !tex.isNull("name")) {
                                displayName = "#" + i + " · " + tex.getString("name");
                            }
                            
                            textureNames.add(displayName);
                        }
                    }
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Python Error: " + json.optString("error"), Toast.LENGTH_LONG).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Exception: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }

            // Update UI
            runOnUiThread(() -> {
                texListTitle.setText("TEXTURES (" + textureNames.size() + ")");
                
                if (textureNames.isEmpty()) {
                    textureNames.add("No textures found.");
                }
                
                // Note: You can replace this with your custom TextureAdapter if you want the fancy rows!
                adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, textureNames);
                texList.setAdapter(adapter);
            });
        }).start();
    }
}