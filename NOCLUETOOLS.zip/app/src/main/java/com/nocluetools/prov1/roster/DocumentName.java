package com.nocluetools.prov1.roster;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;

/* JADX INFO: loaded from: classes.dex */
public final class DocumentName {
    public static String read(ContentResolver contentResolver, Uri uri) {
        int columnIndex;
        Cursor cursorQuery = (Cursor) null;
        try {
            cursorQuery = contentResolver.query(uri, new String[]{"_display_name"}, (String) null, (String[]) null, (String) null);
            if (cursorQuery != null && cursorQuery.moveToFirst() && (columnIndex = cursorQuery.getColumnIndex("_display_name")) >= 0) {
                String string = cursorQuery.getString(columnIndex);
                if (cursorQuery != null) {
                    cursorQuery.close();
                }
                return string;
            }
        } catch (Exception e) {
        } catch (Throwable th) {
            if (cursorQuery != null) {
                cursorQuery.close();
            }
            throw th;
        }
        if (cursorQuery != null) {
            cursorQuery.close();
        }
        String lastPathSegment = uri.getLastPathSegment();
        return lastPathSegment == null ? "Roster" : lastPathSegment;
    }

    DocumentName() {
    }
}
