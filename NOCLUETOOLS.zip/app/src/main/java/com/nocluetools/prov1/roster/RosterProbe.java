package com.nocluetools.prov1.roster;

import android.content.ContentResolver;
import android.net.Uri;
import android.provider.Settings;
import com.nocluetools.prov1.roster.RosterCrypto;
import com.nocluetools.prov1.roster.RosterPlayerMap;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public final class RosterProbe {

    public static final class Result {
        public List<RosterPlayerMap.TeamRecord> activeTeams;
        public final int compressedSize;
        public final int containerTag;
        public final byte[] cryptoMask;
        public final String cryptoMode;
        public final int decodedRawSize;
        public final int encryptedPayloadSize;
        public final int formatVersion;
        public List<Integer> literalCyberfaceIds;
        public final boolean myCareerContainer;
        public long playerTableBitOffset;
        public boolean playerTableMapped;
        public List<RosterPlayerMap.PlayerRecord> players;
        public byte[] raw;
        public final String rawSha256;
        public final int rosterUid;
        public int serializedTeamCount;
        public final long size;
        public final byte[] sourceFile;
        public final long storedChecksum;
        public long teamTableBitOffset;
        public boolean teamTableMapped;

        Result(byte[] bArr, RosterCrypto.Decoded decoded) throws IOException {
            this.sourceFile = bArr;
            this.raw = (byte[]) decoded.raw.clone();
            this.size = bArr.length;
            this.formatVersion = decoded.formatVersion;
            this.containerTag = decoded.containerTag;
            this.rosterUid = decoded.rosterUid;
            this.storedChecksum = decoded.storedChecksum;
            this.encryptedPayloadSize = decoded.payloadSize;
            this.compressedSize = decoded.compressedSize;
            this.decodedRawSize = decoded.raw.length;
            this.cryptoMode = decoded.cryptoMode;
            this.cryptoMask = (byte[]) decoded.cryptoMask.clone();
            this.rawSha256 = decoded.rawSha256;
            this.myCareerContainer = decoded.formatVersion >= 17;
            refreshMapping();
        }

        public void refreshMapping() throws IOException {
            RosterPlayerMap.Result result = RosterPlayerMap.parse(this.raw);
            this.playerTableMapped = true;
            this.teamTableMapped = true;
            this.playerTableBitOffset = result.playerTableBitOffset;
            this.teamTableBitOffset = result.teamTableBitOffset;
            this.serializedTeamCount = result.serializedTeamCount;
            this.players = result.players;
            this.activeTeams = result.activeTeams;
            ArrayList arrayList = new ArrayList();
            for (RosterPlayerMap.PlayerRecord playerRecord : result.players) {
                if (playerRecord.hasUsableCyberfaceId()) {
                    arrayList.add(Integer.valueOf(playerRecord.cyberfaceId));
                }
            }
            this.literalCyberfaceIds = arrayList;
        }
    }

    public static Result inspectBytes(byte[] bArr) throws IOException {
        if (bArr == null || bArr.length < 40) {
            throw new IOException("Roster file is too small.");
        }
        return new Result((byte[]) bArr.clone(), RosterCrypto.decode(bArr));
    }

    public static Result inspectBytes(byte[] bArr, String str) throws IOException {
        if (bArr == null || bArr.length < 40) {
            throw new IOException("Roster file is too small.");
        }
        return new Result((byte[]) bArr.clone(), RosterCrypto.decode(bArr, idVariants(str)));
    }

    public static Result inspect(ContentResolver contentResolver, Uri uri) throws IOException {
        byte[] all = readAll(contentResolver, uri);
        return new Result((byte[]) all.clone(), RosterCrypto.decode(all, idVariants(Settings.Secure.getString(contentResolver, "android_id"))));
    }

    public static Result inspect(ContentResolver contentResolver, Uri uri, String str) throws IOException {
        byte[] all = readAll(contentResolver, uri);
        String[] strArrIdVariants = idVariants(Settings.Secure.getString(contentResolver, "android_id"));
        String[] strArrIdVariants2 = idVariants(str);
        String[] strArr = new String[strArrIdVariants.length + strArrIdVariants2.length];
        System.arraycopy(strArrIdVariants, 0, strArr, 0, strArrIdVariants.length);
        System.arraycopy(strArrIdVariants2, 0, strArr, strArrIdVariants.length, strArrIdVariants2.length);
        return new Result((byte[]) all.clone(), RosterCrypto.decode(all, strArr));
    }

    private static String[] idVariants(String str) {
        if (str == null) {
            return new String[0];
        }
        String strTrim = str.trim();
        if (strTrim.length() == 0) {
            return new String[0];
        }
        String lowerCase = strTrim.toLowerCase(Locale.US);
        String upperCase = strTrim.toUpperCase(Locale.US);
        return (lowerCase.equals(strTrim) && upperCase.equals(strTrim)) ? new String[]{strTrim} : lowerCase.equals(strTrim) ? new String[]{strTrim, upperCase} : upperCase.equals(strTrim) ? new String[]{strTrim, lowerCase} : new String[]{strTrim, lowerCase, upperCase};
    }

    private static byte[] readAll(ContentResolver contentResolver, Uri uri) throws IOException {
        InputStream inputStream = (InputStream) null;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            InputStream inputStreamOpenInputStream = contentResolver.openInputStream(uri);
            if (inputStreamOpenInputStream == null) {
                throw new IOException("Could not open roster.");
            }
            byte[] bArr = new byte[262144];
            do {
                int i = inputStreamOpenInputStream.read(bArr);
                if (i == -1) {
                    byte[] byteArray = byteArrayOutputStream.toByteArray();
                    if (inputStreamOpenInputStream != null) {
                        try {
                            inputStreamOpenInputStream.close();
                        } catch (Exception e) {
                        }
                    }
                    try {
                        byteArrayOutputStream.close();
                    } catch (Exception e2) {
                    }
                    return byteArray;
                }
                if (i > 0) {
                    byteArrayOutputStream.write(bArr, 0, i);
                }
            } while (byteArrayOutputStream.size() <= 134217728);
            throw new IOException("Roster file is unexpectedly large.");
        } catch (Throwable th) {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (Exception e3) {
                }
            }
            try {
                byteArrayOutputStream.close();
            } catch (Exception e4) {
            }
            throw th;
        }
    }

    RosterProbe() {
    }
}
