package com.nocluetools.prov1;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class IffOpenerActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Create a simple text view programmatically (no XML needed for this test)
        TextView tv = new TextView(this);
        tv.setTextColor(0xFFFFFFFF);
        tv.setTextSize(18f);
        tv.setPadding(50, 50, 50, 50);
        setContentView(tv);

        try {
            // 1. Start the Python engine
            if (!Python.isStarted()) {
                Python.start(new AndroidPlatform(this));
            }
            
            Python py = Python.getInstance();
            
            // 2. Load your renamed Python file (noclue2k.py)
            PyObject bridge = py.getModule("noclue2k"); 
            
            // 3. Call a simple function to prove it works
            // We will just show a success message on the screen
            tv.setText("SUCCESS!\n\nPython Engine Connected.\nBridge Loaded: " + bridge.toString() + "\n\nReady to mod!");
            
        } catch (Exception e) {
            // If it fails, show the error on the screen!
            tv.setText("ERROR LOADING PYTHON:\n\n" + e.getMessage());
        }
    }
}