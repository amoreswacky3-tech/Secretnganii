package com.nocluetools.prov1.roster;

/* JADX INFO: loaded from: classes.dex */
final class PlayerValueClipboard {
    static final int ATTRIBUTES = 0;
    static final int TENDENCIES = 1;
    private final int[][] values = new int[2][];
    private final String[] sources = new String[2];

    void copy(int i, int[] iArr, String str) {
        validate(i, iArr);
        this.values[i] = (int[]) iArr.clone();
        this.sources[i] = str == null ? "Player" : str;
    }

    int[] paste(int i) {
        checkKind(i);
        if (this.values[i] == null) {
            throw new IllegalStateException("Copy from a player first.");
        }
        return (int[]) this.values[i].clone();
    }

    String source(int i) {
        checkKind(i);
        return this.sources[i];
    }

    private static void checkKind(int i) {
        if (i != 0 && i != TENDENCIES) {
            throw new IllegalArgumentException("Invalid group.");
        }
    }

    private static void validate(int i, int[] iArr) {
        checkKind(i);
        int length = i == 0 ? RosterEditor.RATING_FIELDS.length : RosterEditor.TENDENCY_FIELDS.length;
        int i2 = i == 0 ? 25 : 0;
        int i3 = i == 0 ? 99 : 100;
        if (iArr == null || iArr.length != length) {
            throw new IllegalArgumentException("Incomplete player values.");
        }
        for (int i4 = 0; i4 < iArr.length; i4 += TENDENCIES) {
            int i5 = iArr[i4];
            if (i5 < i2 || i5 > i3) {
                throw new IllegalArgumentException(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append("Values must be ").append(i2).toString()).append("-").toString()).append(i3).toString()).append(".").toString());
            }
        }
    }
}
