package com.nocluetools.prov1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class TextureRowAdapter extends BaseAdapter {

    private Context context;
    private List<TextureItem> items;
    private LayoutInflater inflater;

    // Simple class to hold the data for one texture row
    public static class TextureItem {
        public String title;
        public String chip;
        public String meta;

        public TextureItem(String title, String chip, String meta) {
            this.title = title;
            this.chip = chip;
            this.meta = meta;
        }
    }

    public TextureRowAdapter(Context context, List<TextureItem> items) {
        this.context = context;
        this.items = items;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() { return items.size(); }

    @Override
    public TextureItem getItem(int position) { return items.get(position); }

    @Override
    public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            // 🚨 Inflate YOUR custom texture row layout 🚨
            convertView = inflater.inflate(R.layout.item_texture_row, parent, false);
        }

        TextView texTitle = convertView.findViewById(R.id.texTitle);
        TextView texChip = convertView.findViewById(R.id.texChip);
        TextView texMeta = convertView.findViewById(R.id.texMeta);

        TextureItem item = items.get(position);

        texTitle.setText(item.title);
        texChip.setText(item.chip);
        texMeta.setText(item.meta);

        return convertView;
    }
}