package com.nocluetools.prov1;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AudioListActivity extends Activity {

    TextView audioTitle, audioNowPlaying;
    EditText audioSearch;
    ListView audioList;
    SeekBar audioSeek;
    Button audioPlayPause, audioStop, audioExtract, audioReplace, audioClose;
    
    ArrayAdapter<String> adapter;
    List<String> audioFiles = new ArrayList<>();
    String currentObbSession = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_list);

        // 1. Link UI
        audioTitle = findViewById(R.id.audioTitle);
        audioNowPlaying = findViewById(R.id.audioNowPlaying);
        audioSearch = findViewById(R.id.audioSearch);
        audioList = findViewById(R.id.audioList);
        audioSeek = findViewById(R.id.audioSeek);
        audioPlayPause = findViewById(R.id.audioPlayPause);
        audioStop = findViewById(R.id.audioStop);
        audioExtract = findViewById(R.id.audioExtract);
        audioReplace = findViewById(R.id.audioReplace);
        audioClose = findViewById(R.id.audioClose);

        // 2. Get the REAL OBB Session ID passed from the previous screen
        currentObbSession = getIntent().getStringExtra("OBB_SESSION");
        if (currentObbSession == null) {
            currentObbSession = ""; // Fallback
        }

        // 3. Load REAL data from Python
        loadAudioDataFromPython();

        // 4. Setup Search
        audioSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (adapter != null) adapter.getFilter().filter(s);
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // 5. List Item Click (Reveals Playback Controls)
        audioList.setOnItemClickListener((parent, view, position, id) -> {
            String selectedFile = adapter.getItem(position);
            
            audioNowPlaying.setVisibility(View.VISIBLE);
            audioSeek.setVisibility(View.VISIBLE);
            audioPlayPause.setVisibility(View.VISIBLE);
            audioStop.setVisibility(View.VISIBLE);
            audioClose.setVisibility(View.VISIBLE);
            
            audioNowPlaying.setText("Now Playing: " + selectedFile);
        });

        // 6. Button Clicks
        audioPlayPause.setOnClickListener(v -> {
            if (audioPlayPause.getText().toString().contains("PLAY")) {
                audioPlayPause.setText("⏸ PAUSE");
                // Here you will eventually call Python to extract the .ogg and play it
            } else {
                audioPlayPause.setText("▶ PLAY");
            }
        });

        audioStop.setOnClickListener(v -> {
            audioPlayPause.setText("▶ PLAY");
            audioSeek.setProgress(0);
        });

        audioExtract.setOnClickListener(v -> Toast.makeText(this, "Calling Python to extract...", Toast.LENGTH_SHORT).show());
        audioReplace.setOnClickListener(v -> Toast.makeText(this, "Calling Python to replace...", Toast.LENGTH_SHORT).show());
        
        audioClose.setOnClickListener(v -> {
            audioNowPlaying.setVisibility(View.GONE);
            audioSeek.setVisibility(View.GONE);
            audioPlayPause.setVisibility(View.GONE);
            audioStop.setVisibility(View.GONE);
            audioClose.setVisibility(View.GONE);
        });
    }

    private void loadAudioDataFromPython() {
        try {
            if (!Python.isStarted()) {
                Python.start(new AndroidPlatform(this));
            }
            Python py = Python.getInstance();
            PyObject bridge = py.getModule("noclue2k_bridge");

            // 🚨 CALLING YOUR REAL PYTHON FUNCTION 🚨
            PyObject result = bridge.callAttr("scan_obb_audio_bridge", currentObbSession);
            String jsonString = result.toString();

            // Parse the JSON response from Python
            JSONObject json = new JSONObject(jsonString);
            
            if (json.getBoolean("ok")) {
                // Assuming your python returns a list called "rows" or "audio_files"
                JSONArray rows = json.optJSONArray("rows"); 
                if (rows != null) {
                    for (int i = 0; i < rows.length(); i++) {
                        JSONObject row = rows.getJSONObject(i);
                        String name = row.optString("name", "Unknown.bin");
                        audioFiles.add(name);
                    }
                }
            } else {
                Toast.makeText(this, "Python Error: " + json.optString("error"), Toast.LENGTH_LONG).show();
            }

            audioTitle.setText("AUDIO FILES (" + audioFiles.size() + ")");
            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, audioFiles);
            audioList.setAdapter(adapter);

        } catch (Exception e) {
            audioTitle.setText("ERROR LOADING AUDIO");
            Toast.makeText(this, "Exception: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}