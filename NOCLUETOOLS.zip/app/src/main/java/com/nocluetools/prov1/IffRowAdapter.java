package com.nocluetools.prov1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class IffRowAdapter extends BaseAdapter {

    private Context context;
    private List<IffItem> items;
    private List<IffItem> filteredItems;
    private LayoutInflater inflater;

    // Simple class to hold the data for one row
    public static class IffItem {
        public String title;
        public String sub;
        public String chip;

        public IffItem(String title, String sub, String chip) {
            this.title = title;
            this.sub = sub;
            this.chip = chip;
        }
        
        // Used by the search filter
        public boolean matches(String query) {
            return title.toLowerCase().contains(query) || sub.toLowerCase().contains(query);
        }
    }

    public IffRowAdapter(Context context, List<IffItem> items) {
        this.context = context;
        this.items = items;
        this.filteredItems = new ArrayList<>(items);
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() { return filteredItems.size(); }

    @Override
    public IffItem getItem(int position) { return filteredItems.get(position); }

    @Override
    public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            // 🚨 Inflate YOUR custom row layout 🚨
            convertView = inflater.inflate(R.layout.item_iff_row, parent, false);
        }

        TextView rowTitle = convertView.findViewById(R.id.rowTitle);
        TextView rowSub = convertView.findViewById(R.id.rowSub);
        TextView rowChip = convertView.findViewById(R.id.rowChip);

        IffItem item = filteredItems.get(position);

        rowTitle.setText(item.title);
        rowSub.setText(item.sub);
        rowChip.setText(item.chip);

        return convertView;
    }

    // Method to handle the search bar
    public void filter(String text) {
        filteredItems.clear();
        if (text == null || text.isEmpty()) {
            filteredItems.addAll(items);
        } else {
            String query = text.toLowerCase();
            for (IffItem item : items) {
                if (item.matches(query)) {
                    filteredItems.add(item);
                }
            }
        }
        notifyDataSetChanged();
    }
}