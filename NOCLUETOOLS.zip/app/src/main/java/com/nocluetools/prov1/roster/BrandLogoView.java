package com.nocluetools.prov1.roster;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class BrandLogoView extends View {
    private final Paint paint;
    private final Path path;

    public BrandLogoView(Context context) {
        super(context);
        this.paint = new Paint(1);
        this.path = new Path();
        setLayerType(1, (Paint) null);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float width = getWidth();
        float height = getHeight();
        float fMin = Math.min(width, height);
        float f = width * 0.5f;
        float f2 = height * 0.5f;
        float f3 = fMin * 0.42f;
        this.paint.setStyle(Paint.Style.FILL);
        this.paint.setColor(Color.rgb(24, 28, 36));
        this.paint.setShadowLayer(fMin * 0.1f, 0.0f, 0.0f, Color.rgb(30, 115, 255));
        canvas.drawCircle(f, f2, f3, this.paint);
        this.paint.clearShadowLayer();
        this.paint.setStyle(Paint.Style.STROKE);
        this.paint.setStrokeWidth(Math.max(2.0f, fMin * 0.035f));
        this.paint.setColor(Color.rgb(72, 143, 255));
        canvas.drawCircle(f, f2, f3, this.paint);
        this.paint.setStrokeWidth(Math.max(1.5f, fMin * 0.022f));
        this.paint.setColor(Color.rgb(228, 233, 244));
        RectF rectF = new RectF(f - (f3 * 0.72f), f2 - (f3 * 0.72f), f + (f3 * 0.72f), f2 + (f3 * 0.72f));
        canvas.drawArc(rectF, -82.0f, 164.0f, false, this.paint);
        canvas.drawArc(rectF, 98.0f, 164.0f, false, this.paint);
        canvas.drawLine(f - (f3 * 0.7f), f2, f + (f3 * 0.7f), f2, this.paint);
        this.paint.setStyle(Paint.Style.STROKE);
        this.paint.setStrokeCap(Paint.Cap.SQUARE);
        this.paint.setStrokeJoin(Paint.Join.MITER);
        this.paint.setStrokeWidth(Math.max(3.0f, fMin * 0.07f));
        this.paint.setColor(-1);
        this.path.reset();
        this.path.moveTo(f - (f3 * 0.42f), f2 + (f3 * 0.4f));
        this.path.lineTo(f, f2 - (f3 * 0.46f));
        this.path.lineTo(f + (f3 * 0.42f), f2 + (f3 * 0.4f));
        canvas.drawPath(this.path, this.paint);
        canvas.drawLine(f - (f3 * 0.2f), f2 + (f3 * 0.08f), f + (f3 * 0.2f), f2 + (f3 * 0.08f), this.paint);
        this.paint.setStrokeWidth(Math.max(2.0f, fMin * 0.03f));
        this.paint.setColor(Color.rgb(72, 143, 255));
        canvas.drawLine(f + (f3 * 0.46f), f2 - (f3 * 0.42f), f + (f3 * 0.66f), f2 - (f3 * 0.18f), this.paint);
        canvas.drawLine(f + (f3 * 0.66f), f2 - (f3 * 0.18f), f + (f3 * 0.78f), f2 - (f3 * 0.42f), this.paint);
    }
}
