package com.nocluetools.prov1.roster;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class PlayerTableAdapter extends ArrayAdapter<String> {
    public PlayerTableAdapter(Context context, List<String> list) {
        super(context, android.R.layout.simple_list_item_1, list);
    }

    @Override // android.widget.ArrayAdapter, android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        TextView textView = (TextView) super.getView(i, view, viewGroup);
        textView.setTextColor(-1);
        textView.setTextSize(12);
        textView.setTypeface(Typeface.MONOSPACE, 0);
        textView.setSingleLine(true);
        textView.setMaxLines(1);
        textView.setHorizontallyScrolling(false);
        textView.setPadding(dp(10), dp(11), dp(8), dp(11));
        if ((i & 1) == 0) {
            textView.setBackgroundColor(Color.rgb(27, 30, 36));
        } else {
            textView.setBackgroundColor(Color.rgb(31, 34, 41));
        }
        return textView;
    }

    private int dp(int i) {
        return Math.round(i * getContext().getResources().getDisplayMetrics().density);
    }
}
