package com.nocluetools.prov1;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONObject;

public class ObjViewerActivity extends Activity {

    // UI Elements
    ImageView objImage, objTextureView;
    TextView objInfo, objTexInfo, objStatus;
    TextView objClose, objPrev, objNext, objRotL, objRotR, objExport, objSaveTex, objUvToggle;
    TextView uvGrid4, uvGrid8, uvGrid16, uvGrid32, uvGridOff;

    // State
    int currentYaw = 28;
    int currentPitch = 12;
    String currentSessionId = "";
    int currentFileIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_obj_viewer); // Match your XML filename

        initViews();
        setupListeners();

        // Get data from previous screen
        currentSessionId = getIntent().getStringExtra("SESSION_ID");
        currentFileIndex = getIntent().getIntExtra("FILE_INDEX", 0);

        if (currentSessionId != null) {
            loadMeshFromPython();
        } else {
            objStatus.setText("ERROR: No session ID provided.");
        }
    }

    private void initViews() {
        objImage = findViewById(R.id.objImage);
        objTextureView = findViewById(R.id.objTextureView);
        objInfo = findViewById(R.id.objInfo);
        objTexInfo = findViewById(R.id.objTexInfo);
        objStatus = findViewById(R.id.objStatus);

        objClose = findViewById(R.id.objClose);
        objPrev = findViewById(R.id.objPrev);
        objNext = findViewById(R.id.objNext);
        objRotL = findViewById(R.id.objRotL);
        objRotR = findViewById(R.id.objRotR);
        objExport = findViewById(R.id.objExport);
        objSaveTex = findViewById(R.id.objSaveTex);
        objUvToggle = findViewById(R.id.objUvToggle);

        uvGrid4 = findViewById(R.id.uvGrid4);
        uvGrid8 = findViewById(R.id.uvGrid8);
        uvGrid16 = findViewById(R.id.uvGrid16);
        uvGrid32 = findViewById(R.id.uvGrid32);
        uvGridOff = findViewById(R.id.uvGridOff);
        
        // Set default grid active
        updateGridUI(uvGrid4);
    }

    private void setupListeners() {
        objClose.setOnClickListener(v -> finish());

        // Rotate Left
        objRotL.setOnClickListener(v -> {
            currentYaw -= 15;
            objInfo.setText("yaw=" + currentYaw + "° pitch=" + currentPitch + "°");
            // Call Python to rotate and redraw mesh here
            objStatus.setText("Rotating Mesh...");
        });

        // Rotate Right
        objRotR.setOnClickListener(v -> {
            currentYaw += 15;
            objInfo.setText("yaw=" + currentYaw + "° pitch=" + currentPitch + "°");
            // Call Python to rotate and redraw mesh here
            objStatus.setText("Rotating Mesh...");
        });

        objExport.setOnClickListener(v -> {
            objStatus.setText("Exporting OBJ to storage...");
            // bridge.callAttr("export_mesh_obj_bridge", currentSessionId, currentFileIndex, outDir)
            Toast.makeText(this, "Export OBJ Triggered", Toast.LENGTH_SHORT).show();
        });

        objSaveTex.setOnClickListener(v -> {
            objStatus.setText("Saving Texture...");
            // bridge.callAttr("export_texture_png_bridge", ...)
            Toast.makeText(this, "Save Texture Triggered", Toast.LENGTH_SHORT).show();
        });

        // Grid Buttons
        View.OnClickListener gridListener = v -> {
            updateGridUI(v);
            objStatus.setText("Grid updated. Rendering...");
        };
        uvGrid4.setOnClickListener(gridListener);
        uvGrid8.setOnClickListener(gridListener);
        uvGrid16.setOnClickListener(gridListener);
        uvGrid32.setOnClickListener(gridListener);
        uvGridOff.setOnClickListener(gridListener);
    }

    // Helper to change grid button colors
    private void updateGridUI(View activeView) {
        TextView[] grids = {uvGrid4, uvGrid8, uvGrid16, uvGrid32, uvGridOff};
        for (TextView grid : grids) {
            grid.setBackgroundResource(R.drawable.bg_btn_secondary);
            grid.setTextColor(Color.parseColor("#FFFFFF"));
        }
        activeView.setBackgroundResource(R.drawable.bg_btn_primary);
        // Optional: change text color for active grid
        ((TextView) activeView).setTextColor(Color.parseColor("#FFFFFF"));
    }

    private void loadMeshFromPython() {
        objStatus.setText("Loading Mesh via Python Engine...");

        new Thread(() -> {
            try {
                if (!Python.isStarted()) {
                    Python.start(new AndroidPlatform(this));
                }
                Python py = Python.getInstance();
                PyObject bridge = py.getModule("noclue2k_bridge");

                // 🚨 CALLING YOUR PYTHON FUNCTION 🚨
                // Make sure your python bridge returns base64 encoded image strings for the mesh/texture
                PyObject result = bridge.callAttr("extract_mesh_bridge", currentSessionId, currentFileIndex);
                String jsonString = result.toString();

                JSONObject json = new JSONObject(jsonString);
                
                if (json.getBoolean("ok")) {
                    // Assuming Python returns base64 strings for the previews
                    String meshBase64 = json.optString("mesh_preview_b64", "");
                    String texBase64 = json.optString("texture_preview_b64", "");
                    
                    Bitmap meshBmp = null;
                    if (!meshBase64.isEmpty()) {
                        byte[] meshBytes = Base64.decode(meshBase64, Base64.DEFAULT);
                        meshBmp = BitmapFactory.decodeByteArray(meshBytes, 0, meshBytes.length);
                    }

                    Bitmap texBmp = null;
                    if (!texBase64.isEmpty()) {
                        byte[] texBytes = Base64.decode(texBase64, Base64.DEFAULT);
                        texBmp = BitmapFactory.decodeByteArray(texBytes, 0, texBytes.length);
                    }

                    Bitmap finalMeshBmp = meshBmp;
                    Bitmap finalTexBmp = texBmp;

                    runOnUiThread(() -> {
                        if (finalMeshBmp != null) objImage.setImageBitmap(finalMeshBmp);
                        if (finalTexBmp != null) objTextureView.setImageBitmap(finalTexBmp);
                        
                        int verts = json.optInt("vertices", 0);
                        int tris = json.optInt("triangles", 0);
                        objStatus.setText("✓ Success: textured " + verts + " verts | " + tris + " tris");
                        objInfo.setText("yaw=" + currentYaw + "° pitch=" + currentPitch + "°");
                    });
                } else {
                    String error = json.optString("error", "Unknown Error");
                    runOnUiThread(() -> objStatus.setText("ERROR: " + error));
                }
            } catch (Exception e) {
                runOnUiThread(() -> objStatus.setText("EXCEPTION: " + e.getMessage()));
            }
        }).start();
    }
}