package com.nocluetools.prov1;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {

    // UI Elements
    TextView tvStatus, tvLog;
    ScrollView scrollLog;
    Button btnOpenObb, btnOpenIff, btnOpenAudio;
    ListView listObbContents;
    
    // Python Elements
    Python py;
    PyObject bridge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Link UI elements from the XML
        tvStatus = findViewById(R.id.tvStatus);
        tvLog = findViewById(R.id.tvLog);
        scrollLog = (ScrollView) tvLog.getParent();
        btnOpenObb = findViewById(R.id.btnOpenObb);
        btnOpenIff = findViewById(R.id.btnOpenIff);
        btnOpenAudio = findViewById(R.id.btnOpenAudio);
        listObbContents = findViewById(R.id.listObbContents);

        // 2. Start Python Engine
        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }
        
        try {
            py = Python.getInstance();
            // Load your renamed module
            bridge = py.getModule("noclue2k_bridge"); 
            log("System Ready. Python Engine Initialized.");
        } catch (Exception e) {
            log("FATAL ERROR LOADING PYTHON: " + e.getMessage());
            tvStatus.setText("STATUS: PYTHON FAILED");
        }

        // 3. Button Click Listeners
        btnOpenObb.setOnClickListener(v -> {
            tvStatus.setText("STATUS: OPENING OBB...");
            log("Calling Python: open_obb_bridge...");
            try {
                // Note: We are using a dummy path for the Beta test.
                // Later, you will replace this with a real file picker.
                String dummyPath = "/storage/emulated/0/Android/obb/com.t2ksports.nba2k20and/main.98.com.t2ksports.nba2k20and.obb";
                String dummyWorkDir = getCacheDir().getAbsolutePath();

                PyObject result = bridge.callAttr("open_obb_bridge", dummyPath, dummyWorkDir);
                String jsonResponse = result.toString();
                
                log("PYTHON RESPONSE:\n" + jsonResponse);
                tvStatus.setText("STATUS: OBB LOADED");
                
                // Show some dummy files in the list to prove it works
                updateList(new String[]{"team_013.iff", "portrait.cdf", "frontend_sync.iff"});
            } catch (Exception e) {
                log("PYTHON ERROR: " + e.getMessage());
                tvStatus.setText("STATUS: ERROR");
            }
        });

        btnOpenIff.setOnClickListener(v -> {
            tvStatus.setText("STATUS: OPENING IFF...");
            log("Calling Python: open_iff_bridge...");
            try {
                String dummyPath = "/storage/emulated/0/test.iff";
                PyObject result = bridge.callAttr("open_iff_bridge", dummyPath);
                
                log("PYTHON RESPONSE:\n" + result.toString());
                tvStatus.setText("STATUS: IFF LOADED");
            } catch (Exception e) {
                log("PYTHON ERROR: " + e.getMessage());
                tvStatus.setText("STATUS: ERROR");
            }
        });

        btnOpenAudio.setOnClickListener(v -> {
            tvStatus.setText("STATUS: SCANNING AUDIO...");
            log("Calling Python: scan_obb_audio_bridge...");
            try {
                // Passing a dummy session ID to test the bridge
                PyObject result = bridge.callAttr("scan_obb_audio_bridge", "dummy_session_id");
                
                log("PYTHON RESPONSE:\n" + result.toString());
                tvStatus.setText("STATUS: AUDIO SCANNED");
                
                // Dummy audio list
                updateList(new String[]{"Audio #1123 (OGG)", "Audio #1124 (OGG)", "Audio #1125 (OGG)"});
            } catch (Exception e) {
                log("PYTHON ERROR: " + e.getMessage());
                tvStatus.setText("STATUS: ERROR");
            }
        });
    }

    // Helper to write to the green output log
    private void log(String message) {
        tvLog.append("\n> " + message);
        // Auto-scroll to the bottom
        scrollLog.post(() -> scrollLog.fullScroll(View.FOCUS_DOWN));
    }

    // Helper to update the ListView
    private void updateList(String[] items) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        listObbContents.setAdapter(adapter);
    }
}