package com.nocluetools.prov1;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    // --- Top Bar & Panels ---
    TextView tvSectionName, tvStatusBar;
    View panelHome, panelRoster, panelTeams, panelPlayers, panelTools;
    
    // --- Bottom Nav Tabs ---
    TextView tabHome, tabRoster, tabTeams, tabPlayers, tabTools;

    // --- Player Drawer ---
    View playerActionsDrawer;
    TextView btnTogglePlayerActions;
    ListView listViewRecords;
    EditText etSearch;

    // --- Player List Data ---
    PlayerRowAdapter playerAdapter;
    List<PlayerRowAdapter.PlayerItem> playerList = new ArrayList<>();

    // Colors for active/inactive tabs
    int activeColor = Color.parseColor("#2196F3"); // Blue background
    int inactiveColor = Color.parseColor("#15171B"); // Dark grey background
    int activeTextColor = Color.parseColor("#FFFFFF");
    int inactiveTextColor = Color.parseColor("#6B7280");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupNavigation();
        setupPlayerList(); // Sets up the search and the custom adapter
        setupButtonClicks();

        // Start Python Engine in the background
        try {
            if (!Python.isStarted()) {
                Python.start(new AndroidPlatform(this));
            }
            tvStatusBar.setText("● READY  ·  PYTHON ENGINE LOADED");
        } catch (Exception e) {
            tvStatusBar.setText("● PYTHON ERROR: " + e.getMessage());
        }
    }

    private void initViews() {
        tvSectionName = findViewById(R.id.tvSectionName);
        tvStatusBar = findViewById(R.id.tvStatusBar);

        panelHome = findViewById(R.id.panelHome);
        panelRoster = findViewById(R.id.panelRoster);
        panelTeams = findViewById(R.id.panelTeams);
        panelPlayers = findViewById(R.id.panelPlayers);
        panelTools = findViewById(R.id.panelTools);

        tabHome = findViewById(R.id.tabHome);
        tabRoster = findViewById(R.id.tabRoster);
        tabTeams = findViewById(R.id.tabTeams);
        tabPlayers = findViewById(R.id.tabPlayers);
        tabTools = findViewById(R.id.tabTools);

        playerActionsDrawer = findViewById(R.id.playerActionsDrawer);
        btnTogglePlayerActions = findViewById(R.id.btnTogglePlayerActions);
        
        listViewRecords = findViewById(R.id.listViewRecords);
        etSearch = findViewById(R.id.etSearch);
    }

    private void setupNavigation() {
        tabHome.setOnClickListener(v -> switchTab("HOME"));
        tabRoster.setOnClickListener(v -> switchTab("ROSTER"));
        tabTeams.setOnClickListener(v -> switchTab("TEAMS"));
        tabPlayers.setOnClickListener(v -> switchTab("PLAYERS"));
        tabTools.setOnClickListener(v -> switchTab("TOOLS"));
    }

    private void switchTab(String tabName) {
        // 1. Reset all panels to GONE
        panelHome.setVisibility(View.GONE);
        panelRoster.setVisibility(View.GONE);
        panelTeams.setVisibility(View.GONE);
        panelPlayers.setVisibility(View.GONE);
        panelTools.setVisibility(View.GONE);

        // 2. Reset all tabs to inactive colors
        TextView[] allTabs = {tabHome, tabRoster, tabTeams, tabPlayers, tabTools};
        for (TextView tab : allTabs) {
            tab.setBackgroundColor(inactiveColor);
            tab.setTextColor(inactiveTextColor);
        }

        // 3. Show the selected panel and highlight the tab
        tvSectionName.setText(tabName);
        switch (tabName) {
            case "HOME":
                panelHome.setVisibility(View.VISIBLE);
                tabHome.setBackgroundColor(activeColor);
                tabHome.setTextColor(activeTextColor);
                break;
            case "ROSTER":
                panelRoster.setVisibility(View.VISIBLE);
                tabRoster.setBackgroundColor(activeColor);
                tabRoster.setTextColor(activeTextColor);
                break;
            case "TEAMS":
                panelTeams.setVisibility(View.VISIBLE);
                tabTeams.setBackgroundColor(activeColor);
                tabTeams.setTextColor(activeTextColor);
                break;
            case "PLAYERS":
                panelPlayers.setVisibility(View.VISIBLE);
                tabPlayers.setBackgroundColor(activeColor);
                tabPlayers.setTextColor(activeTextColor);
                break;
            case "TOOLS":
                panelTools.setVisibility(View.VISIBLE);
                tabTools.setBackgroundColor(activeColor);
                tabTools.setTextColor(activeTextColor);
                break;
        }
    }

    private void setupPlayerList() {
        // Populate with REAL data from Python later. For now, we test the UI:
        playerList.add(new PlayerRowAdapter.PlayerItem("LeBron James", "23", "97", "1013"));
        playerList.add(new PlayerRowAdapter.PlayerItem("Stephen Curry", "30", "96", "1180"));
        playerList.add(new PlayerRowAdapter.PlayerItem("Kevin Durant", "7", "95", "1055"));
        playerList.add(new PlayerRowAdapter.PlayerItem("Giannis Antetokounmpo", "34", "96", "1201"));

        playerAdapter = new PlayerRowAdapter(this, playerList);
        listViewRecords.setAdapter(playerAdapter);

        // Search Bar
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (playerAdapter != null) playerAdapter.filter(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // Player Click Listener
        listViewRecords.setOnItemClickListener((parent, view, position, id) -> {
            PlayerRowAdapter.PlayerItem selectedPlayer = playerAdapter.getItem(position);
            Intent intent = new Intent(MainActivity.this, PlayerEditorActivity.class);
            intent.putExtra("PLAYER_ID", selectedPlayer.cfId);
            intent.putExtra("PLAYER_NAME", selectedPlayer.name);
            startActivity(intent);
        });
    }

    private void setupButtonClicks() {
        // --- HOME PANEL BUTTONS ---
        findViewById(R.id.btnHomeOpenRoster).setOnClickListener(v -> switchTab("ROSTER"));
        findViewById(R.id.btnHomePlayerLab).setOnClickListener(v -> switchTab("PLAYERS"));
        findViewById(R.id.btnHomeTeamControl).setOnClickListener(v -> switchTab("TEAMS"));
        findViewById(R.id.btnHomeTools).setOnClickListener(v -> switchTab("TOOLS"));

        // --- ROSTER PANEL BUTTONS ---
        findViewById(R.id.btnOpenRoster2).setOnClickListener(v -> showToast("Open Roster File Picker..."));
        findViewById(R.id.btnSaveAsNew).setOnClickListener(v -> showToast("Saving Roster..."));

        // --- TEAMS PANEL BUTTONS ---
        findViewById(R.id.btnTeamDatabase).setOnClickListener(v -> showToast("Team Database..."));
        findViewById(R.id.btnFreeAgentManager).setOnClickListener(v -> showToast("Free Agent Manager..."));
        findViewById(R.id.btnRotationSettings).setOnClickListener(v -> showToast("Rotation Settings..."));
        findViewById(R.id.btnRosterValidator).setOnClickListener(v -> showToast("Validating Roster..."));

        // --- PLAYERS PANEL BUTTONS ---
        // Drawer Toggle
        btnTogglePlayerActions.setOnClickListener(v -> {
            if (playerActionsDrawer.getVisibility() == View.GONE) {
                playerActionsDrawer.setVisibility(View.VISIBLE);
                btnTogglePlayerActions.setText("▼  HIDE TOOLS");
            } else {
                playerActionsDrawer.setVisibility(View.GONE);
                btnTogglePlayerActions.setText("▲  PLAYER TOOLS");
            }
        });

        // Drawer Buttons
        findViewById(R.id.btnCreatePlayer).setOnClickListener(v -> showToast("Create Player..."));
        findViewById(R.id.btnEditPlayer).setOnClickListener(v -> showToast("Edit Player..."));
        findViewById(R.id.btnPlayerEditorPro).setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PlayerEditorActivity.class);
            intent.putExtra("PLAYER_ID", "1013");
            intent.putExtra("PLAYER_NAME", "LeBron James");
            startActivity(intent);
        });
        findViewById(R.id.btnCreateCyberface).setOnClickListener(v -> showToast("Cyberface Editor..."));
        findViewById(R.id.btnAnimations).setOnClickListener(v -> showToast("Animations..."));
        findViewById(R.id.btnDraftInfo).setOnClickListener(v -> showToast("Draft Info..."));

        // --- TOOLS PANEL BUTTONS ---
        findViewById(R.id.btnSyncPlayer).setOnClickListener(v -> showToast("Syncing Player..."));
        findViewById(R.id.btnApplyOnline).setOnClickListener(v -> showToast("Applying Online..."));
        findViewById(R.id.btnSyncWholeTeam).setOnClickListener(v -> showToast("Syncing Team..."));
        findViewById(R.id.btnMoveRelease).setOnClickListener(v -> showToast("Move/Release..."));

        // Game Archives (OBB) -> Launches the File List Activity we built!
        findViewById(R.id.btnOpenMainObb).setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FileListActivity.class);
            intent.putExtra("OBB_SESSION", "dummy_session"); // Replace with real Python session ID later
            startActivity(intent);
        });
        
        findViewById(R.id.btnOpenPatch98).setOnClickListener(v -> showToast("Opening Patch.98..."));
        findViewById(R.id.btnScanPatchCfid).setOnClickListener(v -> showToast("Scanning Patch CFID..."));
        findViewById(R.id.btnScanMainRealnames).setOnClickListener(v -> showToast("Scanning Main Realnames..."));

        // Cyberface Export
        EditText etCyberfaceId = findViewById(R.id.etCyberfaceId);
        findViewById(R.id.btnExportCyberfaceIff).setOnClickListener(v -> {
            String cfId = etCyberfaceId.getText().toString();
            if (cfId.isEmpty()) {
                showToast("Please enter a Cyberface ID");
            } else {
                showToast("Exporting IFF for CF ID: " + cfId);
            }
        });
        findViewById(R.id.btnExportSelectedPlayerCf).setOnClickListener(v -> showToast("Exporting Selected Player CF..."));
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}