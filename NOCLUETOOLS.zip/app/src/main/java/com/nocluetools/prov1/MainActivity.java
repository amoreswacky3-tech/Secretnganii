package com.nocluetools.prov1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // 🚨 THIS IS YOUR HOME SCREEN XML (The one with the 6 buttons)

        // Start Python Engine in the background
        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }

        // 1. Open Roster Editor Button
        findViewById(R.id.cardRosterEditor).setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RosterEditorActivity.class);
            startActivity(intent);
        });

        // 2. Open OBB Button
        findViewById(R.id.btnSelectObb).setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FileListActivity.class);
            startActivity(intent);
        });

        // 3. Open IFF Button
        findViewById(R.id.btnSelectIff).setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, TextureViewerActivity.class);
            startActivity(intent);
        });

        // 4. Obj Editor Button
        findViewById(R.id.btnObjEditor).setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ObjViewerActivity.class);
            startActivity(intent);
        });

        // 5. Head / Hair Button
        findViewById(R.id.btnHeadHair).setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, HeadHairActivity.class);
            startActivity(intent);
        });
    }
}