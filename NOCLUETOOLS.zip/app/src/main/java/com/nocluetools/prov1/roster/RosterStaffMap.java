package com.nocluetools.prov1.roster;

import com.nocluetools.prov1.roster.RosterPlayerMap;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public final class RosterStaffMap {
    public static final int STAFF_APPEARANCE_ID_A_BITS = 1067;
    public static final int STAFF_APPEARANCE_ID_B_BITS = 1088;
    public static final int STAFF_APPEARANCE_ID_MAX = 8191;
    public static final int STAFF_APPEARANCE_ID_WIDTH = 13;
    public static final int STAFF_FIRST_REF_BITS = 0;
    public static final int STAFF_LAST_REF_BITS = 32;
    public static final int STAFF_STRIDE_BITS = 1248;
    public static final long STAFF_TAG_BASE = 572522496;
    public static final int STAFF_TAG_BITS = 32;
    public static final int TEAM_ASSISTANT_COACH_REF_BITS = 1344;
    public static final int TEAM_HEAD_COACH_REF_BITS = 1312;

    public static final class StaffRecord {
        public final int appearanceIdA;
        public final int appearanceIdB;
        public final String displayName;
        public final String firstName;
        public final long firstNameRef;
        public final String lastName;
        public final long lastNameRef;
        public final int slot;

        StaffRecord(int i, long j, long j2, String str, String str2, int i2, int i3) {
            this.slot = i;
            this.firstNameRef = j;
            this.lastNameRef = j2;
            this.firstName = RosterStaffMap.clean(str);
            this.lastName = RosterStaffMap.clean(str2);
            this.appearanceIdA = i2;
            this.appearanceIdB = i3;
            String strTrim = new StringBuffer().append(new StringBuffer().append(this.firstName).append(" ").toString()).append(this.lastName).toString().trim();
            this.displayName = strTrim.length() == 0 ? String.format(Locale.US, "Staff %04d", new Integer(i)) : strTrim;
        }
    }

    public static final class Result {
        public final List<StaffRecord> staff;
        public final long staffTableBitOffset;

        Result(long j, List<StaffRecord> list) {
            this.staffTableBitOffset = j;
            this.staff = Collections.unmodifiableList(list);
        }

        public StaffRecord get(int i) {
            return (i < 0 || i >= this.staff.size()) ? (StaffRecord) null : this.staff.get(i);
        }
    }

    public static Result parse(byte[] bArr, List<RosterPlayerMap.TeamRecord> list) throws IOException {
        String rosterString;
        String rosterString2;
        if (bArr == null || bArr.length < 1024) {
            throw new IOException("Roster payload is empty.");
        }
        long jFindSequentialTable = findSequentialTable(bArr, STAFF_TAG_BASE, STAFF_STRIDE_BITS, 8);
        if (jFindSequentialTable < 0) {
            throw new IOException("STAFF/COACH table was not found.");
        }
        int iCountSequentialRecords = countSequentialRecords(bArr, jFindSequentialTable, STAFF_TAG_BASE, STAFF_STRIDE_BITS, 4096);
        if (iCountSequentialRecords < 30) {
            throw new IOException(new StringBuffer().append("STAFF/COACH table is too small: ").append(iCountSequentialRecords).toString());
        }
        long jFindStringPoolBitOffset = RosterNameResolver.findStringPoolBitOffset(bArr, list);
        ArrayList arrayList = new ArrayList(iCountSequentialRecords);
        for (int i = 0; i < iCountSequentialRecords; i++) {
            long j = jFindSequentialTable + (((long) i) * ((long) STAFF_STRIDE_BITS)) + ((long) 32);
            long bits = RosterPlayerMap.readBits(bArr, j + ((long) 0), 32);
            long bits2 = RosterPlayerMap.readBits(bArr, j + ((long) 32), 32);
            if (jFindStringPoolBitOffset >= 0) {
                rosterString = RosterNameResolver.readRosterString(bArr, jFindStringPoolBitOffset, bits);
            } else {
                rosterString = "";
            }
            String str = rosterString;
            if (jFindStringPoolBitOffset >= 0) {
                rosterString2 = RosterNameResolver.readRosterString(bArr, jFindStringPoolBitOffset, bits2);
            } else {
                rosterString2 = "";
            }
            arrayList.add(new StaffRecord(i, bits, bits2, str, rosterString2, (int) RosterPlayerMap.readBits(bArr, j + ((long) STAFF_APPEARANCE_ID_A_BITS), 13), (int) RosterPlayerMap.readBits(bArr, j + ((long) STAFF_APPEARANCE_ID_B_BITS), 13)));
        }
        return new Result(jFindSequentialTable, arrayList);
    }

    public static int getHeadCoachSlot(byte[] bArr, long j, int i) {
        return staffSlotFromRef(readTeamStaffRef(bArr, j, i, TEAM_HEAD_COACH_REF_BITS));
    }

    public static int getAssistantCoachSlot(byte[] bArr, long j, int i) {
        return staffSlotFromRef(readTeamStaffRef(bArr, j, i, TEAM_ASSISTANT_COACH_REF_BITS));
    }

    public static long makeStaffRef(int i) {
        if (i < 0 || i > 1048575) {
            throw new IllegalArgumentException("staffSlot");
        }
        return STAFF_TAG_BASE | (((long) i) & 1048575);
    }

    public static int staffSlotFromRef(long j) {
        long j2 = j - STAFF_TAG_BASE;
        if (j2 < 0 || j2 > 1048575) {
            return -1;
        }
        return (int) j2;
    }

    public static int findUnusedStaffSlot(byte[] bArr, long j, int i, Result result) {
        if (bArr == null || result == null || result.staff.size() == 0) {
            return -1;
        }
        boolean[] zArr = new boolean[result.staff.size()];
        int iMax = Math.max(0, i);
        for (int i2 = 0; i2 < iMax; i2++) {
            long j2 = j + (((long) i2) * 6356) + 32;
            if (j2 + ((long) TEAM_ASSISTANT_COACH_REF_BITS) + 32 > ((long) bArr.length) * 8) {
                break;
            }
            int iStaffSlotFromRef = staffSlotFromRef(RosterPlayerMap.readBits(bArr, j2 + ((long) TEAM_HEAD_COACH_REF_BITS), 32));
            int iStaffSlotFromRef2 = staffSlotFromRef(RosterPlayerMap.readBits(bArr, j2 + ((long) TEAM_ASSISTANT_COACH_REF_BITS), 32));
            if (iStaffSlotFromRef >= 0 && iStaffSlotFromRef < zArr.length) {
                zArr[iStaffSlotFromRef] = true;
            }
            if (iStaffSlotFromRef2 >= 0 && iStaffSlotFromRef2 < zArr.length) {
                zArr[iStaffSlotFromRef2] = true;
            }
        }
        for (int length = zArr.length - 1; length >= 0; length--) {
            if (!zArr[length]) {
                return length;
            }
        }
        return -1;
    }

    public static int countTeamReferences(byte[] bArr, long j, int i, int i2) {
        if (bArr == null || i2 < 0) {
            return 0;
        }
        int i3 = 0;
        long length = ((long) bArr.length) * 8;
        int iMax = Math.max(0, i);
        for (int i4 = 0; i4 < iMax; i4++) {
            long j2 = j + (((long) i4) * 6356) + 32;
            if (j2 + ((long) TEAM_ASSISTANT_COACH_REF_BITS) + 32 > length) {
                break;
            }
            int iStaffSlotFromRef = staffSlotFromRef(RosterPlayerMap.readBits(bArr, j2 + ((long) TEAM_HEAD_COACH_REF_BITS), 32));
            int iStaffSlotFromRef2 = staffSlotFromRef(RosterPlayerMap.readBits(bArr, j2 + ((long) TEAM_ASSISTANT_COACH_REF_BITS), 32));
            if (iStaffSlotFromRef == i2) {
                i3++;
            }
            if (iStaffSlotFromRef2 == i2) {
                i3++;
            }
        }
        return i3;
    }

    public static void writePlayerIdentityIntoExistingCoach(byte[] bArr, Result result, int i, RosterPlayerMap.PlayerRecord playerRecord) throws IOException {
        if (bArr == null || result == null || playerRecord == null) {
            throw new IOException("Player/coach data is unavailable.");
        }
        if (i < 0 || i >= result.staff.size()) {
            throw new IOException("Active coach STAFF slot is invalid.");
        }
        long j = result.staffTableBitOffset + (((long) i) * ((long) STAFF_STRIDE_BITS)) + ((long) 32);
        RosterEditor.writeBits(bArr, j + ((long) 0), 32, playerRecord.firstNameRef);
        RosterEditor.writeBits(bArr, j + ((long) 32), 32, playerRecord.lastNameRef);
        long bits = RosterPlayerMap.readBits(bArr, j + ((long) 0), 32);
        long bits2 = RosterPlayerMap.readBits(bArr, j + ((long) 32), 32);
        if (bits != (playerRecord.firstNameRef & 4294967295L) || bits2 != (playerRecord.lastNameRef & 4294967295L)) {
            throw new IOException("Active coach identity verification failed.");
        }
    }

    public static void writePlayerIdentityAndAppearanceIntoExistingCoach(byte[] bArr, Result result, int i, RosterPlayerMap.PlayerRecord playerRecord) throws IOException {
        if (bArr == null || result == null || playerRecord == null) {
            throw new IOException("Player/coach data is unavailable.");
        }
        if (i < 0 || i >= result.staff.size()) {
            throw new IOException("Active coach STAFF slot is invalid.");
        }
        if (!playerRecord.hasUsableCyberfaceId()) {
            throw new IOException("Selected player does not have a usable cyberface ID.");
        }
        if (playerRecord.cyberfaceId > 8191) {
            throw new IOException(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append("Player CFID ").append(playerRecord.cyberfaceId).toString()).append(" is too large for the 13-bit coach appearance field (max ").toString()).append(STAFF_APPEARANCE_ID_MAX).toString()).append(").").toString());
        }
        writePlayerIdentityIntoExistingCoach(bArr, result, i, playerRecord);
        long j = result.staffTableBitOffset + (((long) i) * ((long) STAFF_STRIDE_BITS)) + ((long) 32);
        int i2 = playerRecord.cyberfaceId;
        RosterEditor.writeBits(bArr, j + ((long) STAFF_APPEARANCE_ID_A_BITS), 13, i2);
        RosterEditor.writeBits(bArr, j + ((long) STAFF_APPEARANCE_ID_B_BITS), 13, i2);
        int bits = (int) RosterPlayerMap.readBits(bArr, j + ((long) STAFF_APPEARANCE_ID_A_BITS), 13);
        int bits2 = (int) RosterPlayerMap.readBits(bArr, j + ((long) STAFF_APPEARANCE_ID_B_BITS), 13);
        if (bits != i2 || bits2 != i2) {
            throw new IOException("Coach appearance CFID verification failed.");
        }
    }

    public static void cloneCoachTemplateForPlayer(byte[] bArr, Result result, int i, int i2, RosterPlayerMap.PlayerRecord playerRecord) throws IOException {
        if (bArr == null || result == null || playerRecord == null) {
            throw new IOException("Player/coach data is unavailable.");
        }
        if (i < 0 || i >= result.staff.size()) {
            throw new IOException("Coach template slot is invalid.");
        }
        if (i2 < 0 || i2 >= result.staff.size()) {
            throw new IOException("No safe STAFF slot is available.");
        }
        if (i2 == i) {
            throw new IOException("Target STAFF slot must differ from the template.");
        }
        long j = result.staffTableBitOffset + (((long) i) * ((long) STAFF_STRIDE_BITS)) + ((long) 32);
        long j2 = result.staffTableBitOffset + (((long) i2) * ((long) STAFF_STRIDE_BITS)) + ((long) 32);
        int i3 = 0;
        while (true) {
            int i4 = i3;
            if (i4 >= 1216) {
                break;
            }
            int iMin = Math.min(32, 1216 - i4);
            RosterEditor.writeBits(bArr, j2 + ((long) i4), iMin, RosterPlayerMap.readBits(bArr, j + ((long) i4), iMin));
            i3 = i4 + 32;
        }
        RosterEditor.writeBits(bArr, j2 + ((long) 0), 32, playerRecord.firstNameRef);
        RosterEditor.writeBits(bArr, j2 + ((long) 32), 32, playerRecord.lastNameRef);
        if (RosterPlayerMap.readBits(bArr, j2 + ((long) 0), 32) != (playerRecord.firstNameRef & 4294967295L) || RosterPlayerMap.readBits(bArr, j2 + ((long) 32), 32) != (playerRecord.lastNameRef & 4294967295L)) {
            throw new IOException("Player-to-coach identity verification failed.");
        }
    }

    private static long readTeamStaffRef(byte[] bArr, long j, int i, int i2) {
        if (i < 0 || i >= 30) {
            throw new IllegalArgumentException("teamSlot");
        }
        return RosterPlayerMap.readBits(bArr, j + (((long) i) * 6356) + 32 + ((long) i2), 32);
    }

    private static int countSequentialRecords(byte[] bArr, long j, long j2, int i, int i2) {
        int i3 = 0;
        long length = ((long) bArr.length) * 8;
        while (i3 < i2) {
            long j3 = j + (((long) i3) * ((long) i));
            if (j3 + 32 > length) {
                break;
            }
            if (RosterPlayerMap.readBits(bArr, j3, 32) != (j2 | (((long) i3) & 1048575))) {
                break;
            }
            i3++;
        }
        return i3;
    }

    private static long findSequentialTable(byte[] bArr, long j, int i, int i2) {
        byte[] bArr2 = {(byte) ((j >>> 24) & ((long) 255)), (byte) ((j >>> 16) & ((long) 255)), (byte) ((j >>> 8) & ((long) 255)), (byte) (j & ((long) 255))};
        for (int i3 = 0; i3 <= bArr.length - 4; i3++) {
            if (bArr[i3] == bArr2[0] && bArr[i3 + 1] == bArr2[1] && bArr[i3 + 2] == bArr2[2] && bArr[i3 + 3] == bArr2[3]) {
                long j2 = ((long) i3) * 8;
                if (verify(bArr, j2, j, i, i2)) {
                    return j2;
                }
            }
        }
        for (int i4 = 1; i4 < 8; i4++) {
            for (int i5 = 0; i5 < bArr.length - 4; i5++) {
                if (shiftedByte(bArr, i5, i4) == (bArr2[0] & 255) && shiftedByte(bArr, i5 + 1, i4) == (bArr2[1] & 255) && shiftedByte(bArr, i5 + 2, i4) == (bArr2[2] & 255) && shiftedByte(bArr, i5 + 3, i4) == (bArr2[3] & 255)) {
                    long j3 = (((long) i5) * 8) + ((long) i4);
                    if (verify(bArr, j3, j, i, i2)) {
                        return j3;
                    }
                }
            }
        }
        return -1L;
    }

    private static boolean verify(byte[] bArr, long j, long j2, int i, int i2) {
        int i3;
        long length = ((long) bArr.length) * 8;
        for (0; i3 < i2; i3 + 1) {
            long j3 = j + (((long) i3) * ((long) i));
            i3 = (j3 + 32 <= length && RosterPlayerMap.readBits(bArr, j3, 32) == (j2 | (((long) i3) & 1048575))) ? i3 + 1 : 0;
            return false;
        }
        return true;
    }

    private static int shiftedByte(byte[] bArr, int i, int i2) {
        return (((bArr[i] & 255) << i2) & 255) | ((bArr[i + 1] & 255) >>> (8 - i2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static String clean(String str) {
        return str == null ? "" : str.trim().replaceAll("\\s+", " ");
    }

    RosterStaffMap() {
    }
}
