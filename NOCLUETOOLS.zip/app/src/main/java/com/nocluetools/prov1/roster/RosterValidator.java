package com.nocluetools.prov1.roster;

import com.nocluetools.prov1.roster.RosterPlayerMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public final class RosterValidator {

    public static final class Report {
        public final int errors;
        public final List<String> items;
        public final int warnings;

        Report(int i, int i2, List<String> list) {
            this.errors = i;
            this.warnings = i2;
            this.items = list;
        }

        public String text() {
            StringBuilder sb = new StringBuilder();
            sb.append(String.format(Locale.US, "Errors: %d   Warnings: %d", new Integer(this.errors), new Integer(this.warnings)));
            if (this.items.isEmpty()) {
                sb.append("\n\nCore PLAYERDATA / TEAMDATA links passed.");
            } else {
                int iMin = Math.min(this.items.size(), 24);
                for (int i = 0; i < iMin; i++) {
                    sb.append("\n\n").append(this.items.get(i));
                }
                if (this.items.size() > iMin) {
                    sb.append("\n\n+").append(this.items.size() - iMin).append(" more");
                }
            }
            return sb.toString();
        }
    }

    RosterValidator() {
    }

    public static Report validate(byte[] bArr, RosterPlayerMap.Result result) {
        Integer num;
        ArrayList arrayList = new ArrayList();
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        HashMap map = new HashMap();
        HashMap map2 = new HashMap();
        for (RosterPlayerMap.TeamRecord teamRecord : result.activeTeams) {
            HashSet hashSet = new HashSet();
            HashSet hashSet2 = new HashSet();
            int i5 = 0;
            int i6 = 0;
            for (int i7 : teamRecord.playerSlots) {
                if (i7 < 0 || i7 >= result.players.size()) {
                    i++;
                    arrayList.add(new StringBuffer().append(new StringBuffer().append("ERROR - Team ").append(teamRecord.slot).toString()).append(" has an invalid PLAYERDATA reference.").toString());
                } else {
                    if (!hashSet2.add(new Integer(i7))) {
                        i++;
                        arrayList.add(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append("ERROR - Team ").append(teamRecord.slot).toString()).append(" references player slot S").toString()).append(String.format(Locale.US, "%04d", new Integer(i7))).toString()).append(" more than once.").toString());
                    }
                    Integer num2 = (Integer) map.put(new Integer(i7), new Integer(teamRecord.slot));
                    if (num2 != null && num2.intValue() != teamRecord.slot) {
                        i++;
                        arrayList.add(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append("ERROR - Player S").append(String.format(Locale.US, "%04d", new Integer(i7))).toString()).append(" is referenced by teams ").toString()).append(num2).toString()).append(" and ").toString()).append(teamRecord.slot).toString()).append(".").toString());
                    }
                    RosterPlayerMap.PlayerRecord playerRecord = result.players.get(i7);
                    if (RosterEditor.isPrimaryFreeAgent(bArr, result.playerTableBitOffset, i7)) {
                        i++;
                        arrayList.add(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append("ERROR - ").append(safeName(playerRecord)).toString()).append(" is on Team ").toString()).append(teamRecord.slot).toString()).append(" but PLAYERDATA marks Free Agent.").toString());
                    } else {
                        int primaryTeamId = RosterEditor.getPrimaryTeamId(bArr, result.playerTableBitOffset, i7);
                        if (primaryTeamId != teamRecord.slot) {
                            i++;
                            arrayList.add(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append("ERROR - ").append(safeName(playerRecord)).toString()).append(" TEAMDATA=").toString()).append(teamRecord.slot).toString()).append(" but PLAYERDATA TeamID=").toString()).append(primaryTeamId).toString()).append(".").toString());
                        }
                    }
                    if (playerRecord.jerseyNumber > 0 && !hashSet.add(new Integer(playerRecord.jerseyNumber))) {
                        i2++;
                        arrayList.add(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append("WARN - Team ").append(teamRecord.slot).toString()).append(" has duplicate jersey #").toString()).append(playerRecord.jerseyNumber).toString()).append(".").toString());
                    }
                    int rotationMinutes = RosterEditor.getRotationMinutes(bArr, result.playerTableBitOffset, i7);
                    if (rotationMinutes > 48) {
                        i++;
                        arrayList.add(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append("ERROR - ").append(safeName(playerRecord)).toString()).append(" has invalid rotation minutes ").toString()).append(rotationMinutes).toString()).append(".").toString());
                    } else {
                        i5 += rotationMinutes;
                        if (rotationMinutes > 0) {
                            i6++;
                        }
                    }
                    if (playerRecord.cyberfaceId > 0 && playerRecord.cyberfaceId < 65280 && (num = (Integer) map2.put(new Integer(playerRecord.cyberfaceId), new Integer(i7))) != null && num.intValue() != i7) {
                        i3++;
                    }
                }
            }
            if (i5 != 240) {
                i++;
                arrayList.add(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append("ERROR - Team ").append(teamRecord.slot).toString()).append(" rotation totals ").toString()).append(i5).toString()).append(" minutes instead of ").toString()).append(RosterEditor.TEAM_ROTATION_MINUTES_TOTAL).toString()).append(".").toString());
            }
            if (i6 < 5) {
                i++;
                arrayList.add(new StringBuffer().append(new StringBuffer().append("ERROR - Team ").append(teamRecord.slot).toString()).append(" has fewer than five players with rotation minutes.").toString());
            }
            try {
                int[] teamLineup = RosterEditor.getTeamLineup(bArr, result.teamTableBitOffset, teamRecord.slot, 0);
                int i8 = 0;
                while (true) {
                    if (i8 < teamLineup.length) {
                        if (RosterEditor.getRotationMinutes(bArr, result.playerTableBitOffset, teamLineup[i8]) <= 0) {
                            i++;
                            arrayList.add(new StringBuffer().append(new StringBuffer().append("ERROR - Team ").append(teamRecord.slot).toString()).append(" has a starter with 0 rotation minutes.").toString());
                            break;
                        }
                        i8++;
                    }
                }
            } catch (Exception e) {
                i++;
                arrayList.add(new StringBuffer().append(new StringBuffer().append("ERROR - Team ").append(teamRecord.slot).toString()).append(" Starting 5 is invalid.").toString());
            }
        }
        if (i3 > 0) {
            i2++;
            arrayList.add(new StringBuffer().append(new StringBuffer().append("WARN - ").append(i3).toString()).append(" duplicate active CFID assignments found. Review only if those players should use unique cyberfaces.").toString());
        }
        for (RosterPlayerMap.PlayerRecord playerRecord2 : result.players) {
            boolean zIsPrimaryFreeAgent = RosterEditor.isPrimaryFreeAgent(bArr, result.playerTableBitOffset, playerRecord2.slot);
            int primaryTeamId2 = RosterEditor.getPrimaryTeamId(bArr, result.playerTableBitOffset, playerRecord2.slot);
            if (!zIsPrimaryFreeAgent && primaryTeamId2 < 30 && !map.containsKey(new Integer(playerRecord2.slot))) {
                i4++;
            }
        }
        if (i4 > 0) {
            i2++;
            arrayList.add(new StringBuffer().append(new StringBuffer().append("WARN - ").append(i4).toString()).append(" PLAYERDATA records point to an NBA team without an active TEAMDATA roster reference.").toString());
        }
        Iterator<String> it = RosterNameEditor.validateDirectNameSafety(bArr, result.players, result.activeTeams).iterator();
        while (it.hasNext()) {
            i2++;
            arrayList.add(new StringBuffer().append(new StringBuffer().append("WARN - NAME SAFETY: ").append(it.next()).toString()).append(".").toString());
        }
        return new Report(i, i2, arrayList);
    }

    private static String safeName(RosterPlayerMap.PlayerRecord playerRecord) {
        return (playerRecord.displayName == null || playerRecord.displayName.trim().length() <= 0) ? new StringBuffer().append("Player S").append(String.format(Locale.US, "%04d", new Integer(playerRecord.slot))).toString() : playerRecord.displayName;
    }
}
