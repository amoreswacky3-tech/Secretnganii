package com.nocluetools.prov1.roster;

import com.nocluetools.prov1.roster.RosterCollegeMap;
import com.nocluetools.prov1.roster.RosterPlayerMap;
import com.nocluetools.prov1.roster.RosterStaffMap;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class RosterNameEditor {
    private static final int FIRST_CRC_BITS = 96;
    private static final int FIRST_REF_BITS = 32;
    private static final int LAST_CRC_BITS = 64;
    private static final int LAST_REF_BITS = 0;
    private static final int MAX_NAME_CHARS = 24;
    private static final int MAX_TEAM_ABBREV_CHARS = 8;
    private static final int MAX_TEAM_TEXT_CHARS = 24;
    private static final int PLAYER_STRIDE_BITS = 4075;
    private static final int PLAYER_TAG_BITS = 32;
    private static final int TEAM_ABBREV_REF_BITS = 672;
    private static final int TEAM_CITY_REF_BITS = 704;
    private static final int TEAM_DISPLAY_REF_BITS = 736;
    private static final int TEAM_NAME_CRC_BITS = 768;
    private static final int TEAM_NAME_REF_BITS = 640;
    private static final int TEAM_SHORT_NAME_CRC_BITS = 800;
    private static final int TEAM_STRIDE_BITS = 6356;
    private static final int TEAM_TAG_BITS = 32;

    public static final class EditResult {
        public final long firstNameRef;
        public final long lastNameRef;
        public final boolean reusedFirstSlot;
        public final boolean reusedLastSlot;

        EditResult(long j, long j2, boolean z, boolean z2) {
            this.firstNameRef = j;
            this.lastNameRef = j2;
            this.reusedFirstSlot = z;
            this.reusedLastSlot = z2;
        }
    }

    public static EditResult setPlayerName(byte[] bArr, long j, List<RosterPlayerMap.PlayerRecord> list, List<RosterPlayerMap.TeamRecord> list2, int i, String str, String str2) throws IOException {
        if (bArr == null || list == null || list2 == null) {
            throw new IOException("Roster is not loaded.");
        }
        if (i < 0 || i >= list.size()) {
            throw new IOException("Invalid player slot.");
        }
        String strNormalize = normalize(str, "First name");
        String strNormalize2 = normalize(str2, "Last name");
        if (strNormalize.length() == 0 && strNormalize2.length() == 0) {
            throw new IOException("Player name cannot be empty.");
        }
        long jFindStringPoolBitOffset = RosterNameResolver.findStringPoolBitOffset(bArr, list2);
        if (jFindStringPoolBitOffset < 0) {
            throw new IOException("This roster opened in compatibility mode; its name table is not writable yet.");
        }
        RosterPlayerMap.PlayerRecord playerRecord = list.get(i);
        byte[] bArr2 = (byte[]) bArr.clone();
        Map<Long, Integer> mapBuildReferenceCounts = buildReferenceCounts(list, list2);
        List<RosterStaffMap.StaffRecord> list3 = (List) null;
        try {
            list3 = RosterStaffMap.parse(bArr, list2).staff;
            for (RosterStaffMap.StaffRecord staffRecord : list3) {
                increment(mapBuildReferenceCounts, staffRecord.firstNameRef);
                increment(mapBuildReferenceCounts, staffRecord.lastNameRef);
            }
        } catch (Exception e) {
        }
        List<RosterCollegeMap.CollegeRecord> list4 = (List) null;
        try {
            list4 = RosterCollegeMap.parse(bArr, list2).colleges;
            Iterator<RosterCollegeMap.CollegeRecord> it = list4.iterator();
            while (it.hasNext()) {
                increment(mapBuildReferenceCounts, it.next().nameRef);
            }
        } catch (Exception e2) {
        }
        List<StringRange> listBuildStringRanges = buildStringRanges(bArr, jFindStringPoolBitOffset, list, list2, list3, list4);
        HashMap map = new HashMap();
        if (sameText(playerRecord.firstName, strNormalize)) {
            map.put(new Long(playerRecord.firstNameRef), strNormalize);
        }
        if (sameText(playerRecord.lastName, strNormalize2)) {
            map.put(new Long(playerRecord.lastNameRef), strNormalize2);
        }
        try {
            NameSlot nameSlotChooseSafePlayerSlot = chooseSafePlayerSlot(bArr, jFindStringPoolBitOffset, list, playerRecord, playerRecord.firstNameRef, playerRecord.firstName, strNormalize, mapBuildReferenceCounts, listBuildStringRanges, map);
            map.put(Long.valueOf(nameSlotChooseSafePlayerSlot.ref), strNormalize);
            if (nameSlotChooseSafePlayerSlot.donorPlayerSlot >= 0) {
                map.put(Long.valueOf(nameSlotChooseSafePlayerSlot.donorReplacementRef), RosterNameResolver.readRosterString(bArr, jFindStringPoolBitOffset, nameSlotChooseSafePlayerSlot.donorReplacementRef));
            }
            reserveChosenRange(nameSlotChooseSafePlayerSlot, strNormalize, listBuildStringRanges);
            NameSlot nameSlotChooseSafePlayerSlot2 = chooseSafePlayerSlot(bArr, jFindStringPoolBitOffset, list, playerRecord, playerRecord.lastNameRef, playerRecord.lastName, strNormalize2, mapBuildReferenceCounts, listBuildStringRanges, map);
            map.put(Long.valueOf(nameSlotChooseSafePlayerSlot2.ref), strNormalize2);
            if (nameSlotChooseSafePlayerSlot2.donorPlayerSlot >= 0) {
                map.put(Long.valueOf(nameSlotChooseSafePlayerSlot2.donorReplacementRef), RosterNameResolver.readRosterString(bArr, jFindStringPoolBitOffset, nameSlotChooseSafePlayerSlot2.donorReplacementRef));
            }
            reserveChosenRange(nameSlotChooseSafePlayerSlot2, strNormalize2, listBuildStringRanges);
            boolean z = !sameText(playerRecord.firstName, strNormalize);
            boolean z2 = !sameText(playerRecord.lastName, strNormalize2);
            ArrayList arrayList = new ArrayList();
            long jPlayerPayload = playerPayload(j, i);
            applyDonorEvacuation(bArr, j, nameSlotChooseSafePlayerSlot, arrayList);
            applyDonorEvacuation(bArr, j, nameSlotChooseSafePlayerSlot2, arrayList);
            if (z) {
                arrayList.add(new BitRange(jPlayerPayload + ((long) 32), jPlayerPayload + ((long) 32) + 32));
                arrayList.add(new BitRange(jPlayerPayload + ((long) FIRST_CRC_BITS), jPlayerPayload + ((long) FIRST_CRC_BITS) + 32));
                if (nameSlotChooseSafePlayerSlot.writeValue) {
                    writeString(bArr, jFindStringPoolBitOffset, nameSlotChooseSafePlayerSlot.ref, strNormalize, nameSlotChooseSafePlayerSlot.capacity);
                    addStringWriteRange(arrayList, jFindStringPoolBitOffset, nameSlotChooseSafePlayerSlot.ref, strNormalize.length());
                }
                writeBits(bArr, jPlayerPayload + ((long) 32), 32, nameSlotChooseSafePlayerSlot.ref);
                writeBits(bArr, jPlayerPayload + ((long) FIRST_CRC_BITS), 32, 0L);
            }
            if (z2) {
                arrayList.add(new BitRange(jPlayerPayload + ((long) 0), jPlayerPayload + ((long) 0) + 32));
                arrayList.add(new BitRange(jPlayerPayload + ((long) LAST_CRC_BITS), jPlayerPayload + ((long) LAST_CRC_BITS) + 32));
                if (nameSlotChooseSafePlayerSlot2.writeValue) {
                    writeString(bArr, jFindStringPoolBitOffset, nameSlotChooseSafePlayerSlot2.ref, strNormalize2, nameSlotChooseSafePlayerSlot2.capacity);
                    addStringWriteRange(arrayList, jFindStringPoolBitOffset, nameSlotChooseSafePlayerSlot2.ref, strNormalize2.length());
                }
                writeBits(bArr, jPlayerPayload + ((long) 0), 32, nameSlotChooseSafePlayerSlot2.ref);
                writeBits(bArr, jPlayerPayload + ((long) LAST_CRC_BITS), 32, 0L);
            }
            verifyNoCollateralNameChanges(bArr, list, list2, list3, i, strNormalize, strNormalize2);
            verifyCrcPolicy(bArr, j, i, playerRecord, z, z2);
            verifyOnlyAllowedBitsChanged(bArr2, bArr, arrayList);
            return new EditResult(nameSlotChooseSafePlayerSlot.ref, nameSlotChooseSafePlayerSlot2.ref, nameSlotChooseSafePlayerSlot.borrowed, nameSlotChooseSafePlayerSlot2.borrowed);
        } catch (Exception e3) {
            System.arraycopy(bArr2, 0, bArr, 0, bArr.length);
            if (e3 instanceof IOException) {
                throw ((IOException) e3);
            }
            throw new IOException(e3.getMessage() == null ? "Player name edit failed safely." : e3.getMessage());
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:223:0x0703 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:231:0x05c1 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void setTeamIdentity(byte[] r57, long r58, long r60, java.util.List<com.nocluetools.prov1.roster.RosterPlayerMap.PlayerRecord> r62, java.util.List<com.nocluetools.prov1.roster.RosterPlayerMap.TeamRecord> r63, int r64, java.lang.String r65, java.lang.String r66, java.lang.String r67, java.lang.String r68) throws java.io.IOException {
        /*
            Method dump skipped, instruction units count: 1975
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.nocluetools.prov1.roster.RosterNameEditor.setTeamIdentity(byte[], long, long, java.util.List, java.util.List, int, java.lang.String, java.lang.String, java.lang.String, java.lang.String):void");
    }

    public static int getTeamStringCapacity(byte[] bArr, List<RosterPlayerMap.TeamRecord> list, int i, int i2) throws IOException {
        long j;
        if (bArr == null || list == null || i < 0 || i >= list.size()) {
            return -1;
        }
        long jFindStringPoolBitOffset = RosterNameResolver.findStringPoolBitOffset(bArr, list);
        if (jFindStringPoolBitOffset < 0) {
            return -1;
        }
        RosterPlayerMap.TeamRecord teamRecord = list.get(i);
        if (i2 == 0) {
            j = teamRecord.cityRef;
        } else if (i2 == 1) {
            j = teamRecord.teamNameRef;
        } else if (i2 == 2) {
            j = teamRecord.abbreviationRef;
        } else {
            if (i2 != 3) {
                return -1;
            }
            j = teamRecord.displayRef;
        }
        return RosterNameResolver.getRosterStringLength(bArr, jFindStringPoolBitOffset, j);
    }

    private static String normalizeTeamText(String str, String str2, boolean z) throws IOException {
        String str3 = str;
        if (str3 == null) {
            str3 = "";
        }
        String strReplaceAll = str3.trim().replaceAll("\\s+", " ");
        if (!z && strReplaceAll.length() == 0) {
            throw new IOException(new StringBuffer().append(str2).append(" cannot be empty.").toString());
        }
        if (strReplaceAll.length() > 24) {
            throw new IOException(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(str2).append(" must be ").toString()).append(24).toString()).append(" characters or less.").toString());
        }
        for (int i = 0; i < strReplaceAll.length(); i++) {
            if (Character.isISOControl(strReplaceAll.charAt(i))) {
                throw new IOException(new StringBuffer().append(str2).append(" contains an unsupported control character.").toString());
            }
        }
        return strReplaceAll;
    }

    private static String normalizeTeamAbbreviation(String str) throws IOException {
        String str2 = str;
        if (str2 == null) {
            str2 = "";
        }
        String upperCase = str2.trim().replaceAll("\\s+", " ").toUpperCase(Locale.US);
        if (upperCase.length() < 1 || upperCase.length() > MAX_TEAM_ABBREV_CHARS) {
            throw new IOException(new StringBuffer().append(new StringBuffer().append("Abbreviation must be 1-").append(MAX_TEAM_ABBREV_CHARS).toString()).append(" characters.").toString());
        }
        for (int i = 0; i < upperCase.length(); i++) {
            if (Character.isISOControl(upperCase.charAt(i))) {
                throw new IOException("Abbreviation contains an unsupported control character.");
            }
        }
        return upperCase;
    }

    private static NameSlot chooseSafePlayerSlot(byte[] bArr, long j, List<RosterPlayerMap.PlayerRecord> list, RosterPlayerMap.PlayerRecord playerRecord, long j2, String str, String str2, Map<Long, Integer> map, List<StringRange> list2, Map<Long, String> map2) throws IOException {
        String str3;
        int rosterStringLength;
        String str4;
        int rosterStringLength2;
        if (sameText(str, str2) && RosterNameResolver.isSupportedStringRef(j2) && (((str4 = map2.get(Long.valueOf(j2))) == null || sameText(str4, str2)) && (rosterStringLength2 = RosterNameResolver.getRosterStringLength(bArr, j, j2)) >= str2.length())) {
            return new NameSlot(j2, rosterStringLength2, false, false, false);
        }
        NameSlot nameSlotFindExistingExactPlayerRef = findExistingExactPlayerRef(bArr, j, list, str2, map2, -1L);
        if (nameSlotFindExistingExactPlayerRef != null) {
            return nameSlotFindExistingExactPlayerRef;
        }
        long[] jArr = {j2};
        NameSlot nameSlot = (NameSlot) null;
        for (int i = 0; i < jArr.length; i++) {
            long j3 = jArr[i];
            if (RosterNameResolver.isSupportedStringRef(j3) && (((str3 = map2.get(Long.valueOf(j3))) == null || sameText(str3, str2)) && isTargetOwnedExclusive(j3, playerRecord, map) && (rosterStringLength = RosterNameResolver.getRosterStringLength(bArr, j, j3)) >= str2.length() && isRangeIsolated(j3, rosterStringLength, list2) && (nameSlot == null || rosterStringLength < nameSlot.capacity))) {
                nameSlot = new NameSlot(j3, rosterStringLength, j3 != j2, true, false);
            }
        }
        if (nameSlot != null) {
            return nameSlot;
        }
        NameSlot nameSlotFindGameOwnedDonorSlot = findGameOwnedDonorSlot(bArr, j, list, playerRecord, str2, map, list2, map2);
        if (nameSlotFindGameOwnedDonorSlot != null) {
            return nameSlotFindGameOwnedDonorSlot;
        }
        throw new IOException(new StringBuffer().append(new StringBuffer().append("Name edit needs a larger game-owned string slot. ").append("V4 blocked this rename instead of writing into blank/padding storage. ").toString()).append("Try a shorter name; the roster was left unchanged.").toString());
    }

    private static NameSlot findGameOwnedDonorSlot(byte[] bArr, long j, List<RosterPlayerMap.PlayerRecord> list, RosterPlayerMap.PlayerRecord playerRecord, String str, Map<Long, Integer> map, List<StringRange> list2, Map<Long, String> map2) {
        String str2;
        Integer num;
        int rosterStringLength;
        NameSlot nameSlotFindExistingExactPlayerRef;
        for (RosterPlayerMap.PlayerRecord playerRecord2 : list) {
            if (playerRecord2.slot != playerRecord.slot && playerRecord2.activeTeamSlot < 0) {
                long[] jArr = {playerRecord2.firstNameRef, playerRecord2.lastNameRef};
                String[] strArr = {playerRecord2.firstName, playerRecord2.lastName};
                int i = 0;
                while (i < jArr.length) {
                    long j2 = jArr[i];
                    if (RosterNameResolver.isSupportedStringRef(j2) && (((str2 = map2.get(Long.valueOf(j2))) == null || sameText(str2, str)) && (num = map.get(Long.valueOf(j2))) != null && num.intValue() == 1 && (rosterStringLength = RosterNameResolver.getRosterStringLength(bArr, j, j2)) >= str.length() && isRangeIsolated(j2, rosterStringLength, list2))) {
                        String strTrim = strArr[i] == null ? "" : strArr[i].trim();
                        if (strTrim.length() != 0 && (nameSlotFindExistingExactPlayerRef = findExistingExactPlayerRef(bArr, j, list, strTrim, map2, j2)) != null && nameSlotFindExistingExactPlayerRef.ref != j2 && nameSlotFindExistingExactPlayerRef.ref != playerRecord.firstNameRef && nameSlotFindExistingExactPlayerRef.ref != playerRecord.lastNameRef) {
                            return new NameSlot(j2, rosterStringLength, true, true, false, playerRecord2.slot, i == 0, nameSlotFindExistingExactPlayerRef.ref);
                        }
                    }
                    i++;
                }
            }
        }
        return (NameSlot) null;
    }

    private static NameSlot findExistingExactPlayerRef(byte[] bArr, long j, List<RosterPlayerMap.PlayerRecord> list, String str, Map<Long, String> map, long j2) {
        String str2;
        int rosterStringLength;
        HashSet hashSet = new HashSet();
        for (RosterPlayerMap.PlayerRecord playerRecord : list) {
            for (long j3 : new long[]{playerRecord.firstNameRef, playerRecord.lastNameRef}) {
                Long lValueOf = Long.valueOf(j3);
                if (j3 != j2 && hashSet.add(lValueOf) && RosterNameResolver.isSupportedStringRef(j3) && (((str2 = map.get(lValueOf)) == null || sameText(str2, str)) && (rosterStringLength = RosterNameResolver.getRosterStringLength(bArr, j, j3)) >= str.length() && sameText(RosterNameResolver.readRosterString(bArr, j, j3), str))) {
                    return new NameSlot(j3, rosterStringLength, true, false, false);
                }
            }
        }
        return (NameSlot) null;
    }

    private static boolean isTargetOwnedExclusive(long j, RosterPlayerMap.PlayerRecord playerRecord, Map<Long, Integer> map) {
        Integer num = map.get(Long.valueOf(j));
        int i = 0;
        if (playerRecord.firstNameRef == j) {
            i = 0 + 1;
        }
        if (playerRecord.lastNameRef == j) {
            i++;
        }
        return num != null && num.intValue() == i;
    }

    private static boolean isRangeIsolated(long j, int i, List<StringRange> list) {
        long jStringIndex = stringIndex(j);
        long j2 = jStringIndex + ((long) i) + 1;
        for (StringRange stringRange : list) {
            if (stringRange.ref != j && jStringIndex < stringRange.end && stringRange.start < j2) {
                return false;
            }
        }
        return true;
    }

    private static List<StringRange> buildStringRanges(byte[] bArr, long j, List<RosterPlayerMap.PlayerRecord> list, List<RosterPlayerMap.TeamRecord> list2, List<RosterStaffMap.StaffRecord> list3, List<RosterCollegeMap.CollegeRecord> list4) {
        ArrayList arrayList = new ArrayList();
        HashSet hashSet = new HashSet();
        for (RosterPlayerMap.PlayerRecord playerRecord : list) {
            addStringRange(bArr, j, playerRecord.firstNameRef, hashSet, arrayList);
            addStringRange(bArr, j, playerRecord.lastNameRef, hashSet, arrayList);
        }
        for (RosterPlayerMap.TeamRecord teamRecord : list2) {
            addStringRange(bArr, j, teamRecord.teamNameRef, hashSet, arrayList);
            addStringRange(bArr, j, teamRecord.abbreviationRef, hashSet, arrayList);
            addStringRange(bArr, j, teamRecord.cityRef, hashSet, arrayList);
            addStringRange(bArr, j, teamRecord.displayRef, hashSet, arrayList);
        }
        if (list3 != null) {
            for (RosterStaffMap.StaffRecord staffRecord : list3) {
                addStringRange(bArr, j, staffRecord.firstNameRef, hashSet, arrayList);
                addStringRange(bArr, j, staffRecord.lastNameRef, hashSet, arrayList);
            }
        }
        if (list4 != null) {
            Iterator<RosterCollegeMap.CollegeRecord> it = list4.iterator();
            while (it.hasNext()) {
                addStringRange(bArr, j, it.next().nameRef, hashSet, arrayList);
            }
        }
        return arrayList;
    }

    private static void addStringRange(byte[] bArr, long j, long j2, Set<Long> set, List<StringRange> list) {
        int rosterStringLength;
        if (RosterNameResolver.isSupportedStringRef(j2) && set.add(Long.valueOf(j2)) && (rosterStringLength = RosterNameResolver.getRosterStringLength(bArr, j, j2)) >= 0) {
            long jStringIndex = stringIndex(j2);
            list.add(new StringRange(j2, jStringIndex, jStringIndex + ((long) rosterStringLength) + 1));
        }
    }

    private static long stringIndex(long j) {
        return j & 2097151;
    }

    private static void verifyNoCollateralNameChanges(byte[] bArr, List<RosterPlayerMap.PlayerRecord> list, List<RosterPlayerMap.TeamRecord> list2, List<RosterStaffMap.StaffRecord> list3, int i, String str, String str2) throws IOException {
        RosterPlayerMap.Result result = RosterPlayerMap.parse(bArr);
        if (result.players.size() != list.size()) {
            throw new IOException("Player table changed unexpectedly.");
        }
        String strReplaceAll = new StringBuffer().append(new StringBuffer().append(str).append(" ").toString()).append(str2).toString().trim().replaceAll("\\s+", " ");
        if (!result.players.get(i).displayName.equals(strReplaceAll)) {
            throw new IOException(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append("Selected player name verification failed after writeback: expected ").append(strReplaceAll).toString()).append("; got ").toString()).append(result.players.get(i).displayName).toString());
        }
        for (int i2 = 0; i2 < list.size(); i2++) {
            if (i2 != i) {
                String str3 = list.get(i2).displayName == null ? "" : list.get(i2).displayName;
                String str4 = result.players.get(i2).displayName == null ? "" : result.players.get(i2).displayName;
                if (!str3.equals(str4)) {
                    throw new IOException(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append("Name edit would also change Player ").append(i2).toString()).append(" (").toString()).append(str3).toString()).append(" -> ").toString()).append(str4).toString()).append("). Edit rolled back.").toString());
                }
            }
        }
        if (result.activeTeams.size() == list2.size()) {
            for (int i3 = 0; i3 < list2.size(); i3++) {
                if (!(list2.get(i3).fullName == null ? "" : list2.get(i3).fullName).equals(result.activeTeams.get(i3).fullName == null ? "" : result.activeTeams.get(i3).fullName)) {
                    throw new IOException("Name edit would modify a team string. Edit rolled back.");
                }
            }
        }
        if (list3 != null) {
            try {
                RosterStaffMap.Result result2 = RosterStaffMap.parse(bArr, result.activeTeams);
                int iMin = Math.min(list3.size(), result2.staff.size());
                for (int i4 = 0; i4 < iMin; i4++) {
                    if (!list3.get(i4).displayName.equals(result2.staff.get(i4).displayName)) {
                        throw new IOException("Name edit would modify a staff/coach name. Edit rolled back.");
                    }
                }
            } catch (IOException e) {
                throw e;
            } catch (Exception e2) {
            }
        }
    }

    private static void applyDonorEvacuation(byte[] bArr, long j, NameSlot nameSlot, List<BitRange> list) throws IOException {
        if (nameSlot != null && nameSlot.donorPlayerSlot >= 0) {
            long jPlayerPayload = playerPayload(j, nameSlot.donorPlayerSlot) + ((long) (nameSlot.donorFirstName ? 32 : 0));
            list.add(new BitRange(jPlayerPayload, jPlayerPayload + 32));
            writeBits(bArr, jPlayerPayload, 32, nameSlot.donorReplacementRef);
            if (RosterPlayerMap.readBits(bArr, jPlayerPayload, 32) != (nameSlot.donorReplacementRef & 4294967295L)) {
                throw new IOException("Game-owned donor name reference did not verify after evacuation.");
            }
        }
    }

    private static void verifyCrcPolicy(byte[] bArr, long j, int i, RosterPlayerMap.PlayerRecord playerRecord, boolean z, boolean z2) throws IOException {
        long jPlayerPayload = playerPayload(j, i);
        long bits = RosterPlayerMap.readBits(bArr, jPlayerPayload + ((long) FIRST_CRC_BITS), 32);
        long bits2 = RosterPlayerMap.readBits(bArr, jPlayerPayload + ((long) LAST_CRC_BITS), 32);
        if (z) {
            if (bits != 0) {
                throw new IOException("First-name CRC did not switch to direct-string mode.");
            }
        } else if (bits != (playerRecord.firstNameCrc & 4294967295L)) {
            throw new IOException("Unchanged first-name CRC was modified unexpectedly.");
        }
        if (z2) {
            if (bits2 != 0) {
                throw new IOException("Last-name CRC did not switch to direct-string mode.");
            }
        } else if (bits2 != (playerRecord.lastNameCrc & 4294967295L)) {
            throw new IOException("Unchanged last-name CRC was modified unexpectedly.");
        }
    }

    public static List<String> validateDirectNameSafety(byte[] bArr, List<RosterPlayerMap.PlayerRecord> list, List<RosterPlayerMap.TeamRecord> list2) {
        ArrayList arrayList = new ArrayList();
        if (bArr == null || list == null || list2 == null) {
            arrayList.add("Roster name tables are unavailable.");
            return arrayList;
        }
        long jFindStringPoolBitOffset = RosterNameResolver.findStringPoolBitOffset(bArr, list2);
        if (jFindStringPoolBitOffset < 0) {
            arrayList.add("Roster string pool could not be validated.");
            return arrayList;
        }
        HashSet hashSet = new HashSet();
        Iterator<RosterPlayerMap.TeamRecord> it = list2.iterator();
        while (it.hasNext()) {
            for (int i : it.next().playerSlots) {
                if (i >= 0 && i < list.size()) {
                    hashSet.add(Integer.valueOf(i));
                }
            }
        }
        Iterator it2 = hashSet.iterator();
        while (it2.hasNext()) {
            RosterPlayerMap.PlayerRecord playerRecord = list.get(((Integer) it2.next()).intValue());
            validateDirectComponent(bArr, jFindStringPoolBitOffset, playerRecord, true, arrayList);
            validateDirectComponent(bArr, jFindStringPoolBitOffset, playerRecord, false, arrayList);
        }
        return arrayList;
    }

    private static void validateDirectComponent(byte[] bArr, long j, RosterPlayerMap.PlayerRecord playerRecord, boolean z, List<String> list) {
        if ((z ? playerRecord.firstNameCrc : playerRecord.lastNameCrc) == 0) {
            long j2 = z ? playerRecord.firstNameRef : playerRecord.lastNameRef;
            String str = z ? "first" : "last";
            if (!RosterNameResolver.isSupportedStringRef(j2)) {
                list.add(String.format(Locale.US, "Player S%04d has invalid direct %s-name ref %08X", new Integer(playerRecord.slot), str, new Long(j2)));
            } else if (RosterNameResolver.cleanForValidation(RosterNameResolver.readRosterString(bArr, j, j2)).length() == 0) {
                list.add(String.format(Locale.US, "Player S%04d has blank direct %s name at %08X", new Integer(playerRecord.slot), str, new Long(j2)));
            }
        }
    }

    private static Map<Long, Integer> buildReferenceCounts(List<RosterPlayerMap.PlayerRecord> list, List<RosterPlayerMap.TeamRecord> list2) {
        HashMap map = new HashMap();
        for (RosterPlayerMap.PlayerRecord playerRecord : list) {
            increment(map, playerRecord.firstNameRef);
            increment(map, playerRecord.lastNameRef);
        }
        for (RosterPlayerMap.TeamRecord teamRecord : list2) {
            increment(map, teamRecord.teamNameRef);
            increment(map, teamRecord.abbreviationRef);
            increment(map, teamRecord.cityRef);
            increment(map, teamRecord.displayRef);
        }
        return map;
    }

    private static void increment(Map<Long, Integer> map, long j) {
        if (RosterNameResolver.isSupportedStringRef(j)) {
            Long lValueOf = Long.valueOf(j);
            Integer num = map.get(lValueOf);
            map.put(lValueOf, Integer.valueOf(num == null ? 1 : num.intValue() + 1));
        }
    }

    private static void decrement(Map<Long, Integer> map, long j) {
        if (RosterNameResolver.isSupportedStringRef(j)) {
            Long lValueOf = Long.valueOf(j);
            Integer num = map.get(lValueOf);
            if (num == null || num.intValue() <= 1) {
                map.remove(lValueOf);
            } else {
                map.put(lValueOf, Integer.valueOf(num.intValue() - 1));
            }
        }
    }

    private static String normalize(String str, String str2) throws IOException {
        if (str == null) {
            return "";
        }
        String strReplaceAll = str.trim().replaceAll("\\s+", " ");
        if (strReplaceAll.length() > 24) {
            throw new IOException(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(str2).append(" must be ").toString()).append(24).toString()).append(" characters or less.").toString());
        }
        for (int i = 0; i < strReplaceAll.length(); i++) {
            if (Character.isISOControl(strReplaceAll.charAt(i))) {
                throw new IOException(new StringBuffer().append(str2).append(" contains an unsupported control character.").toString());
            }
        }
        return strReplaceAll;
    }

    private static boolean sameText(String str, String str2) {
        return (str == null ? "" : str.trim()).equals(str2 == null ? "" : str2.trim());
    }

    private static void writeString(byte[] bArr, long j, long j2, String str, int i) throws IOException {
        if (!RosterNameResolver.isSupportedStringRef(j2)) {
            throw new IOException("Unsupported roster string reference.");
        }
        if (str.length() > i) {
            throw new IOException("Name does not fit the selected roster string slot.");
        }
        long j3 = j + ((j2 & 2097151) * 16);
        for (int i2 = 0; i2 < str.length(); i2++) {
            char cCharAt = str.charAt(i2);
            writeBits(bArr, j3 + (((long) i2) * 16), 16, ((long) (((cCharAt & 255) << MAX_TEAM_ABBREV_CHARS) | ((cCharAt >>> '\b') & 255))) & 65535);
        }
        writeBits(bArr, j3 + (((long) str.length()) * 16), 16, 0L);
    }

    private static long teamPayload(long j, int i) {
        return j + (((long) i) * ((long) TEAM_STRIDE_BITS)) + ((long) 32);
    }

    private static long playerPayload(long j, int i) {
        return j + (((long) i) * ((long) PLAYER_STRIDE_BITS)) + ((long) 32);
    }

    private static void writeBits(byte[] bArr, long j, int i, long j2) {
        long length = ((long) bArr.length) * 8;
        if (i < 1 || i > 32 || j < 0 || j + ((long) i) > length) {
            throw new IllegalArgumentException("writeBits out of range");
        }
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = (int) ((j2 >>> ((i - 1) - i2)) & 1);
            long j3 = j + ((long) i2);
            int i4 = (int) (j3 >>> 3);
            int i5 = 1 << (7 - (((int) j3) & 7));
            int i6 = bArr[i4] & 255;
            bArr[i4] = (byte) (i3 == 0 ? i6 & (i5 ^ (-1)) : i6 | i5);
        }
    }

    private static void reserveChosenRange(NameSlot nameSlot, String str, List<StringRange> list) {
        if (nameSlot != null && RosterNameResolver.isSupportedStringRef(nameSlot.ref)) {
            long jStringIndex = stringIndex(nameSlot.ref);
            list.add(new StringRange(nameSlot.ref, jStringIndex, jStringIndex + Math.max(1, str == null ? 1 : ((long) str.length()) + 1)));
        }
    }

    private static void addStringWriteRange(List<BitRange> list, long j, long j2, int i) {
        long jStringIndex = j + (stringIndex(j2) * 16);
        list.add(new BitRange(jStringIndex, jStringIndex + ((((long) i) + 1) * 16)));
    }

    private static void verifyOnlyAllowedBitsChanged(byte[] bArr, byte[] bArr2, List<BitRange> list) throws IOException {
        if (bArr.length != bArr2.length) {
            throw new IOException("Roster size changed during name edit.");
        }
        for (int i = 0; i < bArr.length; i++) {
            int i2 = (bArr[i] ^ bArr2[i]) & 255;
            if (i2 != 0) {
                for (int i3 = 0; i3 < MAX_TEAM_ABBREV_CHARS; i3++) {
                    if ((i2 & (1 << (7 - i3))) != 0 && !isAllowedBit((((long) i) * 8) + ((long) i3), list)) {
                        throw new IOException("Name edit touched data outside the selected player's isolated name storage.");
                    }
                }
            }
        }
    }

    private static boolean isAllowedBit(long j, List<BitRange> list) {
        for (BitRange bitRange : list) {
            if (j >= bitRange.start && j < bitRange.end) {
                return true;
            }
        }
        return false;
    }

    private static final class BitRange {
        final long end;
        final long start;

        BitRange(long j, long j2) {
            this.start = j;
            this.end = j2;
        }
    }

    private static final class TeamStringSlot {
        final int capacity;
        final String currentText;
        final int externalUses;
        final long ref;

        TeamStringSlot(long j, int i, String str, int i2) {
            this.ref = j;
            this.capacity = i;
            this.currentText = str == null ? "" : str;
            this.externalUses = i2;
        }
    }

    private static final class NameSlot {
        final boolean arena;
        final boolean borrowed;
        final int capacity;
        final boolean donorFirstName;
        final int donorPlayerSlot;
        final long donorReplacementRef;
        final long ref;
        final boolean writeValue;

        NameSlot(long j, int i, boolean z, boolean z2, boolean z3) {
            this(j, i, z, z2, z3, -1, false, 0L);
        }

        NameSlot(long j, int i, boolean z, boolean z2, boolean z3, int i2, boolean z4, long j2) {
            this.ref = j;
            this.capacity = i;
            this.borrowed = z;
            this.writeValue = z2;
            this.arena = z3;
            this.donorPlayerSlot = i2;
            this.donorFirstName = z4;
            this.donorReplacementRef = j2;
        }
    }

    private static final class StringRange {
        final long end;
        final long ref;
        final long start;

        StringRange(long j, long j2, long j3) {
            this.ref = j;
            this.start = j2;
            this.end = j3;
        }
    }

    RosterNameEditor() {
    }
}
