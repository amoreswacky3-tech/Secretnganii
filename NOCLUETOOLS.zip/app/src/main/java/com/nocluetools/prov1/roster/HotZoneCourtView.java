package com.nocluetools.prov1.roster;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class HotZoneCourtView extends View {
    private static final String[] SHORT_LABELS = {"RIM", "CLOSE L", "CLOSE C", "CLOSE R", "MID L", "MID ML", "MID C", "MID MR", "MID R", "3PT LC", "3PT LW", "3PT TOP", "3PT RW", "3PT RC"};
    private static final int ZONE_COUNT = 14;
    private final Paint fill;
    private final Paint label;
    private OnZoneChangedListener listener;
    private final Paint state;
    private final Paint stroke;
    private final int[] values;
    private final RectF[] zones;

    public interface OnZoneChangedListener {
        void onZoneChanged(int i, int i2);
    }

    public HotZoneCourtView(Context context) {
        super(context);
        this.values = new int[ZONE_COUNT];
        this.zones = new RectF[ZONE_COUNT];
        this.fill = new Paint(1);
        this.stroke = new Paint(1);
        this.label = new Paint(1);
        this.state = new Paint(1);
        setFocusable(true);
        setClickable(true);
        this.stroke.setStyle(Paint.Style.STROKE);
        this.stroke.setStrokeWidth(dp(1.2f));
        this.stroke.setColor(Color.rgb(102, 111, 130));
        this.label.setColor(-1);
        this.label.setTypeface(Typeface.DEFAULT_BOLD);
        this.label.setTextAlign(Paint.Align.CENTER);
        this.state.setColor(Color.rgb(224, 228, 236));
        this.state.setTextAlign(Paint.Align.CENTER);
        setContentDescription("Hot Zones court editor");
    }

    public void setOnZoneChangedListener(OnZoneChangedListener onZoneChangedListener) {
        this.listener = onZoneChangedListener;
    }

    public void setValues(int[] iArr) {
        if (iArr != null && iArr.length == ZONE_COUNT) {
            for (int i = 0; i < ZONE_COUNT; i++) {
                this.values[i] = clamp(iArr[i]);
            }
            invalidate();
        }
    }

    public int[] getValues() {
        return (int[]) this.values.clone();
    }

    public static String stateName(int i) {
        switch (i) {
            case RosterStaffMap.STAFF_FIRST_REF_BITS /* 0 */:
                return "Cold";
            case 1:
                return "Neutral";
            case 2:
                return "Hot";
            default:
                return "Very Hot";
        }
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float width = getWidth();
        float height = getHeight();
        if (width > 0 && height > 0) {
            this.fill.setColor(Color.rgb(20, 23, 29));
            canvas.drawRoundRect(new RectF(0, 0, width, height), dp(16), dp(16), this.fill);
            float fDp = dp(10);
            float fDp2 = dp(4);
            float f = width - fDp;
            float f2 = height - fDp;
            float f3 = f - fDp;
            float f4 = f2 - fDp;
            this.stroke.setColor(Color.rgb(74, 84, 102));
            canvas.drawRect(fDp, fDp, f, f2, this.stroke);
            canvas.drawRect(new RectF(fDp + (f3 * 0.35f), f2 - (f4 * 0.34f), fDp + (f3 * 0.65f), f2), this.stroke);
            canvas.drawArc(new RectF(fDp + (f3 * 0.25f), f2 - (f3 * 0.5f), fDp + (f3 * 0.75f), f2 + (f3 * 0.0f)), 180, 180, false, this.stroke);
            float f5 = fDp + (f4 * 0.04f);
            float f6 = fDp + (f4 * 0.28f);
            makeRow(9, 5, fDp + fDp2, f - fDp2, f5, f6, fDp2);
            makeRow(4, 5, fDp + fDp2, f - fDp2, fDp + (f4 * 0.31f), fDp + (f4 * 0.56f), fDp2);
            makeRow(1, 3, fDp + (f3 * 0.13f), f - (f3 * 0.13f), fDp + (f4 * 0.59f), fDp + (f4 * 0.82f), fDp2);
            this.zones[0] = new RectF(fDp + (f3 * 0.35f), fDp + (f4 * 0.84f), fDp + (f3 * 0.65f), f2 - fDp2);
            for (int i = 0; i < ZONE_COUNT; i++) {
                drawZone(canvas, i, this.zones[i]);
            }
        }
    }

    private void makeRow(int i, int i2, float f, float f2, float f3, float f4, float f5) {
        float f6 = ((f2 - f) - (f5 * (i2 - 1))) / i2;
        for (int i3 = 0; i3 < i2; i3++) {
            float f7 = f + (i3 * (f6 + f5));
            this.zones[i + i3] = new RectF(f7, f3, f7 + f6, f4);
        }
    }

    private void drawZone(Canvas canvas, int i, RectF rectF) {
        if (rectF != null) {
            this.fill.setColor(zoneColor(this.values[i]));
            canvas.drawRoundRect(rectF, dp(8), dp(8), this.fill);
            this.stroke.setColor(Color.rgb(91, 101, 121));
            canvas.drawRoundRect(rectF, dp(8), dp(8), this.stroke);
            float fCenterX = rectF.centerX();
            float fCenterY = rectF.centerY();
            float fMax = Math.max(8.0f, Math.min(11.0f, rectF.width() / dp(6.0f)));
            this.label.setTextSize(sp(fMax));
            this.state.setTextSize(sp(Math.max(8.0f, fMax - 1.0f)));
            canvas.drawText(SHORT_LABELS[i], fCenterX, fCenterY - dp(2), this.label);
            canvas.drawText(stateName(this.values[i]).toUpperCase(), fCenterX, fCenterY + dp(12), this.state);
        }
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getActionMasked() != 1) {
            return true;
        }
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        for (int i = 0; i < ZONE_COUNT; i++) {
            RectF rectF = this.zones[i];
            if (rectF != null && rectF.contains(x, y)) {
                this.values[i] = (this.values[i] + 1) & 3;
                performClick();
                invalidate();
                if (this.listener != null) {
                    this.listener.onZoneChanged(i, this.values[i]);
                }
                return true;
            }
        }
        return true;
    }

    @Override // android.view.View
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private int zoneColor(int i) {
        switch (i) {
            case RosterStaffMap.STAFF_FIRST_REF_BITS /* 0 */:
                return Color.rgb(89, 42, 48);
            case 1:
                return Color.rgb(63, 68, 78);
            case 2:
                return Color.rgb(146, 93, 33);
            default:
                return Color.rgb(42, 108, 72);
        }
    }

    private int clamp(int i) {
        if (i < 0) {
            return 0;
        }
        if (i > 3) {
            return 3;
        }
        return i;
    }

    private float dp(float f) {
        return f * getResources().getDisplayMetrics().density;
    }

    private float sp(float f) {
        return f * getResources().getDisplayMetrics().scaledDensity;
    }
}
