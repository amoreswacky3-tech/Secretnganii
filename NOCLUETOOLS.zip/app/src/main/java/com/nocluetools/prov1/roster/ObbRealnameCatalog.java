package com.nocluetools.prov1.roster;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class ObbRealnameCatalog {
    public static final String ASSET_NAME = "nba2k20_obb_realnames.csv";
    public static final String SOURCE_TAIL14 = "TAIL14_V021_V022_VERIFIED";
    private final HashMap<Long, Record> byHash;
    private final ArrayList<Record> ordered;

    public static final class Record {
        public final String filename;
        public final int historicalIndex;
        public final long nameHash;
        public final String source;

        Record(long j, String str, int i, String str2) {
            this.nameHash = j;
            this.filename = str;
            this.historicalIndex = i;
            this.source = str2;
        }
    }

    ObbRealnameCatalog(HashMap<Long, Record> map, ArrayList<Record> arrayList) {
        this.byHash = map;
        this.ordered = arrayList;
    }

    public static ObbRealnameCatalog load(InputStream inputStream) throws IOException {
        if (inputStream == null) {
            throw new IOException("OBB realname catalog input is missing.");
        }
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
        HashMap map = new HashMap();
        ArrayList arrayList = new ArrayList();
        int i = 0;
        while (true) {
            String line = bufferedReader.readLine();
            if (line != null) {
                i++;
                if (i != 1 || !line.startsWith("name_hash,")) {
                    if (line.trim().length() == 0) {
                        continue;
                    } else {
                        String[] strArrSplit = line.split(",", 4);
                        if (strArrSplit.length != 4) {
                            throw new IOException(new StringBuffer().append(new StringBuffer().append("Malformed OBB realname row ").append(i).toString()).append(".").toString());
                        }
                        try {
                            long j = Long.parseLong(strArrSplit[0].trim(), 16) & 4294967295L;
                            int i2 = Integer.parseInt(strArrSplit[2].trim());
                            String strTrim = strArrSplit[1].trim();
                            String strTrim2 = strArrSplit[3].trim();
                            if (strTrim.length() == 0) {
                                throw new IOException(new StringBuffer().append(new StringBuffer().append("Empty OBB realname at row ").append(i).toString()).append(".").toString());
                            }
                            if (ObbArchive.hashFileName(strTrim) != j) {
                                throw new IOException(String.format(Locale.US, "OBB realname CRC mismatch at row %d: %08X %s", new Integer(i), new Long(j), strTrim));
                            }
                            Long lValueOf = Long.valueOf(j);
                            if (map.containsKey(lValueOf)) {
                                throw new IOException(String.format(Locale.US, "Duplicate OBB realname hash %08X at row %d.", new Long(j), new Integer(i)));
                            }
                            Record record = new Record(j, strTrim, i2, strTrim2);
                            map.put(lValueOf, record);
                            arrayList.add(record);
                        } catch (NumberFormatException e) {
                            throw new IOException(new StringBuffer().append(new StringBuffer().append("Invalid OBB realname row ").append(i).toString()).append(".").toString(), e);
                        }
                    }
                }
            } else {
                return new ObbRealnameCatalog(map, arrayList);
            }
        }
    }

    public int size() {
        return this.byHash.size();
    }

    public Set<Long> hashes() {
        return Collections.unmodifiableSet(this.byHash.keySet());
    }

    public Record get(long j) {
        return this.byHash.get(Long.valueOf(j & 4294967295L));
    }

    public String nameForHash(long j) {
        Record record = get(j);
        return record == null ? (String) null : record.filename;
    }

    public List<Record> recordsBySource(String str) {
        ArrayList arrayList = new ArrayList();
        for (Record record : this.ordered) {
            if (str.equals(record.source)) {
                arrayList.add(record);
            }
        }
        return Collections.unmodifiableList(arrayList);
    }

    public List<Record> allRecords() {
        return Collections.unmodifiableList(this.ordered);
    }
}
