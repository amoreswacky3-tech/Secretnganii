package com.nocluetools.prov1;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class RosterEditorActivity extends Activity {

    // Top Bar & Panels
    TextView tvSectionName, tvStatusBar;
    View panelHome, panelRoster, panelTeams, panelPlayers, panelTools;
    
    // Bottom Nav Tabs
    TextView tabHome, tabRoster, tabTeams, tabPlayers, tabTools;

    // Player Drawer
    View playerActionsDrawer;
    TextView btnTogglePlayerActions;
    
    // Search
    EditText etSearch;
    ListView listViewRecords;

    // Colors
    int activeColor = Color.parseColor("#2196F3");
    int inactiveColor = Color.parseColor("#15171B");
    int activeTextColor = Color.parseColor("#FFFFFF");
    int inactiveTextColor = Color.parseColor("#6B7280");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // 🚨 THIS LOADS THE 1,395-LINE XML YOU SENT 🚨
        setContentView(R.layout.activity_roster_editor); 

        initViews();
        setupNavigation();
        setupButtonClicks();
    }

    private void initViews() {
        tvSectionName = findViewById(R.id.tvSectionName);
        tvStatusBar = findViewById(R.id.tvStatusBar);

        panelHome = findViewById(R.id.panelHome);
        panelRoster = findViewById(R.id.panelRoster);
        panelTeams = findViewById(R.id.panelTeams);
        panelPlayers = findViewById(R.id.panelPlayers);
        panelTools = findViewById(R.id.panelTools);

        tabHome = findViewById(R.id.tabHome);
        tabRoster = findViewById(R.id.tabRoster);
        tabTeams = findViewById(R.id.tabTeams);
        tabPlayers = findViewById(R.id.tabPlayers);
        tabTools = findViewById(R.id.tabTools);

        playerActionsDrawer = findViewById(R.id.playerActionsDrawer);
        btnTogglePlayerActions = findViewById(R.id.btnTogglePlayerActions);
        
        etSearch = findViewById(R.id.etSearch);
        listViewRecords = findViewById(R.id.listViewRecords);
    }

    private void setupNavigation() {
        tabHome.setOnClickListener(v -> switchTab("HOME"));
        tabRoster.setOnClickListener(v -> switchTab("ROSTER"));
        tabTeams.setOnClickListener(v -> switchTab("TEAMS"));
        tabPlayers.setOnClickListener(v -> switchTab("PLAYERS"));
        tabTools.setOnClickListener(v -> switchTab("TOOLS"));
    }

    private void switchTab(String tabName) {
        // 1. Hide all panels
        panelHome.setVisibility(View.GONE);
        panelRoster.setVisibility(View.GONE);
        panelTeams.setVisibility(View.GONE);
        panelPlayers.setVisibility(View.GONE);
        panelTools.setVisibility(View.GONE);

        // 2. Reset all tabs to dark
        TextView[] allTabs = {tabHome, tabRoster, tabTeams, tabPlayers, tabTools};
        for (TextView tab : allTabs) {
            tab.setBackgroundColor(inactiveColor);
            tab.setTextColor(inactiveTextColor);
        }

        // 3. Show selected panel
        tvSectionName.setText(tabName);
        switch (tabName) {
            case "HOME":
                panelHome.setVisibility(View.VISIBLE);
                tabHome.setBackgroundColor(activeColor);
                tabHome.setTextColor(activeTextColor);
                break;
            case "ROSTER":
                panelRoster.setVisibility(View.VISIBLE);
                tabRoster.setBackgroundColor(activeColor);
                tabRoster.setTextColor(activeTextColor);
                break;
            case "TEAMS":
                panelTeams.setVisibility(View.VISIBLE);
                tabTeams.setBackgroundColor(activeColor);
                tabTeams.setTextColor(activeTextColor);
                break;
            case "PLAYERS":
                panelPlayers.setVisibility(View.VISIBLE);
                tabPlayers.setBackgroundColor(activeColor);
                tabPlayers.setTextColor(activeTextColor);
                break;
            case "TOOLS":
                panelTools.setVisibility(View.VISIBLE);
                tabTools.setBackgroundColor(activeColor);
                tabTools.setTextColor(activeTextColor);
                break;
        }
    }

    private void setupButtonClicks() {
        // --- PLAYER DRAWER TOGGLE ---
        btnTogglePlayerActions.setOnClickListener(v -> {
            if (playerActionsDrawer.getVisibility() == View.GONE) {
                playerActionsDrawer.setVisibility(View.VISIBLE);
                btnTogglePlayerActions.setText("▼  HIDE TOOLS");
            } else {
                playerActionsDrawer.setVisibility(View.GONE);
                btnTogglePlayerActions.setText("▲  PLAYER TOOLS");
            }
        });

        // --- ROSTER PANEL BUTTON ---
        findViewById(R.id.btnOpenRoster2).setOnClickListener(v -> {
            Toast.makeText(this, "Add Roster Clicked!", Toast.LENGTH_SHORT).show();
            // Here you will eventually link the RosterCrypto engine to open the .ros file!
        });
        
        // --- OTHER BUTTONS (Placeholders) ---
        findViewById(R.id.btnSaveAsNew).setOnClickListener(v -> Toast.makeText(this, "Save As New", Toast.LENGTH_SHORT).show());
        findViewById(R.id.btnTeamDatabase).setOnClickListener(v -> Toast.makeText(this, "Team DB", Toast.LENGTH_SHORT).show());
        findViewById(R.id.btnFreeAgentManager).setOnClickListener(v -> Toast.makeText(this, "Free Agents", Toast.LENGTH_SHORT).show());
        findViewById(R.id.btnPlayerEditorPro).setOnClickListener(v -> Toast.makeText(this, "Player Editor Pro", Toast.LENGTH_SHORT).show());
        
        // Search bar setup
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                // If you add the PlayerRowAdapter here later, you can filter it!
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }
}