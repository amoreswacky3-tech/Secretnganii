package com.nocluetools.prov1.roster;

import com.nocluetools.prov1.roster.RosterPlayerMap;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public final class RosterNameResolver {
    private static final long MYCAREER_POOL_BIT_OFFSET = 71905107;
    private static final long STANDARD_POOL_BIT_OFFSET = 36432787;
    private static final long STRING_INDEX_MASK = 2097151;
    private static final int STRING_SECTION = 48;
    private static final int[] ANCHOR_TEAM_SLOTS = {0, 1, 2, 4, 13, 28};
    private static final String[] ANCHOR_TEAM_NAMES = {"76ers", "Bucks", "Bulls", "Celtics", "Lakers", "Warriors"};

    public static final class Stats {
        public final long poolBitOffset;
        public final int resolvedPlayers;
        public final int resolvedTeams;

        Stats(long j, int i, int i2) {
            this.poolBitOffset = j;
            this.resolvedPlayers = i;
            this.resolvedTeams = i2;
        }
    }

    public static Stats resolve(byte[] bArr, List<RosterPlayerMap.PlayerRecord> list, List<RosterPlayerMap.TeamRecord> list2) throws IOException {
        long jFindStringPoolBitOffset = findStringPoolBitOffset(bArr, list2);
        if (jFindStringPoolBitOffset < 0) {
            for (RosterPlayerMap.TeamRecord teamRecord : list2) {
                teamRecord.teamName = "";
                teamRecord.abbreviation = "";
                teamRecord.cityName = "";
                teamRecord.fullName = String.format(Locale.US, "Team %02d", new Integer(teamRecord.slot));
            }
            for (RosterPlayerMap.PlayerRecord playerRecord : list) {
                playerRecord.firstName = "";
                playerRecord.lastName = "";
                playerRecord.displayName = String.format(Locale.US, "Player %04d", new Integer(playerRecord.slot));
            }
            return new Stats(-1L, 0, 0);
        }
        int i = 0;
        for (RosterPlayerMap.TeamRecord teamRecord2 : list2) {
            teamRecord2.teamName = clean(readRosterString(bArr, jFindStringPoolBitOffset, teamRecord2.teamNameRef));
            teamRecord2.abbreviation = clean(readRosterString(bArr, jFindStringPoolBitOffset, teamRecord2.abbreviationRef));
            teamRecord2.cityName = clean(readRosterString(bArr, jFindStringPoolBitOffset, teamRecord2.cityRef));
            String strJoinTeamName = joinTeamName(teamRecord2.cityName, teamRecord2.teamName, clean(readRosterString(bArr, jFindStringPoolBitOffset, teamRecord2.displayRef)));
            if (strJoinTeamName.length() == 0) {
                strJoinTeamName = String.format(Locale.US, "Team %02d", new Integer(teamRecord2.slot));
            } else {
                i++;
            }
            teamRecord2.fullName = strJoinTeamName;
        }
        int i2 = 0;
        for (RosterPlayerMap.PlayerRecord playerRecord2 : list) {
            playerRecord2.firstName = clean(readRosterString(bArr, jFindStringPoolBitOffset, playerRecord2.firstNameRef));
            playerRecord2.lastName = clean(readRosterString(bArr, jFindStringPoolBitOffset, playerRecord2.lastNameRef));
            playerRecord2.displayName = joinPlayerName(playerRecord2.firstName, playerRecord2.lastName, playerRecord2.slot);
            if (playerRecord2.firstName.length() > 0 || playerRecord2.lastName.length() > 0) {
                i2++;
            }
        }
        return new Stats(jFindStringPoolBitOffset, i2, i);
    }

    public static long findStringPoolBitOffset(byte[] bArr, List<RosterPlayerMap.TeamRecord> list) {
        if (bArr == null || list == null || list.isEmpty()) {
            return -1;
        }
        long jFindStringPoolByKnownTeamAnchors = findStringPoolByKnownTeamAnchors(bArr, list);
        if (jFindStringPoolByKnownTeamAnchors >= 0) {
            return jFindStringPoolByKnownTeamAnchors;
        }
        if (validateStructuralCandidate(bArr, STANDARD_POOL_BIT_OFFSET, list)) {
            return STANDARD_POOL_BIT_OFFSET;
        }
        if (validateStructuralCandidate(bArr, MYCAREER_POOL_BIT_OFFSET, list)) {
            return MYCAREER_POOL_BIT_OFFSET;
        }
        return findStringPoolByReferenceStructure(bArr, list);
    }

    private static long findStringPoolByKnownTeamAnchors(byte[] bArr, List<RosterPlayerMap.TeamRecord> list) {
        for (int i = 0; i < ANCHOR_TEAM_SLOTS.length; i++) {
            int i2 = ANCHOR_TEAM_SLOTS[i];
            if (i2 >= 0 && i2 < list.size()) {
                long j = list.get(i2).teamNameRef;
                if (isSupportedStringRef(j)) {
                    byte[] bArrUtf16Le = utf16Le(ANCHOR_TEAM_NAMES[i]);
                    long j2 = j & STRING_INDEX_MASK;
                    for (int i3 = 0; i3 < 8; i3++) {
                        int length = (bArr.length - bArrUtf16Le.length) - 1;
                        for (int i4 = 0; i4 <= length; i4++) {
                            if (shiftedByte(bArr, i4, i3) == (bArrUtf16Le[0] & 255) && matchesShifted(bArr, i4, i3, bArrUtf16Le)) {
                                long j3 = ((((long) i4) * 8) + ((long) i3)) - (j2 * 16);
                                if (j3 >= 0 && j3 < ((long) bArr.length) * 8 && validateCandidate(bArr, j3, list)) {
                                    return j3;
                                }
                            }
                        }
                    }
                } else {
                    continue;
                }
            }
        }
        return -1L;
    }

    private static long findStringPoolByReferenceStructure(byte[] bArr, List<RosterPlayerMap.TeamRecord> list) {
        long length = ((long) bArr.length) * 8;
        int iMin = Math.min(30, list.size());
        int i = 0;
        for (int i2 = 0; i2 < iMin && i < 4; i2++) {
            long j = list.get(i2).abbreviationRef;
            if (isSupportedStringRef(j)) {
                long j2 = j & STRING_INDEX_MASK;
                if (j2 > 0 && j2 <= STRING_INDEX_MASK) {
                    i++;
                    long j3 = j2 * 16;
                    int iMax = (int) Math.max(0L, j3 >>> 3);
                    int length2 = bArr.length - 14;
                    for (int i3 = 0; i3 < 8; i3++) {
                        for (int i4 = iMax; i4 <= length2; i4++) {
                            if (quickShortStringLength(bArr, i4, i3) >= 2) {
                                long j4 = ((((long) i4) * 8) + ((long) i3)) - j3;
                                if (j4 >= 0 && j4 < length && hasSecondSaneAbbreviation(bArr, j4, list, i2) && validateStructuralCandidate(bArr, j4, list)) {
                                    return j4;
                                }
                            }
                        }
                    }
                }
            }
        }
        return -1L;
    }

    private static boolean hasSecondSaneAbbreviation(byte[] bArr, long j, List<RosterPlayerMap.TeamRecord> list, int i) {
        int iMin = Math.min(30, list.size());
        for (int i2 = 0; i2 < iMin; i2++) {
            if (i2 != i) {
                long j2 = list.get(i2).abbreviationRef;
                if (isSupportedStringRef(j2)) {
                    return isSaneShortLabel(clean(readRosterString(bArr, j, j2)));
                }
            }
        }
        return false;
    }

    private static boolean validateStructuralCandidate(byte[] bArr, long j, List<RosterPlayerMap.TeamRecord> list) {
        long length = ((long) bArr.length) * 8;
        if (j < 0 || j + 16 > length) {
            return false;
        }
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        int iMin = Math.min(30, list.size());
        for (int i4 = 0; i4 < iMin; i4++) {
            RosterPlayerMap.TeamRecord teamRecord = list.get(i4);
            String strClean = clean(readRosterString(bArr, j, teamRecord.teamNameRef));
            String strClean2 = clean(readRosterString(bArr, j, teamRecord.abbreviationRef));
            String strClean3 = clean(readRosterString(bArr, j, teamRecord.cityRef));
            String strClean4 = clean(readRosterString(bArr, j, teamRecord.displayRef));
            boolean zIsSaneRosterText = isSaneRosterText(strClean, 1, 48);
            boolean zIsSaneShortLabel = isSaneShortLabel(strClean2);
            boolean zIsSaneRosterText2 = isSaneRosterText(strClean3, 1, 48);
            boolean zIsSaneRosterText3 = isSaneRosterText(strClean4, 1, 64);
            if (zIsSaneRosterText) {
                i3++;
            }
            if (zIsSaneShortLabel) {
                i3++;
                i2++;
            }
            if (zIsSaneRosterText2) {
                i3++;
            }
            if (zIsSaneRosterText3) {
                i3++;
            }
            if (zIsSaneShortLabel && (zIsSaneRosterText || zIsSaneRosterText2 || zIsSaneRosterText3)) {
                i++;
            }
        }
        return i >= Math.min(24, Math.max(1, iMin + (-4))) && i2 >= Math.min(26, Math.max(1, iMin + (-2))) && i3 >= Math.min(75, Math.max(4, iMin * 2));
    }

    private static int quickShortStringLength(byte[] bArr, int i, int i2) {
        int iShiftedUtf16LeCodeUnit;
        for (int i3 = 0; i3 <= 8 && (iShiftedUtf16LeCodeUnit = shiftedUtf16LeCodeUnit(bArr, i + (i3 * 2), i2)) >= 0; i3++) {
            if (iShiftedUtf16LeCodeUnit == 0 || iShiftedUtf16LeCodeUnit == 65535) {
                return i3;
            }
            if (i3 >= 8 || !isShortLabelChar((char) iShiftedUtf16LeCodeUnit)) {
                return -1;
            }
        }
        return -1;
    }

    private static int shiftedUtf16LeCodeUnit(byte[] bArr, int i, int i2) {
        int iShiftedByte = shiftedByte(bArr, i, i2);
        int iShiftedByte2 = shiftedByte(bArr, i + 1, i2);
        if (iShiftedByte < 0 || iShiftedByte2 < 0) {
            return -1;
        }
        return iShiftedByte | (iShiftedByte2 << 8);
    }

    private static boolean isShortLabelChar(char c) {
        if (c >= 'A' && c <= 'Z') {
            return true;
        }
        if (c >= 'a' && c <= 'z') {
            return true;
        }
        if (c < '0' || c > '9') {
            return c == ' ' || c == '.' || c == '-' || c == '_' || c == '&' || c == '\'';
        }
        return true;
    }

    private static boolean isSaneShortLabel(String str) {
        if (str == null || str.length() < 1 || str.length() > 8) {
            return false;
        }
        for (int i = 0; i < str.length(); i++) {
            if (!isShortLabelChar(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    private static boolean isSaneRosterText(String str, int i, int i2) {
        if (str == null || str.length() < i || str.length() > i2) {
            return false;
        }
        for (int i3 = 0; i3 < str.length(); i3++) {
            char cCharAt = str.charAt(i3);
            if (cCharAt == 65535 || cCharAt == 65533) {
                return false;
            }
            if (Character.isSurrogate(cCharAt)) {
                return false;
            }
            if (Character.isISOControl(cCharAt) && !Character.isWhitespace(cCharAt)) {
                return false;
            }
        }
        return true;
    }

    private static boolean validateCandidate(byte[] bArr, long j, List<RosterPlayerMap.TeamRecord> list) {
        int i = 0;
        for (int i2 = 0; i2 < ANCHOR_TEAM_SLOTS.length; i2++) {
            int i3 = ANCHOR_TEAM_SLOTS[i2];
            if (i3 >= 0 && i3 < list.size() && clean(readRosterString(bArr, j, list.get(i3).teamNameRef)).equalsIgnoreCase(ANCHOR_TEAM_NAMES[i2])) {
                i++;
            }
        }
        if (i < 4) {
            return false;
        }
        int i4 = 0;
        int iMin = Math.min(30, list.size());
        for (int i5 = 0; i5 < iMin; i5++) {
            RosterPlayerMap.TeamRecord teamRecord = list.get(i5);
            String strClean = clean(readRosterString(bArr, j, teamRecord.teamNameRef));
            String strClean2 = clean(readRosterString(bArr, j, teamRecord.abbreviationRef));
            if (isSaneText(strClean, 2, 32) && isSaneText(strClean2, 2, 5)) {
                i4++;
            }
        }
        return i4 >= 26;
    }

    public static String readRosterString(byte[] bArr, long j, long j2) {
        if (!isSupportedStringRef(j2)) {
            return "";
        }
        long j3 = j + ((j2 & STRING_INDEX_MASK) * 16);
        long length = ((long) bArr.length) * 8;
        if (j3 < 0 || j3 + 16 > length) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 96; i++) {
            long j4 = j3 + (((long) i) * 16);
            if (j4 + 16 > length) {
                break;
            }
            int bits = (int) readBits(bArr, j4, 16);
            int i2 = ((bits & 255) << 8) | ((bits >>> 8) & 255);
            if (i2 == 0 || i2 == 65535) {
                break;
            }
            if (i2 < 32 && i2 != 9) {
                return "";
            }
            sb.append((char) i2);
        }
        return sb.toString();
    }

    public static boolean isSupportedStringRef(long j) {
        return ((j >>> 21) & 255) == ((long) 48);
    }

    public static int getRosterStringLength(byte[] bArr, long j, long j2) {
        if (!isSupportedStringRef(j2)) {
            return -1;
        }
        long j3 = j + ((j2 & STRING_INDEX_MASK) * 16);
        long length = ((long) bArr.length) * 8;
        if (j3 < 0 || j3 + 16 > length) {
            return -1;
        }
        for (int i = 0; i < 96; i++) {
            long j4 = j3 + (((long) i) * 16);
            if (j4 + 16 > length) {
                return -1;
            }
            int bits = (int) readBits(bArr, j4, 16);
            int i2 = ((bits & 255) << 8) | ((bits >>> 8) & 255);
            if (i2 == 0 || i2 == 65535) {
                return i;
            }
            if (i2 < 32 && i2 != 9) {
                return -1;
            }
        }
        return -1;
    }

    private static String joinPlayerName(String str, String str2, int i) {
        String strClean = clean(str);
        String strClean2 = clean(str2);
        return (strClean.length() == 0 && strClean2.length() == 0) ? String.format(Locale.US, "Player %04d", new Integer(i)) : strClean.length() == 0 ? strClean2 : strClean2.length() == 0 ? strClean : new StringBuffer().append(new StringBuffer().append(strClean).append(" ").toString()).append(strClean2).toString();
    }

    private static String joinTeamName(String str, String str2, String str3) {
        String strClean = clean(str);
        String strClean2 = clean(str2);
        String strClean3 = clean(str3);
        return (strClean.length() <= 0 || strClean2.length() <= 0) ? (strClean3.length() <= 0 || strClean2.length() <= 0) ? strClean2.length() > 0 ? strClean2 : strClean3 : strClean3.toLowerCase(Locale.US).contains(strClean2.toLowerCase(Locale.US)) ? strClean3 : new StringBuffer().append(new StringBuffer().append(strClean3).append(" ").toString()).append(strClean2).toString() : strClean2.toLowerCase(Locale.US).startsWith(new StringBuffer().append(strClean.toLowerCase(Locale.US)).append(" ").toString()) ? strClean2 : new StringBuffer().append(new StringBuffer().append(strClean).append(" ").toString()).append(strClean2).toString();
    }

    public static String cleanForValidation(String str) {
        return clean(str);
    }

    private static String clean(String str) {
        if (str == null) {
            return "";
        }
        String strTrim = str.trim();
        StringBuilder sb = new StringBuilder(strTrim.length());
        boolean z = false;
        for (int i = 0; i < strTrim.length(); i++) {
            char cCharAt = strTrim.charAt(i);
            if (Character.isWhitespace(cCharAt)) {
                z = sb.length() > 0;
            } else {
                if (z) {
                    sb.append(' ');
                }
                z = false;
                sb.append(cCharAt);
            }
        }
        return sb.toString().trim();
    }

    private static boolean isSaneText(String str, int i, int i2) {
        if (str == null || str.length() < i || str.length() > i2) {
            return false;
        }
        for (int i3 = 0; i3 < str.length(); i3++) {
            char cCharAt = str.charAt(i3);
            if (cCharAt < ' ' || cCharAt > '~') {
                return false;
            }
        }
        return true;
    }

    private static byte[] utf16Le(String str) {
        byte[] bArr = new byte[str.length() * 2];
        for (int i = 0; i < str.length(); i++) {
            char cCharAt = str.charAt(i);
            bArr[i * 2] = (byte) (cCharAt & 255);
            bArr[(i * 2) + 1] = (byte) ((cCharAt >>> '\b') & 255);
        }
        return bArr;
    }

    private static boolean matchesShifted(byte[] bArr, int i, int i2, byte[] bArr2) {
        for (int i3 = 0; i3 < bArr2.length; i3++) {
            if (shiftedByte(bArr, i + i3, i2) != (bArr2[i3] & 255)) {
                return false;
            }
        }
        return true;
    }

    private static int shiftedByte(byte[] bArr, int i, int i2) {
        if (i < 0 || i >= bArr.length) {
            return -1;
        }
        int i3 = bArr[i] & 255;
        if (i2 == 0) {
            return i3;
        }
        if (i + 1 >= bArr.length) {
            return -1;
        }
        return ((i3 << i2) & 255) | ((bArr[i + 1] & 255) >>> (8 - i2));
    }

    private static long readBits(byte[] bArr, long j, int i) {
        long j2 = 0;
        for (int i2 = 0; i2 < i; i2++) {
            long j3 = j + ((long) i2);
            j2 = (j2 << 1) | ((long) ((bArr[(int) (j3 >>> 3)] >>> (7 - ((int) (j3 & 7)))) & 1));
        }
        return j2;
    }

    RosterNameResolver() {
    }
}
