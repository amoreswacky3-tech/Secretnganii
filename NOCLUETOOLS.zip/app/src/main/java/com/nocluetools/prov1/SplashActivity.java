package com.nocluetools.prov1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class SplashActivity extends Activity {

    TextView overlayText;
    TextView overlaySub;
    View loadingOverlay;
    
    Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Link the overlay elements
        loadingOverlay = findViewById(R.id.loadingOverlay);
        overlayText = findViewById(R.id.overlayText);
        overlaySub = findViewById(R.id.overlaySub);

        // Show the Loading Overlay immediately
        showOverlay("BOOTING ENGINE...", "Initializing Python 3.10");

        // Start Python in the background
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    // 1. Start Python
                    if (!Python.isStarted()) {
                        Python.start(new AndroidPlatform(SplashActivity.this));
                    }
                    
                    // Update overlay text
                    updateOverlay("LOADING DATABASE...", "Mapping 5,474 real file names");
                    
                    // Safe sleep
                    try { Thread.sleep(800); } catch (InterruptedException ignored) {}

                    // Update overlay text again
                    updateOverlay("READY.", "Launching workspace...");
                    
                    // Safe sleep
                    try { Thread.sleep(500); } catch (InterruptedException ignored) {}

                } catch (Exception e) {
                    // If Python fails, show the error on the overlay
                    updateOverlay("ENGINE ERROR", e.getMessage());
                    
                    // Safe sleep so the user can read the error
                    try { Thread.sleep(2000); } catch (InterruptedException ignored) {}
                } finally {
                    // 🚨 THIS ALWAYS RUNS: Launch MainActivity no matter what happens
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                            startActivity(intent);
                            finish(); // Close the Splash screen
                        }
                    });
                }
            }
        }).start();
    }

    // Helper to update the overlay from a background thread
    private void updateOverlay(final String title, final String sub) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (overlayText != null) overlayText.setText(title);
                if (overlaySub != null) overlaySub.setText(sub);
            }
        });
    }

    private void showOverlay(String title, String sub) {
        if (overlayText != null) overlayText.setText(title);
        if (overlaySub != null) overlaySub.setText(sub);
        if (loadingOverlay != null) {
            loadingOverlay.setVisibility(View.VISIBLE);
            loadingOverlay.bringToFront();
        }
    }
}