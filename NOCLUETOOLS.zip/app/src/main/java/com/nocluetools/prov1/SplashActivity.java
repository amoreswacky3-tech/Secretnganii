package com.nocluetools.prov1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class SplashActivity extends Activity {

    TextView splashStatus;
    View loadingOverlay;
    TextView overlayText;
    TextView overlaySub;
    
    Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        splashStatus = findViewById(R.id.splashStatus);
        
        // Link the overlay elements
        loadingOverlay = findViewById(R.id.loadingOverlay);
        overlayText = findViewById(R.id.overlayText);
        overlaySub = findViewById(R.id.overlaySub);

        // 1. Show the Loading Overlay immediately
        showOverlay("BOOTING ENGINE...", "Initializing Python 3.10");

        // 2. Start Python in the background
        new Thread(() -> {
            try {
                if (!Python.isStarted()) {
                    Python.start(new AndroidPlatform(SplashActivity.this));
                }
                
                // Update overlay to show it's loading the CSV
                handler.post(() -> {
                    overlayText.setText("LOADING DATABASE...");
                    overlaySub.setText("Mapping 5,474 real file names");
                });
                
                // Simulate a tiny delay so the user can see the cool text
                Thread.sleep(800); 

                // Update overlay to show ready
                handler.post(() -> {
                    overlayText.setText("READY.");
                    overlaySub.setText("Launching workspace...");
                });

                // Wait another 500ms before launching
                Thread.sleep(500);

            } catch (Exception e) {
                handler.post(() -> {
                    overlayText.setText("ENGINE ERROR");
                    overlaySub.setText(e.getMessage());
                });
                Thread.sleep(2000); // Wait 2 seconds on error before launching anyway
            }

            // 3. Launch MainActivity and hide overlay
            handler.post(() -> {
                Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // Close Splash
            });
        }).start();
    }

    private void showOverlay(String title, String sub) {
        overlayText.setText(title);
        overlaySub.setText(sub);
        loadingOverlay.setVisibility(View.VISIBLE);
        loadingOverlay.bringToFront();
    }
}