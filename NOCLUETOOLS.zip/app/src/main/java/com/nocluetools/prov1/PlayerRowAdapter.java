package com.nocluetools.prov1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class PlayerRowAdapter extends BaseAdapter {

    private Context context;
    private List<PlayerItem> items;
    private List<PlayerItem> filteredItems;
    private LayoutInflater inflater;

    // Simple class to hold the data for one player row
    public static class PlayerItem {
        public String name;
        public String jersey;
        public String ovr;
        public String cfId;

        public PlayerItem(String name, String jersey, String ovr, String cfId) {
            this.name = name;
            this.jersey = jersey;
            this.ovr = ovr;
            this.cfId = cfId;
        }

        // Used by the search filter
        public boolean matches(String query) {
            return name.toLowerCase().contains(query) || 
                   cfId.toLowerCase().contains(query) || 
                   jersey.toLowerCase().contains(query);
        }
    }

    public PlayerRowAdapter(Context context, List<PlayerItem> items) {
        this.context = context;
        this.items = items;
        this.filteredItems = new ArrayList<>(items);
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() { return filteredItems.size(); }

    @Override
    public PlayerItem getItem(int position) { return filteredItems.get(position); }

    @Override
    public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            // 🚨 Inflate YOUR custom player row layout 🚨
            convertView = inflater.inflate(R.layout.item_player_row, parent, false);
        }

        TextView rowName = convertView.findViewById(R.id.rowName);
        TextView rowJersey = convertView.findViewById(R.id.rowJersey);
        TextView rowOvr = convertView.findViewById(R.id.rowOvr);
        TextView rowCf = convertView.findViewById(R.id.rowCf);

        PlayerItem item = filteredItems.get(position);

        rowName.setText(item.name);
        rowJersey.setText(item.jersey);
        rowOvr.setText(item.ovr);
        rowCf.setText(item.cfId);

        return convertView;
    }

    // Method to handle the search bar (Name, CF ID, or Jersey)
    public void filter(String text) {
        filteredItems.clear();
        if (text == null || text.isEmpty()) {
            filteredItems.addAll(items);
        } else {
            String query = text.toLowerCase();
            for (PlayerItem item : items) {
                if (item.matches(query)) {
                    filteredItems.add(item);
                }
            }
        }
        notifyDataSetChanged();
    }
}