package com.nocluetools.prov1.roster;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public final class DarkStringAdapter extends ArrayAdapter<String> {
    public DarkStringAdapter(Context context, int i, List<String> list) {
        super(context, i, list);
    }

    @Override // android.widget.ArrayAdapter, android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        TextView textView = (TextView) super.getView(i, view, viewGroup);
        style(textView, false);
        textView.setSingleLine(true);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        return textView;
    }

    @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
    public View getDropDownView(int i, View view, ViewGroup viewGroup) {
        TextView textView = (TextView) super.getDropDownView(i, view, viewGroup);
        style(textView, true);
        return textView;
    }

    private void style(TextView textView, boolean z) {
        boolean zIsWarning = isWarning(textView.getText() == null ? "" : textView.getText().toString());
        textView.setTextColor(zIsWarning ? Color.rgb(255, 120, 120) : Color.rgb(245, 247, 252));
        textView.setTextSize(15);
        textView.setTypeface(Typeface.DEFAULT, zIsWarning ? 1 : 0);
        int iDp = dp(14);
        int iDp2 = dp(12);
        textView.setPadding(iDp, iDp2, z ? iDp : dp(44), iDp2);
        textView.setMinHeight(dp(48));
        textView.setBackgroundColor(z ? Color.rgb(40, 44, 54) : 0);
        if (z) {
            textView.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
            textView.setSingleLine(false);
            textView.setMaxLines(2);
            textView.setEllipsize(TextUtils.TruncateAt.END);
        }
    }

    private boolean isWarning(String str) {
        String upperCase = str == null ? "" : str.toUpperCase(Locale.US);
        return upperCase.contains("SKIPPED") || upperCase.contains("UNSUPPORTED") || upperCase.contains("FAILED") || upperCase.contains("ERROR");
    }

    private int dp(int i) {
        return Math.round(i * getContext().getResources().getDisplayMetrics().density);
    }
}
