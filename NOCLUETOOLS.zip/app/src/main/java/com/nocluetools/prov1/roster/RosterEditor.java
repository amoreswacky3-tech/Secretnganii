package com.nocluetools.prov1.roster;

import com.nocluetools.prov1.roster.RosterPlayerMap;
import com.nocluetools.prov1.roster.RosterValidator;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class RosterEditor {
    private static final int ABILITY_SERIAL_BASE_BITS = 3154;
    private static final int ABILITY_STRUCT_BASE = 460;
    public static final int BADGE_COUNT = 44;
    private static final int BADGE_LEVEL_SERIAL_BASE_BITS = 3955;
    private static final int CONTRACT_NO_TRADE_BITS = 1903;
    private static final int CONTRACT_OPTION_BITS = 1682;
    private static final int CONTRACT_YEAR1_BITS = 2194;
    private static final int CONTRACT_YEAR_COUNT = 7;
    public static final int NBA2K20_START_YEAR = 2019;
    private static final int PLAYER_ACTIVE_ROSTER_MARKER = 8512;
    private static final int PLAYER_BIRTH_DAY_BITS = 288;
    private static final int PLAYER_BIRTH_DAY_WIDTH = 5;
    private static final int PLAYER_BIRTH_MONTH_BITS = 284;
    private static final int PLAYER_BIRTH_YEAR_BITS = 272;
    private static final int PLAYER_BODY_TYPE_BITS = 1461;
    private static final int PLAYER_CF_BITS = 528;
    private static final int PLAYER_COLLEGE_REF_BITS = 320;
    private static final int PLAYER_COLLEGE_REF_WIDTH = 32;
    private static final int PLAYER_DRAFT_PICK_BITS = 2086;
    private static final int PLAYER_DRAFT_PICK_WIDTH = 5;
    private static final int PLAYER_DRAFT_ROUND_BITS = 2960;
    private static final int PLAYER_DRAFT_TEAM_BITS = 379;
    private static final int PLAYER_DRAFT_TEAM_WIDTH = 5;
    private static final int PLAYER_DRAFT_YEAR_BITS = 1757;
    private static final int PLAYER_DRAFT_YEAR_WIDTH = 5;
    private static final int PLAYER_EYE_COLOR_BITS = 1477;
    private static final int PLAYER_HEIGHT_BITS = 128;
    private static final int PLAYER_JERSEY_BITS = 301;
    private static final int PLAYER_MUSCLE_TYPE_BITS = 1463;
    private static final int PLAYER_PAYLOAD_BITS = 4043;
    private static final int PLAYER_PORTRAIT_BITS = 256;
    private static final int PLAYER_POSITION1_BITS = 456;
    private static final int PLAYER_POSITION2_BITS = 459;
    private static final int PLAYER_PRIMARY_FA_MARKER_BITS = 192;
    private static final int PLAYER_PRIMARY_TEAM_ID_BITS = 216;
    private static final int PLAYER_SKIN_TONE_BITS = 1464;
    private static final int PLAYER_STRIDE_BITS = 4075;
    private static final long PLAYER_TAG_BASE = 543162368;
    private static final int PLAYER_TAG_BITS = 32;
    private static final int PLAYER_WEIGHT_BITS = 160;
    private static final int PLAYER_YEARS_PRO_BITS = 1074;
    private static final int PLAYER_YEARS_PRO_WIDTH = 32;
    public static final int ROTATION_MINUTES_MAX = 48;
    private static final int TEAM_LINEUP_BASE_BITS = 1888;
    private static final int TEAM_LINEUP_COUNT = 7;
    private static final int TEAM_LINEUP_SLOT_COUNT = 5;
    private static final int TEAM_PLAYER_COUNT_BITS = 1000;
    public static final int TEAM_ROTATION_MINUTES_TOTAL = 240;
    private static final int TEAM_STRIDE_BITS = 6356;
    private static final long TEAM_TAG_BASE = 557842432;
    private static final int TEAM_TAG_BITS = 32;
    private static final int TENDENCY_SERIAL_BASE_BITS = 3490;
    public static final int YEARS_PRO_MAX = 30;
    private static final int[] SIGNATURE_SLOT_BITS = {3039, 3045, 3065, 3071, 3077};
    public static final String[] SIGNATURE_SKILL_NAMES = {"00 • None", "01 • Posterizer", "02 • Highlight Film", "03 • Finisher", "04 • Acrobat", "05 • Spot Up Shooter", "06 • Shot Creator", "07 • Deadeye", "08 • Corner Specialist", "09 • Post Proficiency", "10 • Ankle Breaker", "11 • Post Playmaker", "12 • Dimer", "13 • Break Starter", "14 • Alley-Ooper", "15 • Brick Wall", "16 • Lockdown Defender", "17 • Charge Card", "18 • Interceptor", "19 • Pick Pocket", "20 • Active Hands", "21 • Eraser", "22 • Chasedown Artist", "23 • Bruiser", "24 • Hustle Points", "25 • Scraper", "26 • Anti-Freeze", "27 • Microwave", "28 • Heat Retention", "29 • Closer", "30 • Floor General", "31 • Defensive Anchor", "32 • Gatorade Prime Pack", "33 • On Court Coach", "34 • Extended Skill ID 34", "35 • Extended Skill ID 35", "36 • Extended Skill ID 36", "37 • Extended Skill ID 37", "38 • Extended Skill ID 38", "39 • Extended Skill ID 39", "40 • Extended Skill ID 40", "41 • Extended Skill ID 41", "42 • Extended Skill ID 42", "43 • Extended Skill ID 43", "44 • Extended Skill ID 44", "45 • Extended Skill ID 45", "46 • Extended Skill ID 46", "47 • Extended Skill ID 47", "48 • Extended Skill ID 48", "49 • Extended Skill ID 49", "50 • Extended Skill ID 50", "51 • Extended Skill ID 51", "52 • Extended Skill ID 52", "53 • Extended Skill ID 53", "54 • Extended Skill ID 54", "55 • Extended Skill ID 55", "56 • Extended Skill ID 56", "57 • Extended Skill ID 57", "58 • Extended Skill ID 58", "59 • Extended Skill ID 59", "60 • Extended Skill ID 60", "61 • Extended Skill ID 61", "62 • Extended Skill ID 62", "63 • Extended Skill ID 63"};
    public static final String[] POSITION_NAMES = {"PG", "SG", "SF", "PF", "C", "None"};
    public static final String[] TEAM_LINEUP_NAMES = {"STARTERS", "BENCH", "TALL", "QUICK", "DEFENSE", "3PT", "FREE THROW"};
    public static final String[] BADGE_LEVEL_NAMES = {"None", "Bronze", "Silver", "Gold"};
    public static final String[] BADGE_NAMES = {"Posterizer", "Highlight Film", "Finisher", "Acrobat", "Spot Up Shooter", "Shot Creator", "Deadeye", "Corner Specialist", "Post Proficiency", "Ankle Breaker", "Post Playmaker", "Dimer", "Break Starter", "Alley-Ooper", "Brick Wall", "Lockdown Defender", "Charge Card", "Interceptor", "Pick Pocket", "Active Hands", "Eraser", "Chasedown Artist", "Bruiser", "Hustle Points", "Scraper", "Anti-Freeze", "Microwave", "Heat Retention", "Closer", "Floor General", "Defensive Anchor", "Gatorade Prime Pack", "On Court Coach", "Badge ID 34", "Badge ID 35", "Badge ID 36", "Badge ID 37", "Badge ID 38", "Badge ID 39", "Badge ID 40", "Badge ID 41", "Badge ID 42", "Badge ID 43", "Badge ID 44"};
    public static final String[] HOT_ZONE_LABELS = {"Under Rim", "Close Left", "Close Center", "Close Right", "Mid Left", "Mid Left-Center", "Mid Center", "Mid Right-Center", "Mid Right", "3PT Left Corner", "3PT Left Wing", "3PT Top", "3PT Right Wing", "3PT Right Corner"};
    private static final int PLAYER_BIRTH_YEAR_WIDTH = 12;
    private static final int PLAYER_BIRTH_MONTH_WIDTH = 4;
    private static final int PLAYER_DRAFT_ROUND_WIDTH = 2;
    public static final AccessoryField[] ACCESSORY_FIELDS = {new AccessoryField("Shoe Model", 1426, PLAYER_BIRTH_YEAR_WIDTH), new AccessoryField("Shoe Brand", 1438, 3), new AccessoryField("Home Shoe Trim 1", 1443, 3), new AccessoryField("Home Shoe Trim 2", 1446, 3), new AccessoryField("Away Shoe Trim 1", 1449, 3), new AccessoryField("Away Shoe Trim 2", 1452, 3), new AccessoryField("Headband", 1489, 1), new AccessoryField("Left Elbow", 1506, 3), new AccessoryField("Right Elbow", 1509, 3), new AccessoryField("Left Wrist", 1512, PLAYER_BIRTH_MONTH_WIDTH), new AccessoryField("Undershirt", 1524, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Shorts", 1526, 1), new AccessoryField("Right Wrist", 1528, PLAYER_BIRTH_MONTH_WIDTH), new AccessoryField("Left Fingers", 1532, 3), new AccessoryField("Right Fingers", 1535, 3), new AccessoryField("Left Leg", 1539, 3), new AccessoryField("Right Leg", 1543, 3), new AccessoryField("Left Knee", 1546, 3), new AccessoryField("Right Knee", 1549, 3), new AccessoryField("Left Ankle", 1552, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Socks", 1554, PLAYER_BIRTH_MONTH_WIDTH), new AccessoryField("Right Ankle", 1558, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Undershirt Color", 1560, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Shorts Color", 1562, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Left Elbow Color", 1564, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Right Elbow Color", 1566, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Left Arm Color", 1568, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Right Arm Color", 1570, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Left Wrist Color 1", 1572, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Left Wrist Color 2", 1574, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Right Wrist Color 1", 1576, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Right Wrist Color 2", 1578, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Left Fingers Color", 1580, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Right Fingers Color", 1582, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Left Leg Color", 1584, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Right Leg Color", 1586, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Headband Logo", 1596, 3), new AccessoryField("Left Knee Color", 1618, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Right Knee Color", 1620, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Left Ankle Color", 1622, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Right Ankle Color", 1624, PLAYER_DRAFT_ROUND_WIDTH), new AccessoryField("Left Arm", 2874, 3), new AccessoryField("Right Arm", 2877, 3)};
    public static final PlayTypeField[] PLAY_TYPE_FIELDS = {new PlayTypeField("Play Type 1", 1599), new PlayTypeField("Play Type 2", 1603), new PlayTypeField("Play Type 3", 1607), new PlayTypeField("Play Type 4", 1611)};
    private static final int PLAYER_ROTATION_MINUTES_WIDTH = 6;
    private static final int TEAM_PLAYER_REF_COUNT = 20;
    public static final TendencyField[] TENDENCY_FIELDS = {new TendencyField("Shot", 0), new TendencyField("Shot Inside", 1), new TendencyField("Shot Close", PLAYER_DRAFT_ROUND_WIDTH), new TendencyField("Shot Medium", 3), new TendencyField("Shot Three", PLAYER_BIRTH_MONTH_WIDTH), new TendencyField("Drive", 5), new TendencyField("Drive Right", PLAYER_ROTATION_MINUTES_WIDTH), new TendencyField("Pull Up", 7), new TendencyField("Triple Threat Pump Fake", 8), new TendencyField("Triple Threat Jab Step", 9), new TendencyField("Triple Threat Nothing", 10), new TendencyField("Triple Threat Shoot", 11), new TendencyField("Setup Sizeup", PLAYER_BIRTH_YEAR_WIDTH), new TendencyField("Setup Hesitation", 13), new TendencyField("Setup Nothing", 14), new TendencyField("Dribble Crossover", 15), new TendencyField("Dribble Spin", 16), new TendencyField("Dribble Step Back", 17), new TendencyField("Dribble Half Spin", 18), new TendencyField("Dribble Double Cross", 19), new TendencyField("Dribble Behind Back", TEAM_PLAYER_REF_COUNT), new TendencyField("Dribble Hesitation", 21), new TendencyField("Dribble In And Out", 22), new TendencyField("Dribble Nothing", 23), new TendencyField("Finish Attack", 24), new TendencyField("Pass Out", 25), new TendencyField("Shot Fadeaway", 26), new TendencyField("Dunk", 27), new TendencyField("Crash", 28), new TendencyField("Touch", 29), new TendencyField("Post Up", 30), new TendencyField("Roll Vs Fade", 31), new TendencyField("Post Spin", 32), new TendencyField("Post Drop Step", 33), new TendencyField("Post Shimmy Shot", 34), new TendencyField("Post Face Up", 35), new TendencyField("Post Leave", 36), new TendencyField("Post Back Down", 37), new TendencyField("Post Aggressive Back Down", 38), new TendencyField("Post Shoot", 39), new TendencyField("Post Hook Shot", 40), new TendencyField("Post Fadeaway Shot", 41), new TendencyField("Post Drive", 42), new TendencyField("Post Hop Shot", 43), new TendencyField("Putback", 44), new TendencyField("Flashy Pass", 45), new TendencyField("Alley Oop", 46), new TendencyField("Draw Foul", 47), new TendencyField("Interception", 48), new TendencyField("Take Charge", 49), new TendencyField("On Ball Steal", 50), new TendencyField("Contest Shot", 51), new TendencyField("Foul", 52), new TendencyField("Hard Foul", 53), new TendencyField("Use Glass", 54), new TendencyField("Stepback Jumper", 55), new TendencyField("Spin Jumper", 56), new TendencyField("Alley Oop Pass", 57)};
    public static final AnimationField[] ANIMATION_FIELDS = {new AnimationField("Free Throw", 2026, 8), new AnimationField("Shot Release", 2034, 8), new AnimationField("Shot Jumper", 2042, 8), new AnimationField("Iso Behind Back", 2050, 3), new AnimationField("Shot Contested", 2053, 5), new AnimationField("Shot Timing", 2064, PLAYER_DRAFT_ROUND_WIDTH), new AnimationField("Iso Crossover", 2074, PLAYER_BIRTH_MONTH_WIDTH), new AnimationField("Iso Spin", 2078, 3), new AnimationField("Iso Hesitation", 2081, PLAYER_BIRTH_MONTH_WIDTH), new AnimationField("Post Protect Jumper", 2101, PLAYER_BIRTH_MONTH_WIDTH), new AnimationField("Post Protect Spin Jumper", 2105, PLAYER_BIRTH_MONTH_WIDTH), new AnimationField("Shot Spin", 2109, 5), new AnimationField("Shot Dribble Pullup", 2114, PLAYER_ROTATION_MINUTES_WIDTH), new AnimationField("Post Roll", 2120, PLAYER_ROTATION_MINUTES_WIDTH), new AnimationField("Post Shimmy Shot", 2126, PLAYER_BIRTH_MONTH_WIDTH), new AnimationField("Shot Fadeaway", 2130, 5), new AnimationField("Shot Side Hop", 2135, 5), new AnimationField("Post Hook", 2140, PLAYER_ROTATION_MINUTES_WIDTH), new AnimationField("Stadium Intro", 2155, PLAYER_ROTATION_MINUTES_WIDTH), new AnimationField("Layup Package", 2828, PLAYER_ROTATION_MINUTES_WIDTH), new AnimationField("Player Intro 1", 2994, 7), new AnimationField("Player Intro 2", 3001, 7), new AnimationField("Pregame Hype 1", 3026, PLAYER_ROTATION_MINUTES_WIDTH), new AnimationField("Pregame Hype 2", 3032, PLAYER_ROTATION_MINUTES_WIDTH), new AnimationField("Post One-Step Pullup", 3110, PLAYER_BIRTH_MONTH_WIDTH), new AnimationField("Dunk Package 1", 1906, 8), new AnimationField("Dunk Package 2", 1914, 8), new AnimationField("Dunk Package 3", 1922, 8), new AnimationField("Dunk Package 4", 1930, 8), new AnimationField("Dunk Package 5", 1938, 8), new AnimationField("Dunk Package 6", 1946, 8), new AnimationField("Dunk Package 7", 1954, 8), new AnimationField("Dunk Package 8", 1962, 8), new AnimationField("Dunk Package 9", 1970, 8), new AnimationField("Dunk Package 10", 1978, 8), new AnimationField("Dunk Package 11", 1986, 8), new AnimationField("Dunk Package 12", 1994, 8), new AnimationField("Dunk Package 13", 2002, 8), new AnimationField("Dunk Package 14", 2010, 8), new AnimationField("Dunk Package 15", 2018, 8)};
    public static final String[] ANIMATION_GROUP_NAMES = {"SHOOTING", "DRIBBLING", "FINISHING", "POST", "OTHER"};
    public static final int[][] ANIMATION_GROUP_INDICES = {new int[]{0, 1, PLAYER_DRAFT_ROUND_WIDTH, PLAYER_BIRTH_MONTH_WIDTH, 5, 11, PLAYER_BIRTH_YEAR_WIDTH, 15, 16}, new int[]{3, PLAYER_ROTATION_MINUTES_WIDTH, 7, 8}, new int[]{19, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39}, new int[]{9, 10, 13, 14, 17, 24}, new int[]{18, TEAM_PLAYER_REF_COUNT, 21, 22, 23}};
    private static final int PLAYER_ROTATION_MINUTES_BITS = 466;
    public static final RatingField[] RATING_FIELDS = {new RatingField("Close Shot", 460), new RatingField("Mid-Range Shot", 461), new RatingField("Ball Handle", 462), new RatingField("Three-Point Shot", 463), new RatingField("Free Throw", 464), new RatingField("Low Post Shot", 465), new RatingField("Runner / Floater", PLAYER_ROTATION_MINUTES_BITS), new RatingField("Standing Layup", 467), new RatingField("Layup", 468), new RatingField("Spin Layup", 469), new RatingField("Euro Layup", 470), new RatingField("Hop Layup", 471), new RatingField("Step Through", 472), new RatingField("Dunk", 473), new RatingField("Standing Dunk", 474), new RatingField("Shoot In Traffic", 475), new RatingField("Shoot Off Dribble", 476), new RatingField("Hustle", 477), new RatingField("Off-Hand Dribbling", 478), new RatingField("Ball Security", 479), new RatingField("Passing", 480), new RatingField("Low Post Defense", 481), new RatingField("Low Post Offense", 482), new RatingField("Block", 483), new RatingField("Hands", 484), new RatingField("Steal", 485), new RatingField("Speed", 486), new RatingField("Stamina", 487), new RatingField("Emotion", 488), new RatingField("Vertical", 489), new RatingField("Offensive Rebound", 490), new RatingField("Defensive Rebound", 491), new RatingField("Durability", 492), new RatingField("Defensive Awareness", 493), new RatingField("Offensive Awareness", 494), new RatingField("Consistency", 495), new RatingField("On Ball Defense", 496), new RatingField("Quickness", 497), new RatingField("Strength", 499), new RatingField("Post Fadeaway", 500), new RatingField("Post Hook", 501)};

    public static int getYearsPro(byte[] bArr, long j, int i) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_YEARS_PRO_BITS), 32);
    }

    public static void setYearsPro(byte[] bArr, long j, int i, int i2) {
        if (i2 < 0 || i2 > 30) {
            throw new IllegalArgumentException(new StringBuffer().append(new StringBuffer().append("Years Pro must be 0-").append(30).toString()).append(".").toString());
        }
        writeBits(bArr, playerPayload(j, i) + ((long) PLAYER_YEARS_PRO_BITS), 32, i2);
    }

    public static final class AccessoryField {
        public final String label;
        public final int serializedBit;
        public final int width;

        AccessoryField(String str, int i, int i2) {
            this.label = str;
            this.serializedBit = i;
            this.width = i2;
        }

        public int maxValue() {
            return (1 << this.width) - 1;
        }
    }

    public static float getPlayerHeightCm(byte[] bArr, long j, int i) {
        return Float.intBitsToFloat((int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_HEIGHT_BITS), 32));
    }

    public static void setPlayerHeightCm(byte[] bArr, long j, int i, float f) {
        if (Float.isNaN(f) || Float.isInfinite(f) || f < 150.0f || f > 250.0f) {
            throw new IllegalArgumentException("Height must be 150-250 cm.");
        }
        writeBits(bArr, playerPayload(j, i) + ((long) PLAYER_HEIGHT_BITS), 32, ((long) Float.floatToIntBits(f)) & 4294967295L);
    }

    public static int getPlayerBirthYear(byte[] bArr, long j, int i) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_BIRTH_YEAR_BITS), PLAYER_BIRTH_YEAR_WIDTH);
    }

    public static int getPlayerBirthMonth(byte[] bArr, long j, int i) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_BIRTH_MONTH_BITS), PLAYER_BIRTH_MONTH_WIDTH);
    }

    public static int getPlayerBirthDay(byte[] bArr, long j, int i) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_BIRTH_DAY_BITS), 5);
    }

    public static int getPlayerAge(byte[] bArr, long j, int i) {
        int playerBirthYear = getPlayerBirthYear(bArr, j, i);
        if (playerBirthYear < 1900 || playerBirthYear > 2019) {
            return 0;
        }
        return 2019 - playerBirthYear;
    }

    public static void setPlayerAge(byte[] bArr, long j, int i, int i2) {
        if (i2 < 15 || i2 > 90) {
            throw new IllegalArgumentException("Age must be 15-90 for the NBA2K20 2019 season.");
        }
        writeBits(bArr, playerPayload(j, i) + ((long) PLAYER_BIRTH_YEAR_BITS), PLAYER_BIRTH_YEAR_WIDTH, 2019 - i2);
    }

    public static long getPlayerCollegeRef(byte[] bArr, long j, int i) {
        return RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_COLLEGE_REF_BITS), 32);
    }

    public static void setPlayerCollegeRef(byte[] bArr, long j, int i, long j2) {
        if (j2 != 0) {
            long j3 = j2 - RosterCollegeMap.COLLEGE_TAG_BASE;
            if (j3 < 0 || j3 > 1048575) {
                throw new IllegalArgumentException("Invalid NBA2K20 college reference.");
            }
        }
        writeBits(bArr, playerPayload(j, i) + ((long) PLAYER_COLLEGE_REF_BITS), 32, j2);
    }

    public static float getPlayerWeightLb(byte[] bArr, long j, int i) {
        return Float.intBitsToFloat((int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_WEIGHT_BITS), 32));
    }

    public static void setPlayerWeightLb(byte[] bArr, long j, int i, float f) {
        if (Float.isNaN(f) || Float.isInfinite(f) || f < 120.0f || f > 400.0f) {
            throw new IllegalArgumentException("Weight must be 120-400 lb.");
        }
        writeBits(bArr, playerPayload(j, i) + ((long) PLAYER_WEIGHT_BITS), 32, ((long) Float.floatToIntBits(f)) & 4294967295L);
    }

    public static int getPrimaryPosition(byte[] bArr, long j, int i) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_POSITION1_BITS), 3);
    }

    public static int getSecondaryPosition(byte[] bArr, long j, int i) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_POSITION2_BITS), 3);
    }

    public static void setPlayerPositions(byte[] bArr, long j, int i, int i2, int i3) {
        if (i2 < 0 || i2 > 5 || i3 < 0 || i3 > 5) {
            throw new IllegalArgumentException("Position must be PG/SG/SF/PF/C/None.");
        }
        long jPlayerPayload = playerPayload(j, i);
        writeBits(bArr, jPlayerPayload + ((long) PLAYER_POSITION1_BITS), 3, i2);
        writeBits(bArr, jPlayerPayload + ((long) PLAYER_POSITION2_BITS), 3, i3);
    }

    public static int getRotationMinutes(byte[] bArr, long j, int i) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_ROTATION_MINUTES_BITS), PLAYER_ROTATION_MINUTES_WIDTH);
    }

    public static void setRotationMinutes(byte[] bArr, long j, int i, int i2) {
        if (i2 < 0 || i2 > 48) {
            throw new IllegalArgumentException("Rotation minutes must be 0-48.");
        }
        writeBits(bArr, playerPayload(j, i) + ((long) PLAYER_ROTATION_MINUTES_BITS), PLAYER_ROTATION_MINUTES_WIDTH, i2);
    }

    public static int[] getTeamRotationMinutes(byte[] bArr, long j, long j2, int i) throws IOException {
        int[] teamRosterSlots = getTeamRosterSlots(bArr, j2, i);
        int[] iArr = new int[teamRosterSlots.length];
        for (int i2 = 0; i2 < teamRosterSlots.length; i2++) {
            iArr[i2] = getRotationMinutes(bArr, j, teamRosterSlots[i2]);
        }
        return iArr;
    }

    public static void setTeamRotationMinutes(byte[] bArr, long j, long j2, int i, int[] iArr, int[] iArr2) throws IOException {
        int[] teamRosterSlots = getTeamRosterSlots(bArr, j2, i);
        if (iArr == null || iArr2 == null || iArr.length != teamRosterSlots.length || iArr2.length != teamRosterSlots.length) {
            throw new IOException("Rotation must contain every team player exactly once.");
        }
        boolean[] zArr = new boolean[teamRosterSlots.length];
        int i2 = 0;
        for (int i3 = 0; i3 < iArr.length; i3++) {
            int i4 = -1;
            int i5 = 0;
            while (true) {
                if (i5 >= teamRosterSlots.length) {
                    break;
                }
                if (!zArr[i5] && teamRosterSlots[i5] == iArr[i3]) {
                    i4 = i5;
                    break;
                }
                i5++;
            }
            if (i4 < 0) {
                throw new IOException("Rotation contains a missing or duplicate player.");
            }
            zArr[i4] = true;
            if (iArr2[i3] < 0 || iArr2[i3] > 48) {
                throw new IOException("Rotation minutes must be 0-48.");
            }
            i2 += iArr2[i3];
        }
        if (i2 != 240) {
            throw new IOException("Rotation must total exactly 240 minutes.");
        }
        for (int i6 = 0; i6 < iArr.length; i6++) {
            setRotationMinutes(bArr, j, iArr[i6], iArr2[i6]);
        }
    }

    public static int getDraftTeamSlot(byte[] bArr, long j, int i) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_DRAFT_TEAM_BITS), 5);
    }

    public static int getDraftYear(byte[] bArr, long j, int i) {
        return 2000 + ((int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_DRAFT_YEAR_BITS), 5));
    }

    public static int getDraftRound(byte[] bArr, long j, int i) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_DRAFT_ROUND_BITS), PLAYER_DRAFT_ROUND_WIDTH);
    }

    public static int getDraftPickInRound(byte[] bArr, long j, int i) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_DRAFT_PICK_BITS), 5);
    }

    public static void setDraftInfo(byte[] bArr, long j, int i, int i2, int i3, int i4, int i5) throws IOException {
        if (i2 < 0 || i2 > 29) {
            throw new IOException("Drafted By team must be 0-29.");
        }
        if (i3 < 2000 || i3 > 2031) {
            throw new IOException("Draft year must be 2000-2031.");
        }
        if (i4 < 0 || i4 > 3) {
            throw new IOException("Draft round must be 0-3.");
        }
        if (i5 < 0 || i5 > 31) {
            throw new IOException("Pick in round must be 0-31.");
        }
        long jPlayerPayload = playerPayload(j, i);
        writeBits(bArr, jPlayerPayload + ((long) PLAYER_DRAFT_TEAM_BITS), 5, i2);
        writeBits(bArr, jPlayerPayload + ((long) PLAYER_DRAFT_YEAR_BITS), 5, i3 - 2000);
        writeBits(bArr, jPlayerPayload + ((long) PLAYER_DRAFT_ROUND_BITS), PLAYER_DRAFT_ROUND_WIDTH, i4);
        writeBits(bArr, jPlayerPayload + ((long) PLAYER_DRAFT_PICK_BITS), 5, i5);
    }

    public static int getSignatureSlot(byte[] bArr, long j, int i, int i2) {
        if (i2 < 0 || i2 >= SIGNATURE_SLOT_BITS.length) {
            throw new IllegalArgumentException("index");
        }
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) SIGNATURE_SLOT_BITS[i2]), PLAYER_ROTATION_MINUTES_WIDTH);
    }

    public static void setSignatureSlot(byte[] bArr, long j, int i, int i2, int i3) {
        if (i2 < 0 || i2 >= SIGNATURE_SLOT_BITS.length) {
            throw new IllegalArgumentException("index");
        }
        if (i3 < 0 || i3 > 63) {
            throw new IllegalArgumentException("Signature ID must be 0-63.");
        }
        writeBits(bArr, playerPayload(j, i) + ((long) SIGNATURE_SLOT_BITS[i2]), PLAYER_ROTATION_MINUTES_WIDTH, i3);
    }

    public static int[] getSignatureSlots(byte[] bArr, long j, int i) {
        int[] iArr = new int[SIGNATURE_SLOT_BITS.length];
        for (int i2 = 0; i2 < iArr.length; i2++) {
            iArr[i2] = getSignatureSlot(bArr, j, i, i2);
        }
        return iArr;
    }

    public static final class RepairDraft {
        public final String changes;
        public final byte[] raw;

        RepairDraft(byte[] bArr, String str) {
            this.raw = bArr;
            this.changes = str;
        }
    }

    public static RepairDraft prepareRosterRepair(byte[] bArr) throws IOException {
        byte[] bArr2 = (byte[]) bArr.clone();
        RosterPlayerMap.Result result = RosterPlayerMap.parse(bArr2);
        HashMap map = new HashMap();
        int[][] iArr = new int[30][];
        for (int i = 0; i < 30; i++) {
            iArr[i] = getTeamRosterSlots(bArr2, result.teamTableBitOffset, i);
            for (int i2 : iArr[i]) {
                if (i2 < 0 || i2 >= result.players.size()) {
                    throw new IOException(new StringBuffer().append(new StringBuffer().append("Team ").append(i).toString()).append(" has an unknown player reference; manual membership repair required.").toString());
                }
                ArrayList arrayList = (ArrayList) map.get(new Integer(i2));
                if (arrayList == null) {
                    arrayList = new ArrayList();
                    map.put(new Integer(i2), arrayList);
                }
                if (!arrayList.contains(new Integer(i))) {
                    arrayList.add(new Integer(i));
                }
            }
        }
        HashMap map2 = new HashMap();
        for (Map.Entry entry : map.entrySet()) {
            int iIntValue = ((Integer) entry.getKey()).intValue();
            ArrayList arrayList2 = (ArrayList) entry.getValue();
            int primaryTeamId = getPrimaryTeamId(bArr2, result.playerTableBitOffset, iIntValue);
            if (arrayList2.size() > 1 && (isPrimaryFreeAgent(bArr2, result.playerTableBitOffset, iIntValue) || !arrayList2.contains(new Integer(primaryTeamId)))) {
                throw new IOException(new StringBuffer().append(new StringBuffer().append("Player S").append(iIntValue).toString()).append(" belongs to multiple teams with no matching primary team. Choose the intended team manually first.").toString());
            }
            map2.put(new Integer(iIntValue), new Integer(arrayList2.size() == 1 ? ((Integer) arrayList2.get(0)).intValue() : primaryTeamId));
        }
        StringBuilder sb = new StringBuilder();
        for (int i3 = 0; i3 < 30; i3++) {
            ArrayList arrayList3 = new ArrayList();
            for (int i4 : iArr[i3]) {
                if (((Integer) map2.get(new Integer(i4))).intValue() == i3 && !arrayList3.contains(new Integer(i4))) {
                    arrayList3.add(new Integer(i4));
                }
            }
            if (arrayList3.size() < 5) {
                throw new IOException(new StringBuffer().append(new StringBuffer().append("Team ").append(i3).toString()).append(" would have fewer than five players. Repair team membership first.").toString());
            }
            if (arrayList3.size() != iArr[i3].length) {
                long j = result.teamTableBitOffset + (((long) i3) * ((long) TEAM_STRIDE_BITS)) + ((long) 32);
                int i5 = 0;
                while (i5 < TEAM_PLAYER_REF_COUNT) {
                    writeBits(bArr2, j + (32 * ((long) i5)), 32, i5 < arrayList3.size() ? PLAYER_TAG_BASE | ((long) ((Integer) arrayList3.get(i5)).intValue()) : 0);
                    i5++;
                }
                writeBits(bArr2, j + ((long) TEAM_PLAYER_COUNT_BITS), 8, arrayList3.size());
                sb.append("Team ").append(i3).append(": remove duplicate membership entries.\n");
            }
            Iterator it = arrayList3.iterator();
            while (it.hasNext()) {
                int iIntValue2 = ((Integer) it.next()).intValue();
                if (isPrimaryFreeAgent(bArr2, result.playerTableBitOffset, iIntValue2) || getPrimaryTeamId(bArr2, result.playerTableBitOffset, iIntValue2) != i3) {
                    setPrimaryTeamAssignment(bArr2, result.playerTableBitOffset, iIntValue2, false, i3);
                    sb.append(result.players.get(iIntValue2).displayName).append(": match primary team to Team ").append(i3).append(".\n");
                }
            }
            int[] repairableStartingFive = getRepairableStartingFive(bArr2, result.teamTableBitOffset, i3);
            try {
                getTeamLineup(bArr2, result.teamTableBitOffset, i3, 0);
            } catch (IOException e) {
                setTeamLineup(bArr2, result.teamTableBitOffset, i3, 0, repairableStartingFive);
                sb.append("Team ").append(i3).append(": rebuild Starting 5 from valid members.\n");
            }
            int[] teamRosterSlots = getTeamRosterSlots(bArr2, result.teamTableBitOffset, i3);
            int[] iArr2 = new int[teamRosterSlots.length];
            int i6 = 0;
            boolean z = false;
            for (int i7 = 0; i7 < teamRosterSlots.length; i7++) {
                int rotationMinutes = getRotationMinutes(bArr2, result.playerTableBitOffset, teamRosterSlots[i7]);
                iArr2[i7] = Math.max(contains(repairableStartingFive, teamRosterSlots[i7]) ? 1 : 0, Math.min(48, rotationMinutes));
                z |= rotationMinutes != iArr2[i7];
                i6 += iArr2[i7];
            }
            if (i6 != 240 || z) {
                while (i6 != 240) {
                    int i8 = -1;
                    for (int i9 = 0; i9 < iArr2.length; i9++) {
                        int i10 = contains(repairableStartingFive, teamRosterSlots[i9]) ? 1 : 0;
                        if (i6 > 240 && iArr2[i9] > i10 && (i8 < 0 || iArr2[i9] > iArr2[i8])) {
                            i8 = i9;
                        }
                        if (i6 < 240 && iArr2[i9] < 48 && (i8 < 0 || ((iArr2[i9] > 0 && iArr2[i8] == 0) || (iArr2[i9] > 0 && iArr2[i8] > 0 && iArr2[i9] < iArr2[i8])))) {
                            i8 = i9;
                        }
                    }
                    if (i8 < 0) {
                        throw new IOException(new StringBuffer().append(new StringBuffer().append("Cannot balance Team ").append(i3).toString()).append(" rotation.").toString());
                    }
                    int i11 = i6 < 240 ? 1 : -1;
                    int i12 = i8;
                    iArr2[i12] = iArr2[i12] + i11;
                    i6 += i11;
                }
                setTeamRotationMinutes(bArr2, result.playerTableBitOffset, result.teamTableBitOffset, i3, teamRosterSlots, iArr2);
                sb.append("Team ").append(i3).append(": rebalance rotation to 240 minutes.\n");
            }
        }
        RosterValidator.Report reportValidate = RosterValidator.validate(bArr2, RosterPlayerMap.parse(bArr2));
        if (reportValidate.errors != 0) {
            throw new IOException(new StringBuffer().append("Repair needs manual review:\n").append(reportValidate.text()).toString());
        }
        return new RepairDraft(bArr2, sb.length() == 0 ? "No structural repairs needed." : sb.toString());
    }

    public static int[] getTeamRosterSlots(byte[] bArr, long j, int i) throws IOException {
        if (i < 0 || i >= 30) {
            throw new IOException("Invalid NBA team slot.");
        }
        long j2 = j + (((long) i) * ((long) TEAM_STRIDE_BITS)) + ((long) 32);
        int bits = (int) RosterPlayerMap.readBits(bArr, j2 + ((long) TEAM_PLAYER_COUNT_BITS), 8);
        if (bits < 0 || bits > TEAM_PLAYER_REF_COUNT) {
            throw new IOException("Team roster count is invalid.");
        }
        int[] iArr = new int[bits];
        for (int i2 = 0; i2 < bits; i2++) {
            long bits2 = RosterPlayerMap.readBits(bArr, j2 + (((long) i2) * 32), 32);
            if ((bits2 & 4293918720L) != PLAYER_TAG_BASE) {
                throw new IOException("Invalid PLAYERDATA reference in team roster.");
            }
            iArr[i2] = (int) (bits2 & 1048575);
        }
        return iArr;
    }

    public static void setTeamRosterOrder(byte[] bArr, long j, int i, int[] iArr) throws IOException {
        int[] teamRosterSlots = getTeamRosterSlots(bArr, j, i);
        if (iArr == null || iArr.length != teamRosterSlots.length) {
            throw new IOException("Depth chart must keep the same team members.");
        }
        boolean[] zArr = new boolean[teamRosterSlots.length];
        for (int i2 : iArr) {
            int i3 = -1;
            int i4 = 0;
            while (true) {
                if (i4 >= teamRosterSlots.length) {
                    break;
                }
                if (!zArr[i4] && teamRosterSlots[i4] == i2) {
                    i3 = i4;
                    break;
                }
                i4++;
            }
            if (i3 < 0) {
                throw new IOException("Depth chart contains a missing or duplicate player.");
            }
            zArr[i3] = true;
        }
        long j2 = j + (((long) i) * ((long) TEAM_STRIDE_BITS)) + ((long) 32);
        for (int i5 = 0; i5 < iArr.length; i5++) {
            writeBits(bArr, j2 + (((long) i5) * 32), 32, PLAYER_TAG_BASE | (((long) iArr[i5]) & 1048575));
        }
        for (int length = iArr.length; length < TEAM_PLAYER_REF_COUNT; length++) {
            writeBits(bArr, j2 + (((long) length) * 32), 32, 0L);
        }
        writeBits(bArr, j2 + ((long) TEAM_PLAYER_COUNT_BITS), 8, iArr.length);
    }

    public static int[] getTeamLineup(byte[] bArr, long j, int i, int i2) throws IOException {
        if (i < 0 || i >= 30) {
            throw new IOException("Invalid NBA team slot.");
        }
        if (i2 < 0 || i2 >= 7) {
            throw new IOException("Invalid lineup index.");
        }
        int[] teamRosterSlots = getTeamRosterSlots(bArr, j, i);
        int[] iArr = new int[5];
        long j2 = j + (((long) i) * ((long) TEAM_STRIDE_BITS)) + ((long) 32) + ((long) TEAM_LINEUP_BASE_BITS) + (((long) i2) * ((long) 5) * 32);
        for (int i3 = 0; i3 < 5; i3++) {
            long bits = RosterPlayerMap.readBits(bArr, j2 + (((long) i3) * 32), 32);
            if ((bits & 4293918720L) != PLAYER_TAG_BASE) {
                throw new IOException("Invalid PLAYERDATA reference in lineup.");
            }
            int i4 = (int) (bits & 1048575);
            if (!contains(teamRosterSlots, i4)) {
                throw new IOException("Lineup player is not in the team roster.");
            }
            for (int i5 = 0; i5 < i3; i5++) {
                if (iArr[i5] == i4) {
                    throw new IOException("Duplicate player in lineup.");
                }
            }
            iArr[i3] = i4;
        }
        return iArr;
    }

    public static int[] getRepairableStartingFive(byte[] bArr, long j, int i) throws IOException {
        int[] teamRosterSlots = getTeamRosterSlots(bArr, j, i);
        int[] iArr = new int[5];
        Arrays.fill(iArr, -1);
        int i2 = 0;
        long j2 = j + (((long) i) * ((long) TEAM_STRIDE_BITS)) + ((long) 32) + ((long) TEAM_LINEUP_BASE_BITS);
        for (int i3 = 0; i3 < 5; i3++) {
            long bits = RosterPlayerMap.readBits(bArr, j2 + (((long) i3) * 32), 32);
            int i4 = (int) (bits & 1048575);
            if ((bits & 4293918720L) == PLAYER_TAG_BASE && contains(teamRosterSlots, i4) && !contains(iArr, i4)) {
                int i5 = i2;
                i2++;
                iArr[i5] = i4;
            }
        }
        for (int i6 : teamRosterSlots) {
            if (i2 == 5) {
                break;
            }
            if (!contains(iArr, i6)) {
                int i7 = i2;
                i2++;
                iArr[i7] = i6;
            }
        }
        if (i2 < 5) {
            throw new IOException("Team needs five distinct roster members. Repair membership first.");
        }
        return iArr;
    }

    public static void setTeamLineup(byte[] bArr, long j, int i, int i2, int[] iArr) throws IOException {
        if (i2 < 0 || i2 >= 7) {
            throw new IOException("Invalid lineup index.");
        }
        if (iArr == null || iArr.length != 5) {
            throw new IOException("A lineup must contain exactly five players.");
        }
        int[] teamRosterSlots = getTeamRosterSlots(bArr, j, i);
        for (int i3 = 0; i3 < iArr.length; i3++) {
            if (!contains(teamRosterSlots, iArr[i3])) {
                throw new IOException("Lineup player is not in the team roster.");
            }
            for (int i4 = 0; i4 < i3; i4++) {
                if (iArr[i4] == iArr[i3]) {
                    throw new IOException("A lineup cannot contain duplicate players.");
                }
            }
        }
        long j2 = j + (((long) i) * ((long) TEAM_STRIDE_BITS)) + ((long) 32) + ((long) TEAM_LINEUP_BASE_BITS) + (((long) i2) * ((long) 5) * 32);
        for (int i5 = 0; i5 < 5; i5++) {
            writeBits(bArr, j2 + (((long) i5) * 32), 32, PLAYER_TAG_BASE | (((long) iArr[i5]) & 1048575));
        }
    }

    private static boolean contains(int[] iArr, int i) {
        for (int i2 : iArr) {
            if (i2 == i) {
                return true;
            }
        }
        return false;
    }

    public static int getAccessory(byte[] bArr, long j, int i, AccessoryField accessoryField) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) accessoryField.serializedBit), accessoryField.width);
    }

    public static void setAccessory(byte[] bArr, long j, int i, AccessoryField accessoryField, int i2) {
        if (i2 < 0 || i2 > accessoryField.maxValue()) {
            throw new IllegalArgumentException(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(accessoryField.label).append(" must be 0-").toString()).append(accessoryField.maxValue()).toString()).append(".").toString());
        }
        writeBits(bArr, playerPayload(j, i) + ((long) accessoryField.serializedBit), accessoryField.width, i2);
    }

    public static int[] getAccessorySet(byte[] bArr, long j, int i) {
        int[] iArr = new int[ACCESSORY_FIELDS.length];
        for (int i2 = 0; i2 < iArr.length; i2++) {
            iArr[i2] = getAccessory(bArr, j, i, ACCESSORY_FIELDS[i2]);
        }
        return iArr;
    }

    public static final class PlayTypeField {
        public final String label;
        public final int serializedBit;

        PlayTypeField(String str, int i) {
            this.label = str;
            this.serializedBit = i;
        }
    }

    public static int getPlayType(byte[] bArr, long j, int i, PlayTypeField playTypeField) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) playTypeField.serializedBit), PLAYER_BIRTH_MONTH_WIDTH);
    }

    public static void setPlayType(byte[] bArr, long j, int i, PlayTypeField playTypeField, int i2) {
        if (i2 < 0 || i2 > 15) {
            throw new IllegalArgumentException(new StringBuffer().append(playTypeField.label).append(" must be 0-15.").toString());
        }
        writeBits(bArr, playerPayload(j, i) + ((long) playTypeField.serializedBit), PLAYER_BIRTH_MONTH_WIDTH, i2);
    }

    public static int[] getPlayTypeSet(byte[] bArr, long j, int i) {
        int[] iArr = new int[PLAY_TYPE_FIELDS.length];
        for (int i2 = 0; i2 < iArr.length; i2++) {
            iArr[i2] = getPlayType(bArr, j, i, PLAY_TYPE_FIELDS[i2]);
        }
        return iArr;
    }

    public static final class TendencyField {
        public final int index;
        public final String label;

        TendencyField(String str, int i) {
            this.label = str;
            this.index = i;
        }

        int serializedBit() {
            return 3490 + (this.index * 8);
        }
    }

    public static int getTendency(byte[] bArr, long j, int i, TendencyField tendencyField) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) tendencyField.serializedBit()), 8);
    }

    public static void setTendency(byte[] bArr, long j, int i, TendencyField tendencyField, int i2) {
        if (i2 < 0 || i2 > 100) {
            throw new IllegalArgumentException(new StringBuffer().append(tendencyField.label).append(" must be 0-100.").toString());
        }
        writeBits(bArr, playerPayload(j, i) + ((long) tendencyField.serializedBit()), 8, i2);
    }

    public static int badgeCount() {
        return 44;
    }

    public static int getBadgeLevel(byte[] bArr, long j, int i, int i2) {
        if (i2 < 0 || i2 >= 44) {
            throw new IllegalArgumentException("badgeIndex");
        }
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) BADGE_LEVEL_SERIAL_BASE_BITS) + (((long) i2) * 2), PLAYER_DRAFT_ROUND_WIDTH);
    }

    public static void setBadgeLevel(byte[] bArr, long j, int i, int i2, int i3) {
        if (i2 < 0 || i2 >= 44) {
            throw new IllegalArgumentException("badgeIndex");
        }
        if (i3 < 0 || i3 > 3) {
            throw new IllegalArgumentException("Badge level must be 0-3.");
        }
        writeBits(bArr, playerPayload(j, i) + ((long) BADGE_LEVEL_SERIAL_BASE_BITS) + (((long) i2) * 2), PLAYER_DRAFT_ROUND_WIDTH, i3);
    }

    public static int hotZoneCount() {
        return HOT_ZONE_LABELS.length;
    }

    public static int getHotZone(byte[] bArr, long j, int i, int i2) {
        throw new UnsupportedOperationException("Hot Zones remap pending.");
    }

    public static int[] getHotZoneSet(byte[] bArr, long j, int i) {
        throw new UnsupportedOperationException("Hot Zones remap pending.");
    }

    public static void setHotZone(byte[] bArr, long j, int i, int i2, int i3) {
        throw new UnsupportedOperationException("Hot Zones remap pending.");
    }

    public static void setHotZoneSet(byte[] bArr, long j, int i, int[] iArr) {
        throw new UnsupportedOperationException("Hot Zones remap pending.");
    }

    public static int getContractOption(byte[] bArr, long j, int i) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) CONTRACT_OPTION_BITS), PLAYER_DRAFT_ROUND_WIDTH);
    }

    public static void setContractOption(byte[] bArr, long j, int i, int i2) {
        if (i2 < 0 || i2 > 3) {
            throw new IllegalArgumentException("Contract option must be 0-3.");
        }
        writeBits(bArr, playerPayload(j, i) + ((long) CONTRACT_OPTION_BITS), PLAYER_DRAFT_ROUND_WIDTH, i2);
    }

    public static boolean getContractNoTrade(byte[] bArr, long j, int i) {
        return RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) CONTRACT_NO_TRADE_BITS), 1) != ((long) 0);
    }

    public static void setContractNoTrade(byte[] bArr, long j, int i, boolean z) {
        writeBits(bArr, playerPayload(j, i) + ((long) CONTRACT_NO_TRADE_BITS), 1, z ? 1 : 0);
    }

    public static long getContractSalary(byte[] bArr, long j, int i, int i2) {
        if (i2 < 0 || i2 >= 7) {
            throw new IllegalArgumentException("yearIndex");
        }
        return RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) CONTRACT_YEAR1_BITS) + (((long) i2) * 32), 32);
    }

    public static void setContractSalary(byte[] bArr, long j, int i, int i2, long j2) {
        if (i2 < 0 || i2 >= 7) {
            throw new IllegalArgumentException("yearIndex");
        }
        if (j2 < 0 || j2 > 4294967295L) {
            throw new IllegalArgumentException("Salary is out of range.");
        }
        writeBits(bArr, playerPayload(j, i) + ((long) CONTRACT_YEAR1_BITS) + (((long) i2) * 32), 32, j2);
    }

    public static int contractYearCount() {
        return 7;
    }

    public static final class RatingField {
        public final String label;
        public final int structOffset;

        RatingField(String str, int i) {
            this.label = str;
            this.structOffset = i;
        }

        int serializedBit() {
            return 3154 + ((this.structOffset - 460) * 8);
        }
    }

    public static final class AnimationField {
        public final String label;
        public final int serializedBit;
        public final int width;

        AnimationField(String str, int i, int i2) {
            this.label = str;
            this.serializedBit = i;
            this.width = i2;
        }

        public int maxValue() {
            return this.width >= 31 ? Integer.MAX_VALUE : (1 << this.width) - 1;
        }
    }

    public static int getAnimation(byte[] bArr, long j, int i, AnimationField animationField) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) animationField.serializedBit), animationField.width);
    }

    public static void setAnimation(byte[] bArr, long j, int i, AnimationField animationField, int i2) {
        if (i2 < 0 || i2 > animationField.maxValue()) {
            throw new IllegalArgumentException(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(animationField.label).append(" must be 0-").toString()).append(animationField.maxValue()).toString()).append(".").toString());
        }
        writeBits(bArr, playerPayload(j, i) + ((long) animationField.serializedBit), animationField.width, i2);
    }

    public static int[] getAnimationSet(byte[] bArr, long j, int i) {
        int[] iArr = new int[ANIMATION_FIELDS.length];
        for (int i2 = 0; i2 < ANIMATION_FIELDS.length; i2++) {
            iArr[i2] = getAnimation(bArr, j, i, ANIMATION_FIELDS[i2]);
        }
        return iArr;
    }

    public static boolean[] animationMaskForGroup(int i) {
        if (i < 0 || i >= ANIMATION_GROUP_INDICES.length) {
            throw new IllegalArgumentException("Invalid animation group.");
        }
        boolean[] zArr = new boolean[ANIMATION_FIELDS.length];
        for (int i2 : ANIMATION_GROUP_INDICES[i]) {
            if (i2 < 0 || i2 >= zArr.length) {
                throw new IllegalStateException(new StringBuffer().append("Animation group index out of range: ").append(i2).toString());
            }
            zArr[i2] = true;
        }
        return zArr;
    }

    public static boolean[] animationMaskAll() {
        boolean[] zArr = new boolean[ANIMATION_FIELDS.length];
        for (int i = 0; i < zArr.length; i++) {
            zArr[i] = true;
        }
        return zArr;
    }

    public static int countAnimationDifferences(int[] iArr, int[] iArr2) {
        if (iArr == null || iArr2 == null || iArr.length != iArr2.length) {
            throw new IllegalArgumentException("Animation sets must be the same size.");
        }
        int i = 0;
        for (int i2 = 0; i2 < iArr.length; i2++) {
            if (iArr[i2] != iArr2[i2]) {
                i++;
            }
        }
        return i;
    }

    public static int getRating(byte[] bArr, long j, int i, RatingField ratingField) {
        int iRound = Math.round((((int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) ratingField.serializedBit()), 8)) / 3.0f) + 25.0f);
        if (iRound < 25) {
            iRound = 25;
        }
        if (iRound > 99) {
            iRound = 99;
        }
        return iRound;
    }

    public static void setRating(byte[] bArr, long j, int i, RatingField ratingField, int i2) {
        if (i2 < 25 || i2 > 99) {
            throw new IllegalArgumentException("Rating must be 25-99.");
        }
        writeBits(bArr, playerPayload(j, i) + ((long) ratingField.serializedBit()), 8, (i2 - 25) * 3);
    }

    public static void setJersey(byte[] bArr, long j, int i, int i2) {
        if (i2 < 0 || i2 > 99) {
            throw new IllegalArgumentException("Jersey must be 0-99.");
        }
        writeBits(bArr, playerPayload(j, i) + ((long) PLAYER_JERSEY_BITS), 7, i2);
    }

    public static void setCyberface(byte[] bArr, long j, int i, int i2) {
        if (i2 < 0 || i2 > 65535) {
            throw new IllegalArgumentException("CF ID must be 0-65535.");
        }
        writeBits(bArr, playerPayload(j, i) + ((long) PLAYER_CF_BITS), 16, i2);
    }

    public static void setPortrait(byte[] bArr, long j, int i, int i2) {
        if (i2 < 0 || i2 > 65535) {
            throw new IllegalArgumentException("Portrait ID must be 0-65535.");
        }
        writeBits(bArr, playerPayload(j, i) + ((long) PLAYER_PORTRAIT_BITS), 16, i2);
    }

    public static int getBodyType(byte[] bArr, long j, int i) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_BODY_TYPE_BITS), PLAYER_DRAFT_ROUND_WIDTH);
    }

    public static int getMuscleType(byte[] bArr, long j, int i) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_MUSCLE_TYPE_BITS), 1);
    }

    public static int getSkinTone(byte[] bArr, long j, int i) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_SKIN_TONE_BITS), 3);
    }

    public static int getEyeColor(byte[] bArr, long j, int i) {
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_EYE_COLOR_BITS), 3);
    }

    public static void setBodyType(byte[] bArr, long j, int i, int i2) {
        if (i2 < 0 || i2 > 3) {
            throw new IllegalArgumentException("Body Type must be 0-3.");
        }
        writeBits(bArr, playerPayload(j, i) + ((long) PLAYER_BODY_TYPE_BITS), PLAYER_DRAFT_ROUND_WIDTH, i2);
    }

    public static void setMuscleType(byte[] bArr, long j, int i, int i2) {
        if (i2 < 0 || i2 > 1) {
            throw new IllegalArgumentException("Muscle Type must be 0-1.");
        }
        writeBits(bArr, playerPayload(j, i) + ((long) PLAYER_MUSCLE_TYPE_BITS), 1, i2);
    }

    public static void setSkinTone(byte[] bArr, long j, int i, int i2) {
        if (i2 < 0 || i2 > 5) {
            throw new IllegalArgumentException("Skin Tone must be 0-5.");
        }
        writeBits(bArr, playerPayload(j, i) + ((long) PLAYER_SKIN_TONE_BITS), 3, i2);
    }

    public static void setEyeColor(byte[] bArr, long j, int i, int i2) {
        if (i2 < 0 || i2 > 5) {
            throw new IllegalArgumentException("Eye Color must be 0-5.");
        }
        writeBits(bArr, playerPayload(j, i) + ((long) PLAYER_EYE_COLOR_BITS), 3, i2);
    }

    public static boolean hasExpectedPlayerTag(byte[] bArr, long j, int i) {
        if (bArr == null || j < 0 || i < 0 || i >= 1048576) {
            return false;
        }
        long j2 = j + (((long) i) * ((long) PLAYER_STRIDE_BITS));
        long length = ((long) bArr.length) * 8;
        if (j2 < 0 || j2 + 32 > length) {
            return false;
        }
        return RosterPlayerMap.readBits(bArr, j2, 32) == (PLAYER_TAG_BASE | (((long) i) & 1048575));
    }

    public static int findUnusedPlaceholder(byte[] bArr, long j, long j2, int i, List<RosterPlayerMap.PlayerRecord> list, int i2) {
        if (bArr == null || list == null) {
            return -1;
        }
        for (RosterPlayerMap.PlayerRecord playerRecord : list) {
            if (playerRecord.slot != i2 && playerRecord.activeTeamSlot < 0 && !playerRecord.hasUsableCyberfaceId() && isSyntheticPlaceholderName(playerRecord) && !isReferencedByAnySerializedTeam(bArr, j2, i, playerRecord.slot)) {
                return playerRecord.slot;
            }
        }
        return -1;
    }

    private static boolean isSyntheticPlaceholderName(RosterPlayerMap.PlayerRecord playerRecord) {
        if (playerRecord == null) {
            return false;
        }
        String strTrim = playerRecord.displayName == null ? "" : playerRecord.displayName.trim();
        return strTrim.length() == 0 || strTrim.startsWith("Player ");
    }

    public static boolean canExpandPlayerTable(byte[] bArr, long j, long j2, int i) {
        if (bArr == null || i < 0 || i >= 1048576) {
            return false;
        }
        long length = ((long) bArr.length) * 8;
        long j3 = j + (((long) i) * ((long) PLAYER_STRIDE_BITS));
        if (j < 0 || j2 <= j3) {
            return false;
        }
        if (j3 < 0 || j3 + 32 > length) {
            return false;
        }
        if (j2 < 0 || j2 + 32 > length) {
            return false;
        }
        if (RosterPlayerMap.readBits(bArr, j2, 32) != TEAM_TAG_BASE) {
            return false;
        }
        return RosterPlayerMap.readBits(bArr, j3, 32) != (PLAYER_TAG_BASE | (((long) i) & 1048575));
    }

    public static byte[] clonePlayerByExpandingTable(byte[] bArr, long j, long j2, int i, int i2, int i3, int i4) throws IOException {
        if (!canExpandPlayerTable(bArr, j, j2, i)) {
            throw new IOException("PLAYERDATA table expansion is not safe for this roster layout.");
        }
        if (i2 < 0 || i2 >= i) {
            throw new IOException("Invalid source player slot.");
        }
        if (i3 < 0 || i3 >= 30) {
            throw new IOException("Invalid NBA team slot.");
        }
        if (i4 < 0 || i4 >= TEAM_PLAYER_REF_COUNT) {
            throw new IOException("This team already has the maximum 20 roster entries.");
        }
        long j3 = j + (((long) i) * ((long) PLAYER_STRIDE_BITS));
        byte[] bArrInsertZeroBits = insertZeroBits(bArr, j3, PLAYER_STRIDE_BITS);
        writeBits(bArrInsertZeroBits, j3, 32, PLAYER_TAG_BASE | (((long) i) & 1048575));
        copyBits(bArrInsertZeroBits, playerPayload(j, i2), j3 + ((long) 32), PLAYER_PAYLOAD_BITS);
        long j4 = j2 + ((long) PLAYER_STRIDE_BITS) + (((long) i3) * ((long) TEAM_STRIDE_BITS)) + ((long) 32);
        writeBits(bArrInsertZeroBits, j4 + (((long) i4) * 32), 32, PLAYER_TAG_BASE | (((long) i) & 1048575));
        writeBits(bArrInsertZeroBits, j4 + ((long) TEAM_PLAYER_COUNT_BITS), 8, i4 + 1);
        setPrimaryTeamAssignment(bArrInsertZeroBits, j, i, false, i3);
        return bArrInsertZeroBits;
    }

    private static byte[] insertZeroBits(byte[] bArr, long j, int i) throws IOException {
        long j2;
        if (bArr == null || i <= 0) {
            throw new IOException("Invalid expansion request.");
        }
        long length = ((long) bArr.length) * 8;
        if (j < 0 || j > length) {
            throw new IOException("Invalid PLAYERDATA expansion boundary.");
        }
        long j3 = ((length + ((long) i)) + 7) >>> 3;
        if (j3 <= 0 || j3 > Integer.MAX_VALUE) {
            throw new IOException("Expanded roster is too large.");
        }
        byte[] bArr2 = new byte[(int) j3];
        int i2 = (int) (j >>> 3);
        if (i2 > 0) {
            System.arraycopy(bArr, 0, bArr2, 0, i2);
        }
        int i3 = (int) (j & 7);
        if (i3 != 0 && i2 < bArr.length) {
            bArr2[i2] = (byte) (bArr[i2] & 255 & (255 << (8 - i3)) & 255);
        }
        long j4 = j;
        long j5 = j + ((long) i);
        long j6 = length;
        long j7 = j;
        while (true) {
            j2 = j6 - j7;
            if (j2 < 8) {
                break;
            }
            writeByteAtBit(bArr2, j5, readByteAtBit(bArr, j4));
            j4 += 8;
            j5 += 8;
            j6 = j2;
            j7 = 8;
        }
        while (j2 > 0) {
            writeBits(bArr2, j5, 1, (int) RosterPlayerMap.readBits(bArr, j4, 1));
            j4++;
            j5++;
            j2--;
        }
        return bArr2;
    }

    private static int readByteAtBit(byte[] bArr, long j) {
        int i;
        int i2 = (int) (j >>> 3);
        int i3 = (int) (j & 7);
        int i4 = bArr[i2] & 255;
        if (i3 == 0) {
            return i4;
        }
        if (i2 + 1 < bArr.length) {
            i = bArr[i2 + 1] & 255;
        } else {
            i = 0;
        }
        return ((i4 << i3) & 255) | (i >>> (8 - i3));
    }

    private static void writeByteAtBit(byte[] bArr, long j, int i) {
        int i2 = (int) (j >>> 3);
        int i3 = (int) (j & 7);
        int i4 = i & 255;
        if (i3 != 0) {
            bArr[i2] = (byte) ((bArr[i2] & 255 & (255 << (8 - i3)) & 255) | (i4 >>> i3));
            bArr[i2 + 1] = (byte) ((bArr[i2 + 1] & 255 & ((1 << (8 - i3)) - 1)) | ((i4 & ((1 << i3) - 1)) << (8 - i3)));
            return;
        }
        bArr[i2] = (byte) i4;
    }

    private static boolean isReferencedByAnySerializedTeam(byte[] bArr, long j, int i, int i2) {
        long j2 = PLAYER_TAG_BASE | (((long) i2) & 1048575);
        int iMax = Math.max(0, Math.min(i, 1024));
        for (int i3 = 0; i3 < iMax; i3++) {
            long j3 = j + (((long) i3) * ((long) TEAM_STRIDE_BITS)) + ((long) 32);
            int bits = (int) RosterPlayerMap.readBits(bArr, j3 + ((long) TEAM_PLAYER_COUNT_BITS), 8);
            if (bits < 0) {
                bits = 0;
            }
            if (bits > TEAM_PLAYER_REF_COUNT) {
                bits = TEAM_PLAYER_REF_COUNT;
            }
            for (int i4 = 0; i4 < bits; i4++) {
                if (RosterPlayerMap.readBits(bArr, j3 + (((long) i4) * 32), 32) == j2) {
                    return true;
                }
            }
        }
        return false;
    }

    public static void clonePlayerToTeam(byte[] bArr, long j, long j2, int i, int i2, int i3, int i4) throws IOException {
        if (i < 0 || i2 < 0) {
            throw new IOException("Invalid player slot.");
        }
        if (i3 < 0 || i3 >= 30) {
            throw new IOException("Invalid NBA team slot.");
        }
        if (i4 < 0 || i4 >= TEAM_PLAYER_REF_COUNT) {
            throw new IOException("This team already has the maximum 20 roster entries.");
        }
        copyBits(bArr, playerPayload(j, i), playerPayload(j, i2), PLAYER_PAYLOAD_BITS);
        long j3 = j2 + (((long) i3) * ((long) TEAM_STRIDE_BITS)) + ((long) 32);
        writeBits(bArr, j3 + (((long) i4) * 32), 32, PLAYER_TAG_BASE | (((long) i2) & 1048575));
        writeBits(bArr, j3 + ((long) TEAM_PLAYER_COUNT_BITS), 8, i4 + 1);
        setPrimaryTeamAssignment(bArr, j, i2, false, i3);
    }

    public static void movePlayerBetweenTeams(byte[] bArr, long j, long j2, int i, int i2, int i3) throws IOException {
        if (bArr == null) {
            throw new IOException("Roster data is empty.");
        }
        if (i < 0) {
            throw new IOException("Invalid player slot.");
        }
        if (i2 < 0 || i2 >= 30 || i3 < 0 || i3 >= 30) {
            throw new IOException("Invalid NBA team slot.");
        }
        if (i2 == i3) {
            throw new IOException("Player is already on that team.");
        }
        long j3 = PLAYER_TAG_BASE | (((long) i) & 1048575);
        long j4 = j2 + (((long) i2) * ((long) TEAM_STRIDE_BITS)) + ((long) 32);
        long j5 = j2 + (((long) i3) * ((long) TEAM_STRIDE_BITS)) + ((long) 32);
        int bits = (int) RosterPlayerMap.readBits(bArr, j4 + ((long) TEAM_PLAYER_COUNT_BITS), 8);
        int bits2 = (int) RosterPlayerMap.readBits(bArr, j5 + ((long) TEAM_PLAYER_COUNT_BITS), 8);
        if (bits < 1 || bits > TEAM_PLAYER_REF_COUNT) {
            throw new IOException("Source team membership is invalid.");
        }
        if (bits2 < 0 || bits2 >= TEAM_PLAYER_REF_COUNT) {
            throw new IOException("Destination team already has 20 roster entries.");
        }
        int i4 = -1;
        int i5 = 0;
        while (true) {
            if (i5 >= bits) {
                break;
            }
            if (RosterPlayerMap.readBits(bArr, j4 + (((long) i5) * 32), 32) == j3) {
                i4 = i5;
                break;
            }
            i5++;
        }
        if (i4 < 0) {
            throw new IOException("Player reference was not found on the source team.");
        }
        for (int i6 = 0; i6 < bits2; i6++) {
            if (RosterPlayerMap.readBits(bArr, j5 + (((long) i6) * 32), 32) == j3) {
                throw new IOException("Player is already referenced by the destination team.");
            }
        }
        for (int i7 = i4; i7 < bits - 1; i7++) {
            writeBits(bArr, j4 + (((long) i7) * 32), 32, RosterPlayerMap.readBits(bArr, j4 + (((long) (i7 + 1)) * 32), 32));
        }
        writeBits(bArr, j4 + (((long) (bits - 1)) * 32), 32, 0L);
        writeBits(bArr, j4 + ((long) TEAM_PLAYER_COUNT_BITS), 8, bits - 1);
        writeBits(bArr, j5 + (((long) bits2) * 32), 32, j3);
        writeBits(bArr, j5 + ((long) TEAM_PLAYER_COUNT_BITS), 8, bits2 + 1);
        setPrimaryTeamAssignment(bArr, j, i, false, i3);
    }

    public static boolean isPrimaryFreeAgent(byte[] bArr, long j, int i) {
        if (bArr == null || j < 0 || i < 0) {
            return false;
        }
        return RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_PRIMARY_FA_MARKER_BITS), 16) == 0;
    }

    public static int getPrimaryTeamId(byte[] bArr, long j, int i) {
        if (bArr == null || j < 0 || i < 0) {
            return -1;
        }
        return (int) RosterPlayerMap.readBits(bArr, playerPayload(j, i) + ((long) PLAYER_PRIMARY_TEAM_ID_BITS), 8);
    }

    public static boolean isReferencedBySerializedTeam(byte[] bArr, long j, int i, int i2) {
        return isReferencedByAnySerializedTeam(bArr, j, i, i2);
    }

    public static void releasePlayerToFreeAgency(byte[] bArr, long j, long j2, int i, int i2) throws IOException {
        if (i2 < 0 || i2 >= 30) {
            throw new IOException("Invalid source team.");
        }
        removePlayerRefFromTeam(bArr, j2, i, i2);
        setPrimaryTeamAssignment(bArr, j, i, true, 0);
    }

    public static void assignFreeAgentToTeam(byte[] bArr, long j, long j2, int i, int i2, int i3) throws IOException {
        if (i3 < 0 || i3 >= 30) {
            throw new IOException("Invalid destination team.");
        }
        if (!isPrimaryFreeAgent(bArr, j, i2)) {
            throw new IOException("Selected player is not marked as a primary free agent.");
        }
        if (isReferencedByActiveNbaTeam(bArr, j2, i2)) {
            throw new IOException("Player is still referenced by an active NBA team.");
        }
        appendPlayerRefToTeam(bArr, j2, i2, i3);
        setPrimaryTeamAssignment(bArr, j, i2, false, i3);
    }

    private static boolean isReferencedByActiveNbaTeam(byte[] bArr, long j, int i) {
        long j2 = PLAYER_TAG_BASE | (((long) i) & 1048575);
        for (int i2 = 0; i2 < 30; i2++) {
            long j3 = j + (((long) i2) * ((long) TEAM_STRIDE_BITS)) + ((long) 32);
            int bits = (int) RosterPlayerMap.readBits(bArr, j3 + ((long) TEAM_PLAYER_COUNT_BITS), 8);
            if (bits < 0) {
                bits = 0;
            }
            if (bits > TEAM_PLAYER_REF_COUNT) {
                bits = TEAM_PLAYER_REF_COUNT;
            }
            for (int i3 = 0; i3 < bits; i3++) {
                if (RosterPlayerMap.readBits(bArr, j3 + (((long) i3) * 32), 32) == j2) {
                    return true;
                }
            }
        }
        return false;
    }

    private static void setPrimaryTeamAssignment(byte[] bArr, long j, int i, boolean z, int i2) {
        long jPlayerPayload = playerPayload(j, i);
        writeBits(bArr, jPlayerPayload + ((long) PLAYER_PRIMARY_FA_MARKER_BITS), 16, z ? 0L : PLAYER_ACTIVE_ROSTER_MARKER);
        writeBits(bArr, jPlayerPayload + ((long) PLAYER_PRIMARY_TEAM_ID_BITS), 8, z ? 0L : i2 & 255);
    }

    private static void removePlayerRefFromTeam(byte[] bArr, long j, int i, int i2) throws IOException {
        long j2 = PLAYER_TAG_BASE | (((long) i) & 1048575);
        long j3 = j + (((long) i2) * ((long) TEAM_STRIDE_BITS)) + ((long) 32);
        int bits = (int) RosterPlayerMap.readBits(bArr, j3 + ((long) TEAM_PLAYER_COUNT_BITS), 8);
        if (bits < 1 || bits > TEAM_PLAYER_REF_COUNT) {
            throw new IOException("Source team membership is invalid.");
        }
        int i3 = -1;
        int i4 = 0;
        while (true) {
            if (i4 >= bits) {
                break;
            }
            if (RosterPlayerMap.readBits(bArr, j3 + (((long) i4) * 32), 32) == j2) {
                i3 = i4;
                break;
            }
            i4++;
        }
        if (i3 < 0) {
            throw new IOException("Player reference was not found on the source team.");
        }
        for (int i5 = i3; i5 < bits - 1; i5++) {
            writeBits(bArr, j3 + (((long) i5) * 32), 32, RosterPlayerMap.readBits(bArr, j3 + (((long) (i5 + 1)) * 32), 32));
        }
        writeBits(bArr, j3 + (((long) (bits - 1)) * 32), 32, 0L);
        writeBits(bArr, j3 + ((long) TEAM_PLAYER_COUNT_BITS), 8, bits - 1);
    }

    private static void appendPlayerRefToTeam(byte[] bArr, long j, int i, int i2) throws IOException {
        long j2 = PLAYER_TAG_BASE | (((long) i) & 1048575);
        long j3 = j + (((long) i2) * ((long) TEAM_STRIDE_BITS)) + ((long) 32);
        int bits = (int) RosterPlayerMap.readBits(bArr, j3 + ((long) TEAM_PLAYER_COUNT_BITS), 8);
        if (bits < 0 || bits >= TEAM_PLAYER_REF_COUNT) {
            throw new IOException("Destination team already has 20 roster entries.");
        }
        for (int i3 = 0; i3 < bits; i3++) {
            if (RosterPlayerMap.readBits(bArr, j3 + (((long) i3) * 32), 32) == j2) {
                throw new IOException("Player is already referenced by the destination team.");
            }
        }
        writeBits(bArr, j3 + (((long) bits) * 32), 32, j2);
        writeBits(bArr, j3 + ((long) TEAM_PLAYER_COUNT_BITS), 8, bits + 1);
    }

    public static int getTeamHeadCoachSlot(byte[] bArr, long j, int i) {
        return RosterStaffMap.getHeadCoachSlot(bArr, j, i);
    }

    public static int getTeamAssistantCoachSlot(byte[] bArr, long j, int i) {
        return RosterStaffMap.getAssistantCoachSlot(bArr, j, i);
    }

    public static void setTeamHeadCoach(byte[] bArr, long j, int i, int i2) {
        writeTeamStaffRef(bArr, j, i, RosterStaffMap.TEAM_HEAD_COACH_REF_BITS, i2);
    }

    public static void setTeamAssistantCoach(byte[] bArr, long j, int i, int i2) {
        writeTeamStaffRef(bArr, j, i, RosterStaffMap.TEAM_ASSISTANT_COACH_REF_BITS, i2);
    }

    private static void writeTeamStaffRef(byte[] bArr, long j, int i, int i2, int i3) {
        if (i < 0 || i >= 30) {
            throw new IllegalArgumentException("teamSlot");
        }
        writeBits(bArr, j + (((long) i) * ((long) TEAM_STRIDE_BITS)) + ((long) 32) + ((long) i2), 32, RosterStaffMap.makeStaffRef(i3));
    }

    public static void writeBits(byte[] bArr, long j, int i, long j2) {
        if (i < 1 || i > 32) {
            throw new IllegalArgumentException("width");
        }
        long length = ((long) bArr.length) * 8;
        if (j < 0 || j + ((long) i) > length) {
            throw new IllegalArgumentException("bitPosition");
        }
        long j3 = i == 32 ? j2 & 4294967295L : j2 & ((1 << i) - 1);
        for (int i2 = 0; i2 < i; i2++) {
            long j4 = j + ((long) i2);
            int i3 = (int) (j4 >>> 3);
            int i4 = 1 << (7 - (((int) j4) & 7));
            if (((int) ((j3 >>> ((i - 1) - i2)) & 1)) != 0) {
                bArr[i3] = (byte) ((bArr[i3] & 255) | i4);
            } else {
                bArr[i3] = (byte) (bArr[i3] & 255 & (i4 ^ (-1)));
            }
        }
    }

    private static long playerPayload(long j, int i) {
        return j + (((long) i) * ((long) PLAYER_STRIDE_BITS)) + ((long) 32);
    }

    private static void copyBits(byte[] bArr, long j, long j2, int i) {
        for (int i2 = 0; i2 < i; i2++) {
            long j3 = j + ((long) i2);
            int i3 = ((bArr[(int) (j3 >>> 3)] & 255) >>> (7 - (((int) j3) & 7))) & 1;
            long j4 = j2 + ((long) i2);
            int i4 = (int) (j4 >>> 3);
            int i5 = 1 << (7 - (((int) j4) & 7));
            if (i3 != 0) {
                bArr[i4] = (byte) ((bArr[i4] & 255) | i5);
            } else {
                bArr[i4] = (byte) (bArr[i4] & 255 & (i5 ^ (-1)));
            }
        }
    }

    RosterEditor() {
    }
}
