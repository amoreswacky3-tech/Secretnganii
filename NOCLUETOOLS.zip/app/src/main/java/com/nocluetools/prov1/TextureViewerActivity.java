package com.nocluetools.prov1;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TextureViewerActivity extends Activity {

    // Top Bar & Headers
    TextView popupClose, popupPrev, popupNext, btnSaveIff;
    TextView popupTitle, popupInfo, popupMeta, popupFormat, popupPayload;

    // Preview & Lists
    ImageView popupImage;
    ListView embeddedTextureList;
    TextView popupExport, popupImport, popupReplace;

    // State Data
    String sessionId = "";
    int fileIndex = 0;
    String iffName = "";
    int currentTextureIndex = 0;
    int totalTextures = 0;

    // List Data
    ArrayAdapter<String> listAdapter;
    List<String> textureList = new ArrayList<>();

    Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_texture_viewer); // Use your XML filename

        // Get data from the previous screen
        sessionId = getIntent().getStringExtra("SESSION_ID");
        fileIndex = getIntent().getIntExtra("FILE_INDEX", 0);
        iffName = getIntent().getStringExtra("IFF_NAME");

        initViews();
        setupListeners();

        if (iffName != null) {
            popupTitle.setText(iffName);
        }

        // Load the initial texture
        loadTexturePreview(currentTextureIndex);
        loadTextureList();
    }

    private void initViews() {
        popupClose = findViewById(R.id.popupClose);
        popupPrev = findViewById(R.id.popupPrev);
        popupNext = findViewById(R.id.popupNext);
        btnSaveIff = findViewById(R.id.btnSaveIff);

        popupTitle = findViewById(R.id.popupTitle);
        popupInfo = findViewById(R.id.popupInfo);
        popupMeta = findViewById(R.id.popupMeta);
        popupFormat = findViewById(R.id.popupFormat);
        popupPayload = findViewById(R.id.popupPayload);

        popupImage = findViewById(R.id.popupImage);
        embeddedTextureList = findViewById(R.id.embeddedTextureList);

        popupExport = findViewById(R.id.popupExport);
        popupImport = findViewById(R.id.popupImport);
        popupReplace = findViewById(R.id.popupReplace);
    }

    private void setupListeners() {
        popupClose.setOnClickListener(v -> finish());

        popupPrev.setOnClickListener(v -> {
            if (currentTextureIndex > 0) {
                currentTextureIndex--;
                loadTexturePreview(currentTextureIndex);
            } else {
                Toast.makeText(this, "First texture reached.", Toast.LENGTH_SHORT).show();
            }
        });

        popupNext.setOnClickListener(v -> {
            if (currentTextureIndex < totalTextures - 1) {
                currentTextureIndex++;
                loadTexturePreview(currentTextureIndex);
            } else {
                Toast.makeText(this, "Last texture reached.", Toast.LENGTH_SHORT).show();
            }
        });

        btnSaveIff.setOnClickListener(v -> {
            Toast.makeText(this, "Calling Python: save_iff_bridge...", Toast.LENGTH_SHORT).show();
            // bridge.callAttr("save_iff_bridge", sessionId, fileIndex, outPath);
        });

        // When clicking a row in the embedded list, update the preview
        embeddedTextureList.setOnItemClickListener((parent, view, position, id) -> {
            currentTextureIndex = position;
            loadTexturePreview(currentTextureIndex);
        });

        popupExport.setOnClickListener(v -> {
            Toast.makeText(this, "Exporting Texture " + currentTextureIndex, Toast.LENGTH_SHORT).show();
            // bridge.callAttr("export_texture_png_bridge", sessionId, fileIndex, currentTextureIndex, outPath);
        });

        // Launch file picker to import a replacement image
        popupImport.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/png");
            startActivityForResult(intent, 300);
        });
        
        popupReplace.setOnClickListener(v -> {
            // Same as import, but maybe overwrites directly instead of staging
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/png");
            startActivityForResult(intent, 300);
        });
    }

    // 🚨 FETCH TEXTURE PREVIEW FROM PYTHON
    private void loadTexturePreview(int texIndex) {
        popupInfo.setText("Loading Texture " + (texIndex + 1) + "...");
        popupImage.setImageBitmap(null);

        new Thread(() -> {
            try {
                if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
                Python py = Python.getInstance();
                PyObject bridge = py.getModule("noclue2k_bridge");

                // Call Python to get the Base64 PNG
                PyObject result = bridge.callAttr("preview_png_bridge", sessionId, fileIndex, texIndex);
                String jsonString = result.toString();

                JSONObject json = new JSONObject(jsonString);
                if (json.getBoolean("ok")) {
                    String b64 = json.optString("image_b64", ""); // Assuming python returns 'image_b64'
                    String meta = json.optString("meta", "128x128");
                    String format = json.optString("format", "ETC2 RGBA8");
                    
                    Bitmap bmp = null;
                    if (!b64.isEmpty()) {
                        byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                        bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    }

                    Bitmap finalBmp = bmp;
                    handler.post(() -> {
                        if (finalBmp != null) popupImage.setImageBitmap(finalBmp);
                        popupInfo.setText("Texture " + (texIndex + 1) + " of " + totalTextures);
                        popupMeta.setText(meta);
                        popupFormat.setText(format);
                        popupPayload.setText("PAYLOAD OK · OFFSET 0x0");
                    });
                } else {
                    String error = json.optString("error", "No payload");
                    handler.post(() -> {
                        popupInfo.setText("Error: " + error);
                        popupFormat.setText("UNKNOWN");
                        // If your python gives specific payload info
                        popupPayload.setText("Error: " + error); 
                    });
                }
            } catch (Exception e) {
                handler.post(() -> popupInfo.setText("Python Exception: " + e.getMessage()));
            }
        }).start();
    }

    // 🚨 FETCH TEXTURE LIST FROM PYTHON
    private void loadTextureList() {
        new Thread(() -> {
            try {
                if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
                Python py = Python.getInstance();
                PyObject bridge = py.getModule("noclue2k_bridge");

                PyObject result = bridge.callAttr("session_summary_bridge", sessionId);
                JSONObject json = new JSONObject(result.toString());

                if (json.getBoolean("ok")) {
                    JSONArray texArray = json.optJSONArray("textures");
                    if (texArray != null) {
                        totalTextures = texArray.length();
                        for (int i = 0; i < totalTextures; i++) {
                            JSONObject tex = texArray.getJSONObject(i);
                            textureList.add("#" + i + " · " + tex.optString("width", "?") + "x" + tex.optString("height", "?") + " · " + tex.optString("format", "UNKNOWN"));
                        }
                    }
                }
            } catch (Exception ignored) {}

            handler.post(() -> {
                listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, textureList);
                embeddedTextureList.setAdapter(listAdapter);
                // Set the info text now that we know the total count
                popupInfo.setText("Texture " + (currentTextureIndex + 1) + " of " + totalTextures);
            });
        }).start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 300 && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            Toast.makeText(this, "Selected Image: " + imageUri.getLastPathSegment(), Toast.LENGTH_SHORT).show();
            
            // TODO: Convert URI to file path and call Python: replace_texture_bridge
            // bridge.callAttr("replace_texture_bridge", sessionId, fileIndex, currentTextureIndex, realPath);
        }
    }
}