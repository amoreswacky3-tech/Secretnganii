package com.nocluetools.prov1.roster;

import com.nocluetools.prov1.roster.RosterEditor;

/* JADX INFO: loaded from: classes.dex */
public final class AnimationCatalog {
    private static final String[] ISO_HESITATION = {"Hesitation 1", "Hesitation 2", "Hesitation 3", "Hesitation 4"};
    private static final String[] SHOT_CONTESTED = {"Default", "Big"};
    private static final String[] POST_SHIMMY = {"Default", "Big", "One Foot"};
    private static final String[] POST_PROTECT = {"Default", "Compact", "One Foot"};
    private static final String[] POST_PROTECT_SPIN = {"Default", "Compact", "Gaucho", "One Foot"};
    private static final String[] DRIBBLE_PULLUP = {"Big", "Big 2", "Bowed", "Elite", "Elite 2", "Elite 3", "Elite 4", "Elite 5", "Elite 6", "Elite 7", "Elite 8", "Elite 9", "Elite 10", "Elite 11", "Elite 12", "Normal", "Normal 2", "Normal 3", "Normal 4", "Normal 5", "Normal 6", "Normal 7", "Normal 8", "Normal 9", "Normal 10", "Normal 11", "Normal 12", "One Foot", "Stiff", "Stiff 2", "Stiff 3", "Stiff 4", "Stiff 5", "Stiff 6", "J. Akognon", "H. Barnes", "K. Bazemore", "T. Burke", "Durant", "C. Johnson", "B. Mclemore"};
    private static final String[] DUNK = {"Default", "Under Basket Rim Pulls", "Under Basket Regular", "Under Basket Athletic", "One Foot One Hand Rim Grazers", "Two Foot Two Hand Rim Grazers", "One Foot One Hand Basic", "One Foot Two Hand Basic", "Two Foot One Hand Basic", "Two Foot Two Hand Basic", "One Foot Big Man Basic", "Two Foot One Hand Big Man", "One Foot One Hand Athletic", "Two Foot One Hand Athletic", "One Foot Basic Hangs", "One Foot Big Man Basic Hangs", "Two Foot Basic Hangs", "Two Foot Athletic Hangs", "Two Foot Two Hand Quick Drops", "Two Foot Two Hand Fist Pump Rim Pulls", "One Foot Big Man Tomahawks", "Two Foot Big Man Tomahawks", "One Foot Side Arm Tomahawks", "One Foot Straight Arm Tomahawks", "One Foot Cockback Tomahawks", "Two Foot Athletic Side Tomahawks", "Two Foot Athletic Front Tomahawks", "One Foot Uber Athletic Tomahawks", "Two Foot Uber Athletic Sidetomahawks", "Two Foot Leans", "One Foot Front Double Clutch", "Two Foot Front Double Clutch", "One Foot Side Double Clutch", "One Foot Big Man Side Double Clutch", "Two Foot Side Double Clutch", "One Foot Back Scratchers", "Two Foot Back Scratchers", "Two Foot Back Scratcher Rim Hangs", "Two Foot Big Man Back Scratchers", "Quickdropinback Scratchers", "One Foot Two Hand Basic Reverses", "Two Foot One Hand Doubleclutchreverses", "Two Foot Two Hand Reverses", "One Foot Two Hand Doubleclutchreverses", "Two Foot Two Hand Doubleclutchreverses", "Two Foot Two Hand Baselinedoubleclutchreverses", "Two Foot Two Hand Windmillreverses", "One Foot Athletic Baseline 180 Reverses", "Two Foot Baseline 180 Athletic Reverses", "Two Foot One Hand Baseline 180 Windmillreverses", "Two Foot Two Hand Baseline 180 Doubleclutchreverses", "Baselinebig Man 180 Reverses", "Switcheroos", "One Foot Windmills", "Two Foot One Hand Leaningwindmills", "Two Foot One Hand Big Man Windmills", "Two Foot One Hand Front Windmills", "Two Foot One Hand Side Windmills", "Two Foot Two Hand Athletic Windmills", "Two Foot Basic 360 S", "Two Foot Athletic 360 S", "Cradles", "Historic Jordan", "Historic Drexler", "My Player Dunks", "None"};
    private static final String[] FADEAWAY = {"J. Awkward", "J. Big Kick", "J. Big Kick 2", "J. Big Kick 3", "J. Lean", "J. Small Kick", "J. Small Kick 2", "J. Small Kick 3", "J. Small Kick 4", "S. Big Kick", "S. Bowed", "S. Grounded", "S. Grounded 2", "S. Hop Back", "S. Kick", "S. Late Kick", "S. Side Hop", "S. Small Kick", "S. Small Step", "S. Tight", "K. Bryant", "K. Durant", "L. James", "W. Johnson", "S. Marion", "S. Nash", "D. Nowitzki", "P. Pierce", "D. Rose", "E. Turner", "D. Wade"};
    private static final String[] FREE_THROW = {"AO", "Badger", "Brave", "Brown", "Cal", "Cap", "Codum", "Cougar", "Crusader", "Cue", "Cyclone", "Dior", "Doc", "Downey", "Gaucho", "Generic", "Hammer", "Hawk", "Hollywood", "Hund", "Lean", "Mitty", "Pitbull", "Push Up", "Reemix", "Robin", "Round", "SIB", "Spider", "Varsky", "TP", "Warrior", "J. Akognon", "C. Aldrich", "L. Aldridge", "R. Allen", "C. Anthony", "H. Barnes", "K. Bazemore", "M. Beasley", "A. Biedrins", "C. Billups", "L. Bird", "M. Bonner", "C. Boozer", "C. Bosh", "E. Brand", "K. Bryant", "T. Burke", "V. Carter", "B. Cartwright", "W. Chamberlain", "J. Childress", "M. Conley", "J. Crawford", "S. Curry", "G. Davis", "C. Drexler", "T. Duncan", "K. Durant", "M. Ellis", "P. Ewing", "D. Fisher", "K. Garnett", "M. Gasol", "P. Gasol", "R. Gay", "P. George", "M. Ginobili", "B. Gordon", "D. Granger", "R. Hamilton", "D. Harris", "C. Hayes", "A. Horford", "J. Hornacek", "D. Howard", "A. Iguodala", "S. Jackson", "L. James", "A. Jamison", "C. Johnson", "J. Johnson", "M. Johnson", "O. Johnson", "W. Johnson", "M. Jordan", "D. Lee", "R. Lewis", "S. Livingston", "B. Lopez", "K. Love", "C. Maggette", "K. Malone", "S. Marion", "Kev Martin", "A. Mason", "B. Mclemore", "A. Mourning", "S. Nash", "Nene", "J. Noah", "D. Nowitzki", "E. Okafor", "J. Oneal", "S. Oneal", "T. Parker", "C. Paul", "P. Pierce", "T. Prince", "Z. Randolph", "J. Redick", "J. Richardson", "A. Rivers", "N. Robinson", "D. Rodman", "R. Rondo", "D. Rose", "J. Salmons", "L. Scola", "R. Sessions", "Jr Smith", "J. Smith", "J. Stockton", "R. Stuckey", "I. Thomas", "Ty Thomas", "H. Turkoglu", "E. Turner", "D. Wade", "D. Waiters", "G. Wallace", "J. West", "De Williams", "Marv Williams", "M. World Peace"};
    private static final String[] ISO_BEHINDBACK = {"Behind Back 1", "Behind Back 2", "Behind Back 3", "Behind Back 4", "Behind Back 5", "Behind Back 6", "Behind Back 7"};
    private static final String[] ISO_CROSSOVER = {"Crossover 1", "Crossover 2", "Crossover 3", "Crossover 4", "Crossover 5", "Crossover 6", "Crossover 7", "Crossover 8", "Crossover 9", "Crossover 10", "Crossover 11", "Crossover 12"};
    private static final String[] ISO_SPIN = {"Spin 1", "Spin 2", "Spin 3", "Spin 4", "Spin 5", "Spin 6", "Spin 7"};
    private static final String[] LAYUP = {"Guard", "Swing", "Big", "C. Anthony", "J. Crawford", "T. Duncan", "K. Durant", "M. Ellis", "B. Griffin", "J. Harden", "L. James", "M. Jordan", "D. Rose", "C. Paul", "R. Rondo", "D. Wade"};
    private static final String[] POST_1STEP_PULLUP = {"Normal", "Ames", "Big", "Big Smooth", "Compact", "Crusader", "Deliberate", "Gaucho", "One Foot", "Quick"};
    private static final String[] POST_HOOK = {"Normal", "Hook 1", "Hook 2", "Hook 3", "Hook 4", "Hook 5", "Hook 6", "Hook 7", "Hook 8", "Hook 9", "Hook 10", "Hook 11", "Hook 12", "Classic Sky Hook", "S. Oneal"};
    private static final String[] POST_ROLL = {"Normal", "Fade 1", "Fade 2", "Fade 3", "Fade 4", "Fade 5", "Fade 6", "Fade 7", "Fade 8", "Fade 9", "H. Barnes", "B. Cartwright", "C. Johnson", "M. Jordan", "K. Malone", "D. Nowitzki"};
    private static final String[] PREGAME_HYPE = {"Default", "Duncan Hang", "Griffin Hang", "KG Head Stanchion", "LeBron / Wade Salute", "Wade Pull-Up", "Wade Punch Out", "LeBron Face Wipe", "Generic Dribble", "Generic Punch Mitts", "Generic Boxing", "Generic Bump Jump", "Generic Bunny", "Generic Cabbage", "Generic Tebow", "Generic Foot Grab", "Generic Foot Lock", "Generic Fishing", "Generic Baseball", "Generic Charlie", "Generic Lefthang 1", "Generic Lefthang 2", "Generic Camera", "Generic Punchbag", "Generic Hang Flex", "Generic Hang Swing", "Generic Hang Tap", "Generic Robot", "Generic Salsa", "Generic Birdsign", "Generic Shoveoff", "Generic Punchsteel", "Generic Carlton", "Generic Wheelbarrow", "Generic Football", "Generic Catchbuddy"};
    private static final String[] PREGAME_PLAYER = {"Default", "Allen Powder", "Melo Inspect Ball", "Melo Shake", "Billups Inspect Ball", "Boozer Smack Table", "Boozer Take Ball", "Kobe Hug", "Kobe Powder", "V. Carter Pull-Up", "Duncan Cradle", "Durant Brush", "Durant Shake", "KG Hype Crowd", "KG Powder", "Dwight Intro", "Dwight / Nelson Shake", "LeBron Inspect Ball", "MJ Powder 1", "MJ Powder 2", "Lin Textbook", "Dirk Shake", "Dirk Socks", "Chris Paul Hug", "Wade Fans", "Wade / LeBron Shake", "Generic Backflip", "Generic Backflip 2", "Generic Show Belt", "Generic Chicken", "Generic Dunk", "Generic Dance", "Generic Baseball", "Generic Hulk", "Generic Tebow", "Generic Pushup", "Generic Bow", "Generic Robot", "Generic Salsa", "Generic Handstand", "Generic Hypecrowd Point", "Generic Hypecrowd Chestpump", "Generic Hypecrowd Clapwave", "Generic Hypecrowd Hearyou", "Generic Hypecrowd Runby", "Generic Hypecrowd Ourhouse", "Generic Powder", "Generic Powderfly", "Generic Chesttap", "Generic Powderpoint", "Generic Stanch Headbang", "Generic Stanch Drums", "Generic Stanch Monetyteam", "Generic Stanch Fastpunch", "Generic Stanch Focus", "Generic Stanch Punchkick", "Generic Stanch Lowpunch", "Generic Stanch Lean Back", "Generic Stanch Wax", "Generic Ball Dance", "Generic Ball Roundback", "Generic Ball Bowling", "Generic Ball Baseball", "Generic Ball Football", "Generic Ball Hithead", "Generic Ball Scratch", "Generic Ball Weight"};
    private static final String[] PREGAME_STADIUM = {"Default", "Anthem LeBron", "Anthem Wade", "Generic Huddle Dance 1", "Generic Huddle Dance 5", "Generic Huddle Dance 3", "Generic Huddle Dance 4", "Generic Huddle Dance 2", "Generic Huddle Lineup Dance 2", "Generic Huddle Lineup Dance 3", "Generic Huddle Lineup Dance 7", "Generic Huddle Lineup Dance 9", "Generic Huddle Lineup Dance 4", "Generic Huddle Lineup Dance 10", "Generic Huddle Lineup Dance 5", "Generic Huddle Lineup Dance 8", "Generic Huddle Lineup Dance 6", "Generic Huddle Lineup Dance 1", "Generic Trick Shot 3", "Generic Trick Shot 1", "Generic Trick Shot 5", "Generic Trick Shot 6", "Generic Trick Shot 4", "Generic Trick Shot 7", "Generic Trick Shot 2", "Generic Unlock 1", "Generic Unlock 2", "Generic Unlock 3"};
    private static final String[] SHOT_JUMPER = {"Jump Shot 1", "Jump Shot 2", "Jump Shot 3", "Jump Shot 4", "Jump Shot 5", "Jump Shot 6", "Jump Shot 7", "Jump Shot 8", "Jump Shot 9", "Jump Shot 10", "Jump Shot 11", "Jump Shot 12", "Jump Shot 13", "Jump Shot 14", "Jump Shot 15", "Jump Shot 16", "Jump Shot 17", "Jump Shot 18", "Jump Shot 19", "Jump Shot 20", "Jump Shot 21", "Jump Shot 22", "Jump Shot 23", "Jump Shot 24", "Jump Shot 25", "Jump Shot 26", "Jump Shot 27", "Jump Shot 28", "Jump Shot 29", "Jump Shot 30", "Jump Shot 31", "Jump Shot 32", "Jump Shot 33", "Jump Shot 34", "Jump Shot 35", "Jump Shot 36", "Jump Shot 37", "Jump Shot 38", "Jump Shot 39", "Jump Shot 40", "Jump Shot 41", "Jump Shot 42", "Jump Shot 43", "Jump Shot 44", "Jump Shot 45", "Jump Shot 46", "Jump Shot 47", "Jump Shot 48", "Jump Shot 49", "Set Shot 1", "Set Shot 2", "Set Shot 3", "Set Shot 4", "Set Shot 5", "Set Shot 6", "Set Shot 7", "Set Shot 8", "Set Shot 9", "Set Shot 10", "Set Shot 11", "Set Shot 12", "Set Shot 13", "Set Shot 14", "Set Shot 15", "Set Shot 16", "Set Shot 17", "Set Shot 18", "Set Shot 19", "J. Akognon", "L. Aldridge", "R. Allen", "R. Anderson", "C. Anthony", "A. Bargnani", "H. Barnes", "D. Barnett", "K. Bazemore", "M. Beasley", "C. Billups", "L. Bird", "A. Bogut", "M. Bonner", "C. Boozer", "C. Bosh", "K. Bryant", "T. Burke", "M. Camby", "V. Carter", "S. Curry", "K. Duckworth", "T. Duncan", "K. Durant", "M. Ellis", "T. Evans", "P. Ewing", "D. Gallinari", "K. Garnett", "P. Gasol", "R. Gay", "P. George", "M. Ginobili", "D. Granger", "B. Griffin", "J. Harden", "D. Howard", "A. Iguodala", "K. Irving", "L. James", "C. Johnson", "J. Johnson", "M. Johnson", "M. Jordan", "J. Kidd", "B. Laimbeer", "D. Lee", "D. Lillard", "B. Lopez", "K. Love", "K. Malone", "K. Martin", "B. Mclemore", "S. Nash", "D. Nowitzki", "S. Oneal", "C. Oakley", "T. Parker", "C. Paul", "K. Perkins", "P. Pierce", "Z. Randolph", "A. Rivers", "O. Robertson", "D. Robinson", "D. Rose", "J. Smith", "J. Stockton", "A. Stoudemire", "D. Wade", "D. Waiters", "K. Walker", "J. Wall", "G. Wallace", "J. West", "R. Westbrook", "D. Williams"};
    private static final String[] SHOT_RELEASE = {"Release 1", "Release 2", "Release 3", "Release 4", "Release 5", "Release 6", "Release 7", "Release 8", "Release 9", "Release 10", "Release 11", "Release 12", "Release 13", "Release 14", "Release 15", "Release 16", "Release 17", "Release 18", "Release 19", "Release 20", "Release 21", "Release 22", "Release 23", "Release 24", "Release 25", "Release 26", "Release 27", "Release 28", "Release 29", "Release 30", "Release 31", "Release 32", "Release 33", "Release 34", "Release 35", "Release 36", "Release 37", "Release 38", "Release 39", "Release 40", "Release 41", "Release 42", "Release 43", "Release 44", "Release 45", "Release 46", "Release 47", "Release 48", "Release 49", "Release 50", "Release 51", "Release 52", "Release 53", "Release 54", "Release 55", "Release 56", "Release 57", "Release 58", "Release 59", "Release 60", "Release 61", "Release 62", "Release 63", "Release 64", "Release 65", "Release 66", "Release 67", "Release 68", "Release 69", "Release 70", "Release 71", "Release 72", "Release 73", "Release 74", "Release 75", "Release 76", "Release 77", "Release 78", "Release 79", "Release 80", "Release 81", "Release 82", "Release 83", "Release 84", "Release 85", "Release 86", "Release 87", "Release 88", "Release 89", "Release 90", "Release 91", "Release 92", "J. Akognon", "L. Aldridge", "R. Allen", "R. Anderson", "C. Anthony", "A. Bargnani", "H. Barnes", "D. Barnett", "K. Bazemore", "M. Beasley", "C. Billups", "L. Bird", "A. Bogut", "M. Bonner", "C. Boozer", "C. Bosh", "K. Bryant", "T. Burke", "M. Camby", "V. Carter", "S. Curry", "K. Duckworth", "T. Duncan", "K. Durant", "M. Ellis", "T. Evans", "P. Ewing", "D. Gallinari", "K. Garnett", "P. Gasol", "R. Gay", "P. George", "M. Ginobili", "D. Granger", "B. Griffin", "J. Harden", "D. Howard", "A. Iguodala", "K. Irving", "L. James", "C. Johnson", "J. Johnson", "M. Johnson", "M. Jordan", "J. Kidd", "B. Laimbeer", "D. Lee", "D. Lillard", "B. Lopez", "K. Love", "K. Malone", "K. Martin", "B. Mclemore", "S. Nash", "D. Nowitzki", "S. Oneal", "C. Oakley", "T. Parker", "C. Paul", "K. Perkins", "P. Pierce", "Z. Randolph", "A. Rivers", "O. Robertson", "D. Robinson", "D. Rose", "J. Smith", "J. Stockton", "A. Stoudemire", "D. Wade", "D. Waiters", "K. Walker", "J. Wall", "G. Wallace", "J. West", "R. Westbrook", "D. Williams"};
    private static final String[] SIDE_HOP = {"Big", "Big 2", "Normal", "Normal 2", "Normal 3", "Normal 4", "Normal 5", "Normal 6", "Normal 7", "Normal 8", "Normal 9", "Normal 10", "Normal 11", "Normal 12", "Normal 13", "Normal 14", "Normal 15", "One Foot", "Stiff", "Quick", "H. Barnes", "K. Bazemore", "T. Burke", "B. Mclemore"};

    AnimationCatalog() {
    }

    public static boolean usesNativeNames(RosterEditor.AnimationField animationField) {
        return nativeNames(animationField) != null;
    }

    private static String[] nativeNames(RosterEditor.AnimationField animationField) {
        if (animationField == null) {
            return (String[]) null;
        }
        switch (animationField.serializedBit) {
            case 1906:
                break;
            case 1914:
                break;
            case 1922:
                break;
            case 1930:
                break;
            case 1938:
                break;
            case 1946:
                break;
            case 1954:
                break;
            case 1962:
                break;
            case 1970:
                break;
            case 1978:
                break;
            case 1986:
                break;
            case 1994:
                break;
            case 2002:
                break;
            case 2010:
                break;
            case 2018:
                break;
            case 2026:
                break;
            case 2034:
                break;
            case 2042:
                break;
            case 2050:
                break;
            case 2053:
                break;
            case 2074:
                break;
            case 2078:
                break;
            case 2081:
                break;
            case 2101:
                break;
            case 2105:
                break;
            case 2114:
                break;
            case 2120:
                break;
            case 2126:
                break;
            case 2130:
                break;
            case 2135:
                break;
            case 2140:
                break;
            case 2155:
                break;
            case 2828:
                break;
            case 2994:
                break;
            case 3001:
                break;
            case 3026:
                break;
            case 3032:
                break;
            case 3110:
                break;
        }
        return (String[]) null;
    }

    public static String[] optionsFor(RosterEditor.AnimationField animationField) {
        int iMaxValue = animationField.maxValue();
        String[] strArrNativeNames = nativeNames(animationField);
        String[] strArr = new String[iMaxValue + 1];
        for (int i = 0; i <= iMaxValue; i++) {
            if (strArrNativeNames != null && i < strArrNativeNames.length && strArrNativeNames[i] != null && strArrNativeNames[i].length() > 0) {
                strArr[i] = strArrNativeNames[i];
            } else {
                strArr[i] = new StringBuffer().append("Unknown / unmapped  •  ID ").append(i).toString();
            }
        }
        return strArr;
    }

    public static String displayName(RosterEditor.AnimationField animationField, int i) {
        if (animationField == null || i < 0 || i > animationField.maxValue()) {
            return new StringBuffer().append("ID ").append(i).toString();
        }
        String[] strArrNativeNames = nativeNames(animationField);
        if (strArrNativeNames != null && i < strArrNativeNames.length && strArrNativeNames[i] != null && strArrNativeNames[i].length() > 0) {
            return new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(strArrNativeNames[i]).append(" (ID ").toString()).append(i).toString()).append(")").toString();
        }
        return new StringBuffer().append(new StringBuffer().append("Unknown / unmapped (ID ").append(i).toString()).append(")").toString();
    }
}
