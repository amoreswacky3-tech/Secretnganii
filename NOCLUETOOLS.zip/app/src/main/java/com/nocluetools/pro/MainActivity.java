package com.nocluetools.prov1;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {

    TextView tvStatus;
    TextView tvLog;
    ScrollView scrollLog;
    Button btnOpenObb, btnOpenIff;
    ListView listObbContents;
    Python py;
    PyObject bridge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Link UI elements
        tvStatus = findViewById(R.id.tvStatus);
        tvLog = findViewById(R.id.tvLog);
        scrollLog = (ScrollView) tvLog.getParent();
        btnOpenObb = findViewById(R.id.btnOpenObb);
        btnOpenIff = findViewById(R.id.btnOpenIff);
        listObbContents = findViewById(R.id.listObbContents);

        // 1. Start Python Engine
        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }
        py = Python.getInstance();
        bridge = py.getModule("noclue2k");
        log("Python Engine Initialized.");

        // 2. Button Click Listeners
        btnOpenObb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                log("Calling Python: open_obb_bridge...");
                try {
                    // We are just passing a dummy path to see if the bridge responds
                    String dummyPath = "/storage/emulated/0/Android/obb/com.t2ksports.nba2k20and/main.98.com.t2ksports.nba2k20and.obb";
                    String dummyWorkDir = getCacheDir().getAbsolutePath();

                    // Call the Python function
                    PyObject result = bridge.callAttr("open_obb_bridge", dummyPath, dummyWorkDir);
                    String jsonResponse = result.toString();
                    
                    log("RESPONSE:\n" + jsonResponse);
                    tvStatus.setText("Status: OBB Opened");

                    // Fake list update to show it works
                    updateList(new String[]{"File 1.iff", "File 2.iff", "File 3.iff"});

                } catch (Exception e) {
                    log("ERROR: " + e.getMessage());
                }
            }
        });

        btnOpenIff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                log("Calling Python: open_iff_bridge...");
                try {
                    String dummyPath = "/storage/emulated/0/test.iff";
                    PyObject result = bridge.callAttr("open_iff_bridge", dummyPath);
                    String jsonResponse = result.toString();
                    
                    log("RESPONSE:\n" + jsonResponse);
                    tvStatus.setText("Status: IFF Opened");
                } catch (Exception e) {
                    log("ERROR: " + e.getMessage());
                }
            }
        });
    }

    // Helper to write to the on-screen log
    private void log(String message) {
        tvLog.append("\n> " + message);
        // Auto-scroll to bottom
        scrollLog.post(new Runnable() {
            @Override
            public void run() {
                scrollLog.fullScroll(View.FOCUS_DOWN);
            }
        });
    }

    // Helper to update the list
    private void updateList(String[] items) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        listObbContents.setAdapter(adapter);
    }
}