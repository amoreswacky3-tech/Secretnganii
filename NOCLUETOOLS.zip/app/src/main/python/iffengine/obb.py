"""iffengine.obb - read and rebuild NBA 2K16 / 2K20 Android OBB containers.

The games use a hash-indexed 2K container (not ZIP/JOBB): a fixed header, a
record table, and block-aligned entries whose payloads are wrapped in ZLIB
blocks.  This module mirrors the desktop ``obb_tools`` package (nba2k20_obb /
obb_encrypt / direct_obb) using only the standard library, so the same
extract -> modify -> rebuild workflow runs on Android through Chaquopy.

Both NBA 2K16 and NBA 2K20 share the magic, 2048-byte alignment, the
crc32-hashed entry names, the ZLIB block wrapper and the archive checksum
algorithm; they differ only in the header layout of the record table:

* 2K20 - count at +0x18, total blocks at +0x28, checksum at +0x38, table at
  +0xF8 with 16-byte ``(length u32, reserved u32, name_hash u32, block u32)``
  records.
* 2K16 - count at +0x10, total blocks at +0x18, checksum at +0x20, table at
  +0xE0 with 16-byte ``(length u64, name_hash u32, block u32)`` records.

The format is auto-detected from the container header, so the same open ->
list -> extract -> edit -> rebuild workflow works for both games.

Read side
---------
``Obb`` parses the record table and decompresses any ZLIB/compressed entry.

Write side
----------
``stage_iff`` + ``rebuild_obb`` implement the desktop "direct OBB" flow:
edited IFFs are re-encoded into their original entry containers and staged,
then a full copy of the source OBB is produced with only the staged entries
changed (in place when they fit, appended otherwise), the game archive CRC32
is recomputed, and the output is verified before it is returned.
"""

from __future__ import annotations
import dataclasses
import hashlib
import os
import shutil
import struct
import zlib
from pathlib import Path
from typing import BinaryIO, Iterator
import csv

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# Go up one folder (out of iffengine) to find the CSV next to noclue2k_bridge.py
CSV_PATH = os.path.join(os.path.dirname(BASE_DIR), 'nba2k20_names.csv')

IFF_NAME_MAP = {}

def load_iff_names():
    global IFF_NAME_MAP
    try:
        with open(CSV_PATH, mode='r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                hash_name = row['name_hash'].strip().upper()
                real_name = row['filename'].strip()
                if hash_name and real_name:
                    IFF_NAME_MAP[hash_name] = real_name
    except Exception as e:
        print(f"ERROR loading CSV in obb.py: {e}")

load_iff_names()

def get_real_filename(hash_string):
    if not hash_string:
        return "Unknown"
    clean_hash = str(hash_string).strip().upper()
    return IFF_NAME_MAP.get(clean_hash, hash_string)
# 🚨 CSV NAME RESOLVER END 🚨

MAGIC = b"\xbf\xb3\x00\xaa"
ALIGNMENT = 2048
MAX_ENTRIES = 5000000
COPY_CHUNK = 16777216
FORMAT_2K20 = "2k20"
FORMAT_2K16 = "2k16"
@dataclasses.dataclass(frozen=True)
class ContainerFormat:
    """Header layout of one 2K container flavour (2K16 vs 2K20)."""
    name: str
    count_offset: int
    total_blocks_offset: int
    checksum_offset: int
    table_offset: int
    record: struct.Struct
    descriptor_base: int
    descriptor_stride: int
    descriptor_position_delta: int
    descriptor_stored_delta: int
    header_length_offset: int
    header_length_byteorder: str

FORMATS = {
    FORMAT_2K20: ContainerFormat(name=FORMAT_2K20, count_offset=24, total_blocks_offset=40, checksum_offset=56, table_offset=248, record=struct.Struct("<IIII"), descriptor_base=44, descriptor_stride=56, descriptor_position_delta=36, descriptor_stored_delta=44, header_length_offset=8, header_length_byteorder=">"),
    FORMAT_2K16: ContainerFormat(name=FORMAT_2K16, count_offset=16, total_blocks_offset=24, checksum_offset=32, table_offset=224, record=struct.Struct("<QII"), descriptor_base=44, descriptor_stride=32, descriptor_position_delta=8, descriptor_stored_delta=12, header_length_offset=8, header_length_byteorder="<"),
}


def _table_plausible(stream: BinaryIO, fmt: ContainerFormat, size: int) -> bool:
    """True when ``fmt``'s record table at least looks like a 2K table."""
    count = _read_u64le(stream, fmt.count_offset)
    if not 1 <= count <= MAX_ENTRIES:
        return False
    stream.seek(fmt.table_offset)
    table = stream.read(fmt.record.size * min(count, 8))
    for index in range(len(table) // fmt.record.size):
        fields = fmt.record.unpack_from(table, index * fmt.record.size)
        if fields[0] > 8589934592:
            return False
        if fields[-1] * ALIGNMENT >= size:
            return False
    return True


def _detect_format(stream: BinaryIO, size: int) -> ContainerFormat:
    """Identify the container flavour from its header."""
    candidates = []
    for fmt in (FORMATS[FORMAT_2K16], FORMATS[FORMAT_2K20]):
        blocks = _read_u64le(stream, fmt.total_blocks_offset)
        count = _read_u64le(stream, fmt.count_offset)
        if blocks * ALIGNMENT == size and 1 <= count <= MAX_ENTRIES:
            candidates.append(fmt)
    for fmt in candidates:
        if _table_plausible(stream, fmt, size):
            return fmt
    for fmt in (FORMATS[FORMAT_2K16], FORMATS[FORMAT_2K20]):
        if _table_plausible(stream, fmt, size):
            return fmt
    raise ValueError("not a supported NBA 2K OBB (2K16/2K20) container: unrecognized header")


TYPE_COMPRESSED = b"\x94\xef;\xff"
TYPE_ZLIB = b"ZLIB"
TYPE_CDF = b"0P\x98\xf0"
TYPE_DRAM = b"\xdf\x85\xc5\xce"
TYPE_FILELIST = b"\x07\x12y\xe4"

TYPE_NAMES = {
    TYPE_COMPRESSED: "compressed",
    TYPE_ZLIB: "zlib-image",
    TYPE_CDF: "cdf",
    TYPE_DRAM: "dram",
    TYPE_FILELIST: "filelist",
    b"OggS": "ogg",
}

EDITABLE_TYPES = (TYPE_COMPRESSED, TYPE_ZLIB)

KNOWN_NAMES = (
    "TITLEPAGE.IFF",
    "LOADINGFLOWSTATIC.IFF",
    "ENGLISHBOOTUP.IFF",
    "FRONTEND_SYNC.IFF",
    "GOOEYFRONTEND.IFF",
    "GLOBAL.IFF",
    "LOGOS_LARGE.CDF",
    "LOGOS_MEDIUM.CDF",
    "LOGOS_SMALL.CDF",
    "LOGOS_TINY.CDF",
    "PORTRAIT.CDF",
    *(f"""F{index:03d}.IFF""" for index in range(1000)),
    *(f"""LOGO{index:03d}.IFF""" for index in range(32)),
    *(f"""UH{index:03d}.IFF""" for index in range(32)),
    *(f"""UA{index:03d}.IFF""" for index in range(32)),
)

NAME_BY_HASH = {zlib.crc32(name.encode("ascii")): name for name in KNOWN_NAMES}
NAME_BY_HASH[3110144684] = "PORTRAIT.CDF"
_NAME_PATTERNS: tuple[tuple[str, int, str, str], ...] = (("PNG", 4, "cyberface", "face_scene"), ("UH", 3, "uniform", "home"), ("UA", 3, "uniform", "away"), ("UX", 3, "uniform", "alternate"), ("UHX", 3, "uniform", "home_alt"), ("UAX", 3, "uniform", "away_alt"), ("UAY", 3, "uniform", "alt"), ("LOGO", 3, "logo", "team_logo"), ("S", 3, "shader", "shader_bank"), ("F", 3, "court", "floor"), ("team", 5, "data", "team_table"), ("FACE", 5, "data", "face_table"), ("TATTOO", 5, "data", "tattoo_table"))
_NAME_PATTERNS = _NAME_PATTERNS + tuple(((f"""R{digit}{side}""", 3, "uniform", f"""retro_{side.lower()}""") for digit in range(10) for side in ("H", "A")))
_NAME_RANGES: dict[str, int] = {"PNG": 20000, "UH": 2000, "UA": 2000, "UX": 2000, "UHX": 2000, "UAX": 2000, "UAY": 2000, "LOGO": 2000, "S": 1000, "F": 1000, "team": 20000, "FACE": 10000, "TATTOO": 20000}
for _digit in range(10):
    _NAME_RANGES[f"""R{_digit}H"""] = 2000
    _NAME_RANGES[f"""R{_digit}A"""] = 2000

_NAME_BY_HASH: dict[int, tuple[str, str, str, int]] | None = None


def _name_map() -> dict[int, tuple[str, str, str, int]]:
    """Build (crc32 -> (name, category, subcategory, id)) for every pattern."""
    global _NAME_BY_HASH
    if _NAME_BY_HASH is None:
        built = {}
        for prefix, width, category, subcategory in _NAME_PATTERNS:
            for index in range(_NAME_RANGES[prefix]):
                name = f"""{prefix}{index:0{width}d}.IFF"""
                built[zlib.crc32(name.encode("ascii"))] = (name, category, subcategory, index)
        _NAME_BY_HASH = built
    return _NAME_BY_HASH


def resolved_name(name_hash: int) -> tuple[str, str, str, int] | None:
    """Return (name, category, subcategory, id) for a hash, or None."""
    resolved = _name_map().get(name_hash)
    if resolved is not None:
        return resolved
    from .nameresolver_seb import seb_resolved_name
    return seb_resolved_name(name_hash)


def asset_category(name_hash: int) -> tuple[str, str, int] | None:
    """Return (category, subcategory, id) for a hash, or None."""
    resolved = resolved_name(name_hash)
    if resolved is None:
        return None
    return (resolved[1], resolved[2], resolved[3])


def cyberface_name(name_hash: int) -> str | None:
    """Return the PNG####.IFF scene name for a hash, or None."""
    resolved = resolved_name(name_hash)
    if resolved is None or resolved[1] != "cyberface":
        return None
    return resolved[0]


def entry_name(name_hash: int) -> str:
    """Return the known game name for a hash, or an ``hhhhhhhh`` fallback."""
    resolved = resolved_name(name_hash)
    if resolved is not None:
        return resolved[0]
    return NAME_BY_HASH.get(name_hash) or f"""{name_hash:08x}"""


TEAM_NAMES: dict[int, str] = {0: "Philadelphia 76ers", 1: "Milwaukee Bucks", 2: "Washington Wizards", 3: "Chicago Bulls", 4: "Cleveland Cavaliers", 5: "Boston Celtics", 6: "Los Angeles Clippers", 7: "East All-Stars", 8: "Memphis Grizzlies", 9: "Atlanta Hawks", 10: "Miami Heat", 11: "New Orleans Pelicans", 12: "Utah Jazz", 13: "Sacramento Kings", 14: "New York Knicks", 15: "Los Angeles Lakers", 16: "Orlando Magic", 17: "Dallas Mavericks", 18: "Brooklyn Nets", 19: "Denver Nuggets", 20: "Indiana Pacers", 21: "Detroit Pistons", 22: "Toronto Raptors", 23: "Houston Rockets", 24: "Oklahoma City Thunder", 25: "San Antonio Spurs", 26: "Phoenix Suns", 27: "Minnesota Timberwolves", 28: "Portland Trail Blazers", 29: "Golden State Warriors", 30: "West All-Stars", 31: "Charlotte Bobcats", 70: "Alba Berlin", 71: "Anadolu Efes Istanbul", 72: "Laboral Kutxa Vitoria", 73: "CSKA Moscow", 74: "EA7 Emporio Armani Milan", 75: "FC Barcelona", 76: "Fenerbahce Ulker Istanbul", 77: "Maccabi Electra Tel Aviv", 78: "Montepaschi Siena", 79: "Olympiacos Piraeus", 80: "Panathinaikos Athens", 81: "Real Madrid", 82: "Unicaja Malaga", 83: "Zalgiris Kaunas", 504: "Stars (Rookie/Sophomore)", 505: "Elites (Rookie/Sophomore)", 551: "1986 Chicago Bulls", 552: "1986 Boston Celtics", 555: "1990 Cleveland Cavaliers", 557: "1991 Los Angeles Lakers", 560: "1995 New York Knicks", 561: "1996 Chicago Bulls", 562: "1996 Seattle SuperSonics", 565: "1998 Chicago Bulls", 566: "1998 Utah Jazz", 567: "1991 Chicago Bulls", 569: "1965 Boston Celtics", 570: "1965 Los Angeles Lakers", 571: "1971 Milwaukee Bucks", 572: "1971 Los Angeles Lakers", 573: "1972 Los Angeles Lakers", 574: "1972 New York Knicks", 575: "1985 Philadelphia 76ers", 576: "1985 Milwaukee Bucks", 577: "1986 Atlanta Hawks", 578: "1987 Los Angeles Lakers", 579: "1989 Detroit Pistons", 580: "1989 Chicago Bulls", 582: "1991 Portland Trail Blazers", 583: "1991 Golden State Warriors", 584: "1993 Chicago Bulls", 585: "1971 Atlanta Hawks", 586: "1993 Charlotte Hornets", 588: "1994 Denver Nuggets", 589: "1994 Houston Rockets", 590: "1995 Orlando Magic", 591: "1998 Los Angeles Lakers", 592: "1998 San Antonio Spurs", 594: "1977 Philadelphia 76ers", 595: "2001 Philadelphia 76ers", 602: "Ballerz (Blacktop)", 603: "Ringers (Blacktop)", 604: "Rucker Park (Day)", 605: "Stars (MyCareer)", 611: "Rucker Park (Night)", 614: "Blacktop Court (Roof)", 729: "Practice Gym", 730: "Under Armour Gym", 735: "Summer Circuit Gym", 800: "Created Team"}
JERSEY_LABELS: dict[str, str] = {"home": "Home Jersey", "away": "Away Jersey", "alternate": "Alternate Jersey", "home_alt": "Additional Home Alternate Jersey", "away_alt": "Additional Away Alternate Jersey", "alt": "Additional Alternate Jersey", "retro_h": "Retro Home Jersey", "retro_a": "Retro Away Jersey"}
KNOWN_FILE_LABELS: dict[str, str] = {"GLOBAL.IFF": "Global Game Assets", "GLOBAL2.IFF": "Global Game Assets (Part 2)", "GAMEDATA.IFF": "Game Data Assets", "GAMEDATAEXTRA.IFF": "Additional Game Data Assets", "ENGLISH.IFF": "English Language/Menu Assets", "ENGLISHBOOTUP.IFF": "English Boot-Up Assets", "TITLEPAGE.IFF": "Title Screen Art", "LOADINGFLOWSTATIC.IFF": "Loading Screen Art", "GOOEYFRONTEND.IFF": "Front-End Menu Assets", "FRONTEND_SYNC.IFF": "Front-End Sync Assets", "NBABALL.IFF": "NBA Basketball", "EUROBALL.IFF": "Euroleague Basketball", "BLACKBALL.IFF": "Blacktop Basketball", "NEWSCOREBUG.IFF": "Scoreboard Overlay", "LOGOS_LARGE.CDF": "Team Logos — Large", "LOGOS_MEDIUM.CDF": "Team Logos — Medium", "LOGOS_SMALL.CDF": "Team Logos — Small", "LOGOS_TINY.CDF": "Team Logos — Tiny", "PORTRAIT.CDF": "Player Portraits"}
try:
    from . import cyberfacenames as _cfnames
    _CYBERFACE_NAMES = _cfnames.CYBERFACE_NAMES
except Exception:
    _CYBERFACE_NAMES = {}


def display_label(name_hash: int) -> str:
    """Readable description for a hash, or '' when nothing is recognized.

    Display-only: the returned label never renames the entry or alters the
    container; it is meant to sit alongside the original filename in the UI.
    """
    resolved = resolved_name(name_hash)
    if resolved is not None:
        _name, category, subcategory, ident = resolved
        team = TEAM_NAMES.get(ident)
        if category == "uniform":
            if subcategory in ("home", "away") and 100 <= ident <= 199:
                jersey = "Practice Jersey"
            else:
                jersey = JERSEY_LABELS.get(subcategory, "Jersey")
            return f"""{team} — {jersey}""" if team else f"""{jersey} (Team ID {ident:03d})"""

        if category == "cyberface":
            player = _CYBERFACE_NAMES.get(ident)
            if player:
                return f"""Cyberface — Player ID {ident:04d} — {player}"""
            return f"""Cyberface — Player ID {ident:04d}"""

        if category == "logo":
            return f"""{team} — Team Logo""" if team else f"""Team Logo (ID {ident:03d})"""

        if category == "court":
            return f"""{team} — Court/Floor""" if team else f"""Court/Floor {ident:03d}"""

        if category == "shader":
            return f"""Shader Bank {ident:03d}"""

        if category == "data":
            return {"team_table": f"""Team Data Table {ident:05d}""", "face_table": "Face Data Table", "tattoo_table": "Tattoo Data Table"}.get(subcategory, "Data Table")
        return ""
    known = NAME_BY_HASH.get(name_hash)
    if known is not None:
        return KNOWN_FILE_LABELS.get(known.upper(), "")
    return ""


@dataclasses.dataclass(frozen=True)
class Entry:
    index: int
    name_hash: int
    block: int
    length: int
    reserved: int

    @property
    def offset(self) -> int:
        return self.block * ALIGNMENT


class Obb:
    """Parse a 2K container and decompress its entries."""

    def __init__(self, path: Path):
        self.path = path
        with path.open("rb") as stream:
            if stream.read(4) != MAGIC:
                raise ValueError(f"{path} does not have the NBA 2K OBB magic")
            if _read_u32le(stream, 4) != ALIGNMENT:
                raise ValueError(f"{path} does not use {ALIGNMENT}-byte blocks")
            archive_count = _read_u64le(stream, 8)
            if archive_count != 1:
                raise ValueError(f"unsupported embedded archive count: {archive_count}")
            fmt = _detect_format(stream, path.stat().st_size)
            count = _read_u64le(stream, fmt.count_offset)
            stream.seek(fmt.table_offset)
            entries = []
            for index in range(count):
                fields = fmt.record.unpack(_read_exact(stream, fmt.record.size))
                if fmt.name == FORMAT_2K16:
                    length, name_hash, block = fields
                    reserved = 0
                else:
                    length, reserved, name_hash, block = fields
                entries.append(Entry(index, name_hash, block, length, reserved))
        self.entries = entries
        self.format = fmt
        archive_size = path.stat().st_size
        self._invalid_indices = set()
        valid_offsets = set()
        for entry in entries:
            entry_ok = (0 <= entry.offset < archive_size and entry.length >= 0 and entry.offset + entry.length <= archive_size)
            if entry_ok:
                valid_offsets.add(entry.offset)
            else:
                self._invalid_indices.add(entry.index)
        sorted_valid = sorted(valid_offsets)
        self._next_offsets = {offset: sorted_valid[position + 1] if position + 1 < len(sorted_valid) else archive_size for position, offset in enumerate(sorted_valid)}

    def is_valid_entry(self, entry: Entry) -> bool:
        """Return True when the entry's offset and length are within the archive."""
        return entry.index not in self._invalid_indices

    def stored_size(self, entry: Entry) -> int:
        """Physical span assigned to an entry, including alignment padding."""
        if not self.is_valid_entry(entry):
            return 0
        return self._next_offsets.get(entry.offset, 0)

    def type_bytes(self, stream: BinaryIO, entry: Entry) -> bytes:
        stream.seek(entry.offset)
        return _read_exact(stream, 4)

    def type_name(self, entry: Entry) -> str:
        with self.path.open("rb") as stream:
            marker = self.type_bytes(stream, entry)
        return TYPE_NAMES.get(marker, marker.hex())

    def is_editable(self, entry: Entry) -> bool:
        with self.path.open("rb") as stream:
            return self.type_bytes(stream, entry) in EDITABLE_TYPES

    def decompressed_chunks(self, stream: BinaryIO, entry: Entry) -> Iterator[bytes]:
        stream.seek(entry.offset)
        entry_type = _read_exact(stream, 4)
        if entry_type == TYPE_COMPRESSED:
            relative_offset = struct.unpack("<I", _read_exact(stream, 4))[0]
            if relative_offset < 8 or relative_offset >= self.stored_size(entry):
                raise ValueError(f"""entry {entry.index} has invalid payload offset {relative_offset}""")
            position = entry.offset + relative_offset
        elif entry_type == TYPE_ZLIB:
            position = entry.offset
        else:
            raise ValueError(f"""entry {entry.index} is not ZLIB-wrapped ({entry_type.hex()})""")
        end = entry.offset + self.stored_size(entry)
        block_number = 0
        while position + 16 <= end:
            stream.seek(position)
            if stream.read(4) != TYPE_ZLIB:
                break
            unpacked_size, stored_size, _flags = struct.unpack(">III", _read_exact(stream, 12))
            packed_size = stored_size - 16
            if packed_size <= 0 or position + stored_size > end:
                raise ValueError(f"""entry {entry.index} block {block_number} has invalid stored size {stored_size}""")
            packed = _read_exact(stream, packed_size)
            unpacked = zlib.decompress(packed)
            if len(unpacked) != unpacked_size:
                raise ValueError(f"""entry {entry.index} block {block_number}: expected {unpacked_size} bytes, got {len(unpacked)}""")
            yield unpacked
            position += stored_size
            block_number += 1
        if block_number == 0:
            raise ValueError(f"""entry {entry.index} contains no ZLIB blocks""")

    def decompressed_bytes(self, entry: Entry) -> bytes:
        output = bytearray()
        with self.path.open("rb") as stream:
            for chunk in self.decompressed_chunks(stream, entry):
                output.extend(chunk)
        return bytes(output)

    def read_entry_raw(self, entry: Entry) -> bytes:
        """Read the entry's exact stored payload (compressed container bytes)."""
        with self.path.open("rb") as stream:
            stream.seek(entry.offset)
            raw = stream.read(entry.length)
        if len(raw) != entry.length:
            raise EOFError(f"OBB entry {entry.index} is truncated: expected {entry.length}, got {len(raw)}")
        return raw

    def copy_entry_raw(self, entry: Entry, destination: Path) -> int:
        """Stream the entry's exact stored payload to ``destination``.

        Unlike ``read_entry_raw`` this never holds the whole entry in memory,
        so exporting very large containers (GLOBAL.IFF, 60 MB+ texture images)
        stays bounded on low-memory Android devices.  The bytes are written to
        a ``.partial`` sibling first and atomically renamed, so a crash or a
        short write can never leave a truncated file at the destination.
        """
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_suffix(destination.suffix + ".partial")
        written = 0
        try:
            with self.path.open("rb") as source, temporary.open("wb") as output:
                source.seek(entry.offset)
                remaining = entry.length
                while remaining > 0:
                    chunk = source.read(min(COPY_CHUNK, remaining))
                    if not chunk:
                        raise EOFError(f"OBB entry {entry.index} is truncated: expected {entry.length} bytes, got {written}")
                    output.write(chunk)
                    written += len(chunk)
                    remaining -= len(chunk)
            if written != entry.length:
                raise EOFError(f"OBB entry {entry.index} wrote {written} of {entry.length} bytes")
            os.replace(temporary, destination)
        finally:
            temporary.unlink(missing_ok=True)
        return written

    def extract_iff(self, entry: Entry, destination: Path) -> int:
        """Write the fully decompressed IFF bytes to ``destination``."""
        destination.parent.mkdir(parents=True, exist_ok=True)
        written = 0
        with self.path.open("rb") as source, destination.open("wb") as output:
            for chunk in self.decompressed_chunks(source, entry):
                output.write(chunk)
                written += len(chunk)
        return written


def _read_exact(stream: BinaryIO, size: int) -> bytes:
    data = stream.read(size)
    if len(data) != size:
        raise EOFError(f"""expected {size} bytes, got {len(data)}""")
    return data


def _read_u32le(stream: BinaryIO, offset: int) -> int:
    stream.seek(offset)
    return struct.unpack("<I", _read_exact(stream, 4))[0]


def _read_u64le(stream: BinaryIO, offset: int) -> int:
    stream.seek(offset)
    return struct.unpack("<Q", _read_exact(stream, 8))[0]


@dataclasses.dataclass
class Block:
    position: int
    unpacked_size: int
    stored_size: int
    flags: int
    original_sha256: bytes


@dataclasses.dataclass
class StagedEntry:
    index: int
    label: str
    raw_path: Path
    raw_size: int
    decompressed_size: int
    decompressed_sha256: str


@dataclasses.dataclass
class BuiltEntry:
    name: str
    index: int
    offset: int
    slot_size: int
    data: bytes
    expected_sha256: str
    expected_size: int
    is_zlib: bool
    mode: str


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(COPY_CHUNK):
            digest.update(chunk)
    return digest.hexdigest().upper()


def compress_zlib_max(data: bytes) -> bytes:
    """Try compatible zlib variants and keep the smallest (mirrors desktop)."""
    candidates = [zlib.compress(data, level=9)]
    for memory_level in (8, 9):
        for strategy in (zlib.Z_DEFAULT_STRATEGY, zlib.Z_FILTERED):
            compressor = zlib.compressobj(level=9, method=zlib.DEFLATED, wbits=15, memLevel=memory_level, strategy=strategy)
            candidates.append(compressor.compress(data) + compressor.flush())
    return min(candidates, key=len)


def align_up(value: int, alignment: int) -> int:
    return (value + alignment - 1) // alignment * alignment


def parse_entry(raw: bytes, exact_length: int):
    """Split an entry container into its decompressed bytes and ZLIB blocks."""
    entry_type = raw[:4]
    if entry_type == TYPE_COMPRESSED:
        first_offset = struct.unpack_from("<I", raw, 4)[0]
        compressed_wrapper = True
    elif entry_type == TYPE_ZLIB:
        first_offset = 0
        compressed_wrapper = False
    else:
        raise ValueError(f"""unsupported entry wrapper {entry_type.hex()}""")
    position = first_offset
    blocks = []
    unpacked = bytearray()
    while position + 16 <= exact_length and raw[position:position + 4] == TYPE_ZLIB:
        unpacked_size, stored_size, flags = struct.unpack_from(">III", raw, position + 4)
        if stored_size < 16 or position + stored_size > exact_length:
            raise ValueError("invalid ZLIB block size")
        chunk = zlib.decompress(raw[position + 16:position + stored_size])
        if len(chunk) != unpacked_size:
            raise ValueError("ZLIB block decompressed to the wrong length")
        blocks.append(Block(position, unpacked_size, stored_size, flags, hashlib.sha256(chunk).digest()))
        unpacked.extend(chunk)
        position += stored_size

    if not blocks:
        raise ValueError("entry contains no ZLIB blocks")
    return (unpacked, blocks, first_offset, compressed_wrapper)


def rebuild_entry(raw, original_exact_length, modified, blocks, first_offset, compressed_wrapper, fmt: ContainerFormat=FORMATS[FORMAT_2K20]):
    """Re-encode an edited entry container (mirrors desktop obb_encrypt)."""
    cursor = 0
    prepared = []
    preserve_possible = True
    changed_blocks = 0
    for block in blocks:
        view = memoryview(modified)[cursor:cursor + block.unpacked_size]
        changed = hashlib.sha256(view).digest() != block.original_sha256
        packed = compress_zlib_max(view) if changed else None
        if changed:
            changed_blocks += 1
            if 16 + len(packed) > block.stored_size:
                preserve_possible = False
        prepared.append((block, packed, changed))
        cursor += block.unpacked_size

    if cursor != len(modified):
        raise ValueError(f"edited content is {len(modified)} bytes but the original entry's ZLIB blocks total {cursor} bytes -- zlib entries cannot be resized")

    if preserve_possible:
        pieces = [raw[:first_offset]]
        for block, packed, changed in prepared:
            if not changed:
                pieces.append(raw[block.position:block.position + block.stored_size])
                continue
            compact_size = 16 + len(packed)
            pieces.append(TYPE_ZLIB + struct.pack(">III", block.unpacked_size, block.stored_size, block.flags) + packed + b"\x00" * (block.stored_size - compact_size))
        end = blocks[-1].position + blocks[-1].stored_size
        pieces.append(raw[end:original_exact_length])
        rebuilt = b"".join(pieces)
        if len(rebuilt) != original_exact_length:
            raise ValueError("layout-preserved rebuild changed the entry length")
        return (rebuilt, "preserved", changed_blocks)
    compact_blocks = []
    for block, packed, changed in prepared:
        if not changed:
            compact_blocks.append(raw[block.position:block.position + block.stored_size])
            continue
        compact_blocks.append(TYPE_ZLIB + struct.pack(">III", block.unpacked_size, 16 + len(packed), block.flags) + packed)

    prefix = bytearray(raw[:first_offset])
    if compressed_wrapper:
        position = first_offset
        for index, block_bytes in enumerate(compact_blocks):
            descriptor = fmt.descriptor_base + index * fmt.descriptor_stride
            if descriptor + fmt.descriptor_stored_delta + 4 > len(prefix):
                raise ValueError("compressed wrapper has no matching resource descriptor")
            struct.pack_into("<I", prefix, descriptor + fmt.descriptor_position_delta, position)
            struct.pack_into("<I", prefix, descriptor + fmt.descriptor_stored_delta, len(block_bytes))
            position += len(block_bytes)
        rebuilt_array = bytearray(prefix + b"".join(compact_blocks))
        struct.pack_into(fmt.header_length_byteorder + "I", rebuilt_array, fmt.header_length_offset, len(rebuilt_array))
        rebuilt = bytes(rebuilt_array)
    else:
        rebuilt = b"".join(compact_blocks)
    return (rebuilt, "compact", changed_blocks)


def apply_entries(
    source: Path,
    output: Path,
    entries: list[BuiltEntry],
    fmt: ContainerFormat,
    progress_callback=None,
) -> None:
    """Copy the source OBB and overwrite/append the edited entries."""
    output.parent.mkdir(parents=True, exist_ok=True)
    total = source.stat().st_size
    copied = 0
    with source.open("rb") as src, output.open("wb") as dst:
        while True:
            chunk = src.read(COPY_CHUNK)
            if not chunk:
                break
            dst.write(chunk)
            copied += len(chunk)
            if progress_callback:
                progress_callback(copied, total)
    append_position = output.stat().st_size
    if append_position % ALIGNMENT:
        raise ValueError("source OBB does not end on an alignment boundary")

    with output.open("r+b") as stream:
        for built in entries:
            if built.mode != "append":
                stream.seek(built.offset)
                stream.write(built.data)
                stream.write(b"\x00" * (built.slot_size - len(built.data)))
                block = built.offset // ALIGNMENT
            else:
                block = append_position // ALIGNMENT
                stream.seek(append_position)
                stream.write(built.data)
                padded = align_up(len(built.data), ALIGNMENT)
                stream.write(b"\x00" * (padded - len(built.data)))
                append_position += padded
            record_offset = fmt.table_offset + built.index * fmt.record.size
            if fmt.name == FORMAT_2K16:
                stream.seek(record_offset)
                stream.write(struct.pack("<Q", len(built.data)))
                stream.seek(record_offset + 12)
                stream.write(struct.pack("<I", block))
            else:
                stream.seek(record_offset)
                stream.write(struct.pack("<I", len(built.data)))
                stream.seek(record_offset + 12)
                stream.write(struct.pack("<I", block))
        stream.seek(fmt.total_blocks_offset)
        stream.write(struct.pack("<Q", append_position // ALIGNMENT))


def compute_archive_crc32(path: Path) -> int:
    """Reproduce VCBinFileDevice_Platform_VerifyDevice's archive checksum."""
    obb = Obb(path)
    checksum = 0
    with path.open("rb") as stream:
        for entry in sorted(obb.entries, key=lambda item: item.block):
            remaining = entry.length
            if not remaining:
                continue
            stream.seek(entry.offset)
            while remaining:
                chunk = stream.read(min(8388608, remaining))
                if not chunk:
                    raise EOFError(f"entry {entry.index} ended during CRC calculation")
                checksum = zlib.crc32(chunk, checksum)
                remaining -= len(chunk)
    return checksum


def update_archive_crc32(path: Path) -> int:
    checksum = compute_archive_crc32(path)
    fmt = Obb(path).format
    with path.open("r+b") as stream:
        stream.seek(fmt.checksum_offset)
        stream.write(struct.pack("<I", checksum))
    return checksum


def verify_output(path: Path, entries: list[BuiltEntry], archive_crc32: int) -> None:
    """Confirm every changed entry decompresses to the expected bytes."""
    obb = Obb(path)
    entries_by_index = {entry.index: entry for entry in obb.entries}
    for built in entries:
        entry = entries_by_index[built.index]
        if built.is_zlib:
            digest = sha256_bytes(obb.decompressed_bytes(entry))
            total = len(obb.decompressed_bytes(entry))
        else:
            with obb.path.open("rb") as stream:
                stream.seek(entry.offset)
                digest = sha256_bytes(stream.read(built.expected_size))
                total = built.expected_size
        if (digest, total) != (built.expected_sha256, built.expected_size):
            raise ValueError(f"verification failed for {built.name}")
    with path.open("rb") as stream:
        stream.seek(obb.format.checksum_offset)
        stored_crc32 = struct.unpack("<I", stream.read(4))[0]
    if stored_crc32 != archive_crc32 or compute_archive_crc32(path) != archive_crc32:
        raise ValueError("archive CRC verification failed")


class ObbSession:
    """One source OBB plus a small cache of staged edited IFF entries."""

    def __init__(self, path: Path, cache_dir: Path):
        self.path = path.resolve()
        if not self.path.is_file():
            raise ValueError(f"""OBB was not found: {self.path}""")
        self.obb = Obb(self.path)
        self.cache_dir = cache_dir.resolve()
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        stat = self.path.stat()
        self.source_size = stat.st_size
        self.source_modified_ns = stat.st_mtime_ns
        self.staged = {}

    def _entry(self, index: int) -> Entry:
        if index < 0 or index >= len(self.obb.entries):
            raise IndexError(f"""OBB entry index must be 0-{len(self.obb.entries) - 1}""")
        return self.obb.entries[index]

    def staged_raw(self, index: int) -> bytes | None:
        """The staged replacement container for ``index``, if one exists."""
        staged = self.staged.get(index)
        if staged is None:
            return None
        return staged.raw_path.read_bytes()

    def copy_entry_raw(self, index: int, destination: Path) -> int:
        """Stream an entry's exact stored container bytes to ``destination``.

        Serves the staged replacement when one exists, otherwise the original
        source bytes.  Either way the file is written to a ``.partial``
        sibling and atomically renamed, and never fully held in memory.
        """
        staged = self.staged.get(index)
        if staged is None:
            return self.obb.copy_entry_raw(self._entry(index), destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_suffix(destination.suffix + ".partial")
        written = 0
        try:
            with staged.raw_path.open("rb") as source, temporary.open("wb") as output:
                while chunk := source.read(COPY_CHUNK):
                    output.write(chunk)
                    written += len(chunk)
            if written != staged.raw_size:
                raise EOFError(f"staged entry {index} wrote {written} of {staged.raw_size} bytes")
            os.replace(temporary, destination)
        finally:
            temporary.unlink(missing_ok=True)
        return written

    def entry_raw(self, index: int) -> bytes:
        """Exact stored container bytes for an entry, serving staged edits.

        After an IFF is replaced (staged), every read path -- extraction,
        export, and opening the entry in the editor -- must return the
        replacement, otherwise the workspace silently still shows the
        original even though the app reported success.
        """
        staged = self.staged.get(index)
        if staged is not None:
            return staged.raw_path.read_bytes()
        return self.obb.read_entry_raw(self._entry(index))

    def entry_decompressed(self, index: int) -> bytes:
        """Decompressed bytes for an entry, serving staged edits."""
        staged = self.staged.get(index)
        if staged is not None:
            raw = staged.raw_path.read_bytes()
            unpacked, _blocks, _first, _compressed = parse_entry(raw, len(raw))
            return bytes(unpacked)
        return self.obb.decompressed_bytes(self._entry(index))

    def verify_staged(self, index: int, expected_decompressed_sha256: str) -> None:
        """Read the staged entry back from disk and confirm it matches.

        This is the read-back verification step: the replacement is written to
        the staging cache, then re-read and re-decompressed, and its digest
        must equal the digest of the data we intended to stage.  Raises
        ``ValueError`` when the staged file is missing, unreadable, or does
        not round-trip.
        """
        staged = self.staged.get(index)
        if staged is None:
            raise ValueError(f"""entry {index} has no staged replacement to verify""")
        raw = staged.raw_path.read_bytes()
        if len(raw) != staged.raw_size:
            raise ValueError(f"""entry {index} staged file is {len(raw)} bytes, expected {staged.raw_size}""")
        unpacked, _blocks, _first, _compressed = parse_entry(raw, len(raw))
        decompressed = bytes(unpacked)
        if len(decompressed) != staged.decompressed_size:
            raise ValueError(f"""entry {index} staged data decompresses to {len(decompressed)} bytes, expected {staged.decompressed_size}""")
        digest = sha256_bytes(decompressed)
        if digest != expected_decompressed_sha256:
            raise ValueError(f"""entry {index} read-back verification failed: staged digest {digest} does not match the replacement digest {expected_decompressed_sha256}""")

    def rows(self) -> list[dict]:
        rows = []
        for entry in self.obb.entries:
            name = entry_name(entry.name_hash)
            cyberface_kind = "scene" if cyberface_name(entry.name_hash) else ""
            category = asset_category(entry.name_hash)
            if not self.obb.is_valid_entry(entry):
                rows.append({"index": entry.index, "name": name, "hash": f"""{entry.name_hash:08x}""", "type": "invalid", "length": entry.length, "stored_size": 0, "block": entry.block, "editable": False, "staged": False, "cyberface": "", "category": category[0] if category else "", "subcategory": category[1] if category else "", "asset_id": category[2] if category else None, "display_label": display_label(entry.name_hash), "error": f"""Entry {entry.index} is corrupted: block offset {entry.block} is out of bounds for this archive. This entry cannot be extracted or edited."""})
                continue
            editable = self.obb.is_editable(entry)
            rows.append({"index": entry.index, "name": name, "hash": f"""{entry.name_hash:08x}""", "type": self.obb.type_name(entry), "length": entry.length, "stored_size": self.obb.stored_size(entry), "block": entry.block, "editable": editable, "staged": entry.index in self.staged, "cyberface": cyberface_kind, "category": category[0] if category else "", "subcategory": category[1] if category else "", "asset_id": category[2] if category else None, "display_label": display_label(entry.name_hash)})
        return rows

    def extract_iff(self, index: int, destination: Path) -> dict:
        """Write the decompressed IFF bytes of one entry and return its info.

        When the entry has a staged replacement, the staged (rebuilt)
        container is decompressed instead of the original source bytes.
        """
        entry = self._entry(index)
        if not self.obb.is_editable(entry):
            raise ValueError(f"""entry {index} ({self.obb.type_name(entry)}) is not an editable IFF""")

        if index in self.staged:
            data = self.entry_decompressed(index)
            destination.parent.mkdir(parents=True, exist_ok=True)
            temporary = destination.with_suffix(destination.suffix + ".partial")
            temporary.write_bytes(data)
            os.replace(temporary, destination)
            written = len(data)
        else:
            written = self.obb.extract_iff(entry, destination)
        return {"index": index, "name": entry_name(entry.name_hash), "path": str(destination), "size": written}

    def stage_iff(self, index: int, rebuilt_raw: bytes, decompressed_data: bytes) -> dict:
        """Verify and stage one edited IFF entry (mirrors desktop direct_obb)."""
        entry = self._entry(index)
        if not self.obb.is_editable(entry):
            raise ValueError(f"""entry {index} ({self.obb.type_name(entry)}) is not an editable IFF""")
        check_data, _blocks, _first_offset, _compressed = parse_entry(rebuilt_raw, len(rebuilt_raw))
        if bytes(check_data) != decompressed_data:
            raise ValueError(f"""entry {index} staging verification failed: decompressed bytes differ""")
        destination = self.cache_dir / f"""entry_{index:04d}.rebuilt"""
        temporary = destination.with_suffix(destination.suffix + ".partial")
        temporary.write_bytes(rebuilt_raw)
        os.replace(temporary, destination)
        staged = StagedEntry(index=index, label=entry_name(entry.name_hash), raw_path=destination, raw_size=len(rebuilt_raw), decompressed_size=len(decompressed_data), decompressed_sha256=sha256_bytes(decompressed_data))
        self.staged[index] = staged
        self.verify_staged(index, staged.decompressed_sha256)
        return {"index": index, "name": staged.label, "raw_size": staged.raw_size, "decompressed_size": staged.decompressed_size, "decompressed_sha256": staged.decompressed_sha256, "verification": "PASS"}

    def discard_stage(self, index: int) -> None:
        staged = self.staged.pop(index, None)
        if staged is not None:
            staged.raw_path.unlink(missing_ok=True)

    def _assert_source_unchanged(self) -> None:
        stat = self.path.stat()
        if (stat.st_size, stat.st_mtime_ns) != (self.source_size, self.source_modified_ns):
            raise ValueError("the source OBB changed outside the app; reopen it before saving")

    def save_obb(self, destination: Path, progress_callback=None) -> dict:
        """Build a new OBB with staged entries, verify it, and return a report."""
        if not self.staged:
            raise ValueError("no edited IFF entries are staged for the OBB")
        self._assert_source_unchanged()
        destination = destination.resolve()
        if destination == self.path:
            raise ValueError("output OBB must be a new file; the source is never overwritten")
        destination.parent.mkdir(parents=True, exist_ok=True)
        try:
            free_space = shutil.disk_usage(destination.parent).free
            needed_space = self.path.stat().st_size
            if free_space < needed_space:
                raise OSError(f"""Insufficient storage to rebuild OBB. Needed: {needed_space // 1048576} MB, available: {free_space // 1048576} MB. Please free up space on device.""")
        except OSError as e:
            if "Insufficient storage" in str(e):
                raise
        except Exception:
            pass
        temporary = destination.with_suffix(destination.suffix + ".partial")
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        built_entries = []
        for index in sorted(self.staged):
            staged = self.staged[index]
            entry = self._entry(index)
            raw = staged.raw_path.read_bytes()
            mode = "preserved" if len(raw) <= self.obb.stored_size(entry) else "append"
            built_entries.append(BuiltEntry(name=staged.label, index=index, offset=entry.offset, slot_size=self.obb.stored_size(entry), data=raw, expected_sha256=staged.decompressed_sha256, expected_size=staged.decompressed_size, is_zlib=True, mode=mode))
        try:
            apply_entries(self.path, temporary, built_entries, self.obb.format, progress_callback)
            archive_crc32 = update_archive_crc32(temporary)
            verify_output(temporary, built_entries, archive_crc32)
            output_size = temporary.stat().st_size
            os.replace(temporary, destination)
        finally:
            temporary.unlink(missing_ok=True)
        return {"source_obb": str(self.path), "output_obb": str(destination), "output_obb_size": output_size, "archive_crc32": f"""0x{archive_crc32:08X}""", "changed_entry_count": len(built_entries), "changed_entries": [{"index": item.index, "name": item.name, "mode": item.mode, "decompressed_size": item.expected_size, "decompressed_sha256": item.expected_sha256} for item in built_entries], "verification": "PASS"}
