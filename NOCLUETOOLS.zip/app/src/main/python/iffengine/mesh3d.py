"""Cyberface mesh extraction for the 3D preview.

Layout reverse-engineered from 2K20 mobile cyberface scenes (PNG####.IFF):

    block 1 offset 0            u16 triangle index buffer (6 bytes/triangle)
    block 1 + <record table>    28-byte vertex records:
                                  [0:6]   tangent  3xSNORM16
                                  [6:8]   zero pad
                                  [8:14]  normal   3xSNORM16
                                  [14:16] zero pad
                                  [16:20] uv       2xSNORM16 (positive [0,1])
                                  [20:28] skin data (bone indices/weights)
    block 0, <position stream>  positions 3xSNORM16 (6-byte stride), one run
                                covering all sub-mesh batches sequentially

Positions sit inside a table region of block 0 and are located by scanning for
the longest smooth 6-byte-stride SNORM16 run (vertex tables vary slowly between
neighbouring vertices; matrices/quaternions/text do not).

Display-only extraction: nothing in the container is modified.
"""
import struct
import zipfile
from pathlib import Path
from . import pngio

def _snorm16(raw: int) -> float:
    return (raw - 65536 if raw >= 32768 else raw) / 32767.0
RECORD_LAYOUTS = {28: (0, 8, 16, 's16'), 32: (4, 20, 12, 'f16')}

def _record_unit_ok(data: bytes, off: int, rsize: int) -> bool:
    """True when both SNORM16 triples of one record are unit-norm."""
    t_off, n_off, _uv_off, _kind = RECORD_LAYOUTS[rsize]
    t0, t1, t2 = struct.unpack_from('<3H', data, off + t_off)
    n0, n1, n2 = struct.unpack_from('<3H', data, off + n_off)
    for x, y, z in ((_snorm16(t0), _snorm16(t1), _snorm16(t2)), (_snorm16(n0), _snorm16(n1), _snorm16(n2))):
        norm_sq = x * x + y * y + z * z
        if not 0.81 <= norm_sq <= 1.21:
            return False
    return True

def _locate_record_table(data: bytes, block1: int, block1_len: int) -> tuple[int, int, int]:
    """Return (record_table_byte_offset, record_count, record_size) inside block 1.

    The table starts where the u16 index buffer ends.  Indices are always
    < 0x8000 while records contain negative SNORM16 components (raw >= 0x8000),
    so the first big raw value bounds the start; the exact start is validated
    backwards in 2-byte steps (the table can be 4-byte aligned, so 6-byte steps
    would miss it — e.g. PNG0008's table at 0x30a0 with first_big at 0x30a2).
    Two record sizes are known: 28-byte (most scenes) and 32-byte (rare, e.g.
    PNG2536) where tangent/normal sit deeper and UVs are 16.16 fixed-point.
    """
    limit = min(block1_len, 131072)
    first_big = None
    for off in range(0, limit - 2, 2):
        raw, = struct.unpack_from('<H', data, block1 + off)
        if raw >= 32768:
            first_big = off
            break
    if first_big is None:
        raise ValueError('no vertex record table found in block 1')
    for rsize in (28, 32):
        start = first_big & -2
        for _ in range(4096):
            if start < 0:
                break
            if all((_record_unit_ok(data, block1 + start + r * rsize, rsize) for r in range(24))):
                count = 24
                while count <= 300000:
                    off = block1 + start + count * rsize
                    if off + rsize > len(data):
                        break
                    if not _record_unit_ok(data, off, rsize):
                        break
                    count += 1
                return (start, count, rsize)
            start -= 2
    raise ValueError('vertex record table phase not found')

def _locate_positions(data: bytes, block0_len: int, want: int) -> int:
    """Return the block-0 byte offset of the packed XYZW position stream.

    NBA 2K mobile cyberface scenes store vertex coordinates as packed
    (int16 X, int16 Y, int16 Z, int16 W) with an 8-byte stride, where
    W is 32767 (0x7FFF) or -32767. Coordinates are scaled in millimeters.
    """
    limit = min(block0_len, len(data))
    if limit < 8000:
        raise ValueError('block 0 too small')
    for cand in (81952, 77376):
        if cand + want * 8 <= limit:
            w0 = struct.unpack_from('<h', data, cand + 6)[0]
            w1 = struct.unpack_from('<h', data, cand + (want - 1) * 8 + 6)[0]
            if w0 in (32767, -32767) and w1 in (32767, -32767):
                return cand
    best = None
    for off in range(0, limit - 8000, 2):
        if struct.unpack_from('<h', data, off + 6)[0] not in (32767, -32767):
            continue
        if off >= 8 and struct.unpack_from('<h', data, off - 2)[0] in (32767, -32767):
            continue
        count = 0
        while off + (count + 1) * 8 <= limit and count < 6000:
            if struct.unpack_from('<h', data, off + count * 8 + 6)[0] not in (32767, -32767):
                break
            count += 1
        if count >= 1000:
            score = count * 10
            if want > 0 and count == want:
                score += 10000000
            elif want > 0 and count >= want:
                score += 100000
            if best is None or score > best[0]:
                best = (score, off, count)
                if score >= 10000000:
                    break
    if best is not None:
        return best[1]
    raise ValueError(f"packed XYZW position stream not found in block 0 (needed {want} vertices, block0 {block0_len} bytes) — this scene's mesh layout is not recognized")
_CLEAN_TRI_LIMIT = 3107

def _strip_to_triangles(raw):
    """Triangle-strip decode (same convention as extract_cyberface_mesh)."""
    out = []
    for i in range(len(raw) - 2):
        i0, i1, i2 = (raw[i], raw[i + 1], raw[i + 2])
        if i0 == i1 or i1 == i2 or i0 == i2:
            continue
        if i % 2 == 1:
            out.append((i0, i2, i1))
        else:
            out.append((i0, i1, i2))
    return out

def _triangles_to_strip(tris_flat, vertex_count):
    """Pack a triangle list into a triangle strip with degenerate restarts.

    Edge-chasing: keep appending triangles that share the current strip edge;
    restart (via a degenerate run) only when stuck.  Every restart sequence
    decodes to degenerate windows ONLY, and the real triangle is placed on an
    even window index so the decoder's parity-based winding flip matches the
    original data convention.

    Edges are matched UNDIRECTED (either stored direction may be followed).
    The parity-based decoder then emits some chased triangles rotated or
    reflected relative to their input order — the same geometric triangle,
    because strip decoding preserves the vertex *set* of every window.
    Winding consistency is impossible to preserve across the original
    meshes' orientation seams anyway (sub-strips with alternating parity
    phase force constant restarts), and the renderer disables backface
    culling, so geometry-exact output is the contract: the caller verifies
    the decoded triangle SET against the input exactly.
    """
    tris = [(tris_flat[i], tris_flat[i + 1], tris_flat[i + 2]) for i in range(0, len(tris_flat), 3)]
    tris = [t for t in tris if t[0] != t[1] and t[1] != t[2] and (t[0] != t[2])]
    n = len(tris)
    dead = [False] * n
    remaining = n
    edge_tris = {}
    vertex_tris = [[] for _ in range(max(vertex_count, 1))]
    for t, (a, b, c) in enumerate(tris):
        for e in ((a, b), (b, c), (c, a)):
            edge_tris.setdefault(e, []).append(t)
            edge_tris.setdefault((e[1], e[0]), []).append(t)
        for v in (a, b, c):
            vertex_tris[v].append(t)
    valence = [len(vt) for vt in vertex_tris]
    VALENCE_SCORE = (0, 3, 10, 25, 50, 75, 75, 50)

    def _score(tt: int) -> int:
        s = 0
        for v in tris[tt]:
            s += VALENCE_SCORE[valence[v]] if valence[v] < len(VALENCE_SCORE) else 0
        return s

    def _kill(tt: int) -> None:
        nonlocal remaining
        dead[tt] = True
        remaining -= 1
        for v in tris[tt]:
            valence[v] -= 1
    strip = []
    while remaining:
        t = None
        best_s = -1
        if strip:
            qend = strip[-1]
            if qend < vertex_count:
                for tt in vertex_tris[qend]:
                    if dead[tt]:
                        continue
                    s = _score(tt)
                    if s > best_s:
                        best_s = s
                        t = tt
        if t is None:
            for tt in range(n):
                if dead[tt]:
                    continue
                s = _score(tt)
                if s > best_s:
                    best_s = s
                    t = tt
        a, b, c = tris[t]
        _kill(t)
        if not strip:
            strip.extend((a, b, c))
        else:
            q = strip[-1]
            strip.extend((q, a, a))
            if len(strip) % 2 == 0:
                strip.append(a)
            strip.extend((b, c))
        while True:
            p, q = (strip[-2], strip[-1])
            candidates = [tt for tt in edge_tris.get((p, q), ()) if not dead[tt]]
            if not candidates:
                break
            tt = max(candidates, key=lambda x: (_score(x), -x))
            _kill(tt)
            nxt = _third_vertex(*tris[tt], p, q)
            if nxt is None or nxt == p or nxt == q:
                break
            strip.append(nxt)
    return strip

def _triangles_to_strip_best(tris_flat, vertex_count, tries=8):
    """Best-of-N pack: run the stripifier from several seed triangles and
    keep the shortest output. Tiny sub-strips (the 2K20 exporter batches
    ~7 triangles) are extremely sensitive to the starting seed — picking
    the best of a handful of runs routinely saves the 3-6 words a restart
    costs, which is the difference between fitting a segment's original
    word span and cascading into the neighbours.
    """
    tris = [(tris_flat[i], tris_flat[i + 1], tris_flat[i + 2]) for i in range(0, len(tris_flat), 3)]
    if len(tris) <= 1:
        return _triangles_to_strip(tris_flat, vertex_count)
    best = None
    seen_seeds = set()
    for seed in range(min(tries, len(tris))):
        idx = seed * 3 % len(tris) if seed else 0
        if idx in seen_seeds:
            continue
        seen_seeds.add(idx)
        rotated = tris[idx:] + tris[:idx]
        flat = [v for t in rotated for v in t]
        packed = _triangles_to_strip(flat, vertex_count)
        if best is None or len(packed) < len(best):
            best = packed
    return best if best is not None else []

def _third_vertex(x, y, z, d0, d1):
    """Third vertex of triangle (x,y,z) for the undirected edge {d0,d1}.

    Returns None when the triangle does not contain the edge (defensive;
    candidates always come from the edge incidence map).
    """
    if x == d0 and y == d1 or (x == d1 and y == d0):
        return z
    if y == d0 and z == d1 or (y == d1 and z == d0):
        return x
    if z == d0 and x == d1 or (z == d1 and x == d0):
        return y
    return None

def _strip_segments(raw):
    """Split a raw strip buffer into its sub-strip segments.

    2K20 cyberface strips are many SMALL sub-strips separated by 2-5 word
    degenerate restart runs.    Returns ``(prefix_len, segments)`` where each
    segment is ``{"start": word index of its first real window, "tris":
    list of (a, b, c) tuples}``. Windows inside a segment decode normally; a
    degenerate window only ever starts a new segment (this matches the
    game's batched export layout).
    """
    segments = []
    cur = None
    parity = 0
    for i in range(len(raw) - 2):
        i0, i1, i2 = (raw[i], raw[i + 1], raw[i + 2])
        if i0 == i1 or i1 == i2 or i0 == i2:
            cur = None
            continue
        if cur is None:
            cur = {'start': i, 'tris': []}
            segments.append(cur)
        if parity % 2 == 1:
            cur['tris'].append((i0, i2, i1))
        else:
            cur['tris'].append((i0, i1, i2))
        parity += 1
    prefix_len = segments[0]['start'] if segments else 0
    return (prefix_len, segments)

def extract_cyberface_mesh(opened) -> dict:
    """Decode the first sub-mesh batch of a 2K20 cyberface scene.

    Returns positions (meters, y-up), normals, uvs and triangle indices as
    plain lists.  Raises ValueError for scenes that do not match the
    reverse-engineered layout.
    """
    data = bytes(opened.data)
    sizes = opened.block_sizes
    if len(sizes) < 2:
        raise ValueError('cyberface scene needs two blocks')
    block0_len = sizes[0]
    block1 = sizes[0]
    block1_len = sizes[1] if len(sizes) > 1 else len(data) - block1
    rec_off, rec_count, rsize = _locate_record_table(data, block1, block1_len)
    t_off, n_off, uv_off, uv_kind = RECORD_LAYOUTS[rsize]
    pos_off = _locate_positions(data, block0_len, rec_count)
    positions, normals, uvs = ([], [], [])
    for r in range(rec_count):
        rec = block1 + rec_off + r * rsize
        px, py, pz, _pw = struct.unpack_from('<4h', data, pos_off + r * 8)
        positions.append((px / 1000.0, py / 1000.0, pz / 1000.0))
        n0, n1, n2 = struct.unpack_from('<3H', data, rec + n_off)
        normals.append((_snorm16(n0), _snorm16(n1), _snorm16(n2)))
        if uv_kind == 's16':
            [u0, v0] = struct.unpack_from('<2H', data, rec + uv_off)
            uvs.append((u0 / 32767.0, 1.0 - v0 / 32767.0))
            continue
        [u0, v0] = struct.unpack_from('<2I', data, rec + uv_off)
        uvs.append((u0 / 65536.0, 1.0 - v0 / 65536.0))
    num_indices = rec_off // 2
    raw_indices = struct.unpack_from(f'<{num_indices}H', data, block1)
    indices = []
    for i in range(len(raw_indices) - 2):
        i0, i1, i2 = (raw_indices[i], raw_indices[i + 1], raw_indices[i + 2])
        if i0 == i1 or i1 == i2 or i0 == i2:
            continue
        if i % 2 == 1:
            indices.extend((i0, i2, i1))
        else:
            indices.extend((i0, i1, i2))
    tri_count = len(indices) // 3
    if tri_count < 1:
        raise ValueError('index buffer produced no valid triangles')
    if indices and max(indices) >= rec_count:
        raise ValueError(f'index out of range ({max(indices)} >= {rec_count}) — layout mismatch')
    return {'positions': positions, 'normals': normals, 'uvs': uvs, 'indices': indices, 'vertices': rec_count, 'triangles': tri_count}

def update_mesh_data(opened, positions_f32, normals_f32, uvs_f32, indices_u16=None, remap_u16=None) -> dict:
    """Write edited mesh data back into the scene, in place (save-to-IFF).

    Byte-exact in-place rewrite of the streams that ``extract_cyberface_mesh``
    reads, so the container layout, record table and index buffer are preserved
    untouched (the game tolerates changed values, not changed structure):

      positions  8-byte (x,y,z,W) SNORM16 records, millimeter scale
      normals    3xSNORM16 inside the 28/32-byte vertex records
      uvs        2xSNORM16 (28-byte records) or 2xu16 16.16 fixed (32-byte)

    Topology (vertex/triangle counts, index buffer, skin data) must be
    unchanged — extrude/merge/delete change counts and are rejected with a
    clear error instead of silently corrupting the scene.
    """
    import struct as _struct
    data = bytearray(opened.data)
    sizes = opened.block_sizes
    if len(sizes) < 2:
        raise ValueError('cyberface scene needs two blocks')
    block0_len = sizes[0]
    block1 = sizes[0]
    block1_len = sizes[1] if len(sizes) > 1 else len(data) - block1
    rec_off, rec_count, rsize = _locate_record_table(data, block1, block1_len)
    _t_off, n_off, uv_off, uv_kind = RECORD_LAYOUTS[rsize]
    pos_off = _locate_positions(data, block0_len, rec_count)
    vertex_count = len(positions_f32) // 3
    if vertex_count > rec_count:
        raise ValueError(f'cannot save: edited mesh has {vertex_count} vertices but the scene has {rec_count}. Adding vertices (extrude) would require growing the index buffer region, which is not yet supported — use Move/Rotate/Scale/UV edits, or delete first, then extrude no more than you delete.')
    shrinking = vertex_count < rec_count
    rebuilding_strip = indices_u16 is not None
    if rebuilding_strip:
        if len(indices_u16) % 3:
            raise ValueError('index payload is not a whole number of triangles')
        for t in range(0, len(indices_u16), 3):
            tri = indices_u16[t:t + 3]
            if any((i >= vertex_count for i in tri)):
                raise ValueError(f'index payload references vertex {max(tri)} beyond the {vertex_count}-vertex mesh')
            continue
        remap = remap_u16
        if remap is not None and len(remap) != rec_count:
            raise ValueError('remap payload does not match the original vertex count')
        if remap is None:
            remap = list(range(rec_count))
    if len(normals_f32) != vertex_count * 3:
        raise ValueError('normal payload does not match vertex count')
    if len(uvs_f32) != vertex_count * 2:
        raise ValueError('uv payload does not match vertex count')
    max_coord = 2000000.0
    patched_positions = patched_normals = patched_uvs = 0
    strip_written = 0
    original_pos = bytes(data[pos_off:pos_off + rec_count * 8])
    original_rec = bytes(data[block1 + rec_off:block1 + rec_off + rec_count * rsize])

    def f32_to_snorm16(value: float) -> int:
        q = int(round(value * 32767.0))
        return max(-32767, min(32767, q))
    for v in range(rec_count):
        px = positions_f32[v * 3 + 0]
        py = positions_f32[v * 3 + 1]
        pz = positions_f32[v * 3 + 2]
        if max(abs(px), abs(py), abs(pz)) > max_coord:
            raise ValueError(f'vertex {v} coordinate out of range')
        rec = pos_off + v * 8
        _struct.pack_into('<3h', data, rec, int(round(px * 1000.0)), int(round(py * 1000.0)), int(round(pz * 1000.0)))
        patched_positions += 1
        r = block1 + rec_off + v * rsize
        nx = normals_f32[v * 3 + 0]
        ny = normals_f32[v * 3 + 1]
        nz = normals_f32[v * 3 + 2]
        _struct.pack_into('<3h', data, r + n_off, f32_to_snorm16(nx), f32_to_snorm16(ny), f32_to_snorm16(nz))
        patched_normals += 1
        u = uvs_f32[v * 2 + 0]
        vv = uvs_f32[v * 2 + 1]
        if uv_kind == 's16':
            uq = max(0, min(65535, int(round(u * 32767.0))))
            vq = max(0, min(65535, int(round((1.0 - vv) * 32767.0))))
            _struct.pack_into('<2H', data, r + uv_off, uq, vq)
        else:
            uq = max(0, min(4294967295, int(round(u * 65536.0))))
            vq = max(0, min(4294967295, int(round((1.0 - vv) * 65536.0))))
            _struct.pack_into('<2I', data, r + uv_off, uq, vq)
        patched_uvs += 1
    if rebuilding_strip:
        num_indices = rec_off // 2
        original_raw = struct.unpack_from(f'<{num_indices}H', data, block1)
        [prefix_len, segments] = _strip_segments(original_raw)
        original_tri_total = sum((len(s['tris']) for s in segments))
        tail_start = min(_CLEAN_TRI_LIMIT, original_tri_total)
        expected = []
        tail_dropped = 0
        seen = 0
        for seg in segments:
            seg_count = len(seg['tris'])
            head_part = max(0, min(seg_count, tail_start - seen))
            seen += seg_count
            seg['head_count'] = head_part
            seg['changed'] = False
        canon_tri = lambda t: tuple(sorted(t))

        def remapped_canon(tri):
            """Canonical form of an original triangle in CURRENT ids.
            Triangles referencing a removed vertex cannot appear in the
            editor's list (it already dropped them) — return None."""
            if remap:
                vals = []
                for v in tri:
                    rv = remap[v] if v < len(remap) else v
                    if rv < 0:
                        return None
                    vals.append(rv)
                return tuple(sorted(vals))
            return canon_tri(tri)
        orig_head = []
        for si, seg in enumerate(segments):
            for t in seg['tris'][:seg['head_count']]:
                rc_t = remapped_canon(t)
                if rc_t is not None:
                    orig_head.append((si, rc_t))
                continue
        assigned = [[] for _ in segments]
        last_si = 0
        j = 0
        for ti in range(0, len(indices_u16), 3):
            kt = tuple(indices_u16[ti:ti + 3])
            ck = canon_tri(kt)
            while j < len(orig_head) and orig_head[j][1] != ck:
                j += 1
            if j < len(orig_head):
                last_si = orig_head[j][0]
                j += 1
            assigned[last_si].extend(kt)
        for si, seg in enumerate(segments):
            hc = seg['head_count']
            if not hc:
                for tri in seg['tris']:
                    expected.extend(tri)
                continue
            new_flat = list(assigned[si])
            tc = len(seg['tris']) - hc
            if tc:
                for tri in seg['tris'][hc:]:
                    m = [remap[i] if i < rec_count else -1 for i in tri]
                    if any((x < 0 for x in m)):
                        tail_dropped += 1
                        continue
                    new_flat.extend(m)
            old_flat = [v for t in seg['tris'] for v in t]
            remapped_old = []
            if remap:
                for t in seg['tris']:
                    for v in t:
                        if v < len(remap):
                            rv = remap[v]
                            if rv >= 0:
                                remapped_old.append(rv)
            if sorted(new_flat) == sorted(old_flat):
                pass
            elif remapped_old and sorted(new_flat) == sorted(remapped_old):
                si2 = segments.index(seg)
                seg_end_w = segments[si2 + 1]['start'] if si2 + 1 < len(segments) else num_indices
                seg_words = list(original_raw[seg['start']:seg_end_w])
                for w in range(len(seg_words)):
                    word = seg_words[w]
                    if word < len(remap):
                        rv = remap[word]
                        if rv >= 0:
                            seg_words[w] = rv
                seg['verbatim_words'] = seg_words
                seg['changed'] = False
            else:
                seg['changed'] = True
            for v in new_flat:
                expected.append(v)
            seg['new_flat'] = new_flat
        starts = [s['start'] for s in segments] + [num_indices]
        blocks = []
        free_from = 0
        for si, seg in enumerate(segments):
            if not seg['head_count']:
                continue
            if seg.get('absorbed'):
                continue
            seg_start = starts[si]
            if not seg['changed']:
                if seg_start >= free_from:
                    blocks.append((seg_start, list(seg.get('verbatim_words') or original_raw[seg_start:starts[si + 1]]), True, starts[si + 1]))
                    free_from = starts[si + 1]
                    continue
                seg['changed'] = True
            group = list(seg['new_flat'])
            bstart = max(seg_start, free_from)
            j = si
            cascade = 0
            while True:
                span = starts[j + 1] - bstart
                reserve = 4 if j + 1 < len(segments) else 2
                packed = _triangles_to_strip_best(group, rec_count) if group else []
                if len(packed) + reserve <= span:
                    break
                if j + 1 >= len(segments) or not segments[j + 1]['head_count']:
                    raise ValueError(f'edited mesh needs {len(packed) + reserve} strip words but only {span} remain before the preserved tail — undo some deletions or reduce the edit')
                cascade += 1
                if cascade > 12:
                    raise ValueError('edited strip does not fit the original index region — undo some deletions or reduce the edit')
                j += 1
                group = group + list(segments[j]['new_flat'])
                segments[j]['changed'] = True
                segments[j]['absorbed'] = True
            if packed:
                blocks.append((bstart, packed, False, starts[j + 1]))
                free_from = bstart + len(packed) + 4
                continue
            free_from = starts[j + 1]
        out = [0] * num_indices
        if prefix_len:
            out[:prefix_len] = list(original_raw[:prefix_len])
        for tsi, seg in enumerate(segments):
            if not seg['head_count']:
                a, b = (seg['start'], starts[tsi + 1])
                out[a:b] = original_raw[a:b]
            continue
        prev_was_verbatim = False
        prev_end = 0
        last_word = 0
        for bi, (bstart, packed, is_v, span_end) in enumerate(blocks):
            original_boundary = ((
                bi > 0 and prev_was_verbatim and is_v and bstart == prev_end
                ) or (bi == 0 and is_v)
            )
            if not original_boundary and bstart >= 2:
                out[bstart - 2] = packed[0]
                out[bstart - 1] = packed[0]
            out[bstart:bstart + len(packed)] = packed
            if is_v:
                prev_was_verbatim = True
                prev_end = span_end
                if packed:
                    last_word = packed[-1]
                continue
            e = bstart + len(packed)
            if packed:
                last_word = packed[-1]
            if e < num_indices:
                out[e] = last_word
                if e + 1 < num_indices:
                    out[e + 1] = last_word
                gap_end = bstart_next = None
                nb = blocks[bi + 1] if bi + 1 < len(blocks) else None
                gap_end = nb[0] - 2 if nb is not None else num_indices
                if gap_end > e + 2:
                    for gi in range(e + 2, gap_end):
                        out[gi] = last_word
            prev_was_verbatim = False
            prev_end = e + 2
        if len(out) != num_indices:
            raise ValueError('internal strip assembly size mismatch')
        globals()['_LAST_STRIP_WORDS'] = list(out)
        globals()['_LAST_EXPECTED'] = list(expected)
        globals()['_LAST_BLOCKS'] = [(s, len(p), v, e) for s, p, v, e in blocks]
        globals()['_LAST_SEGMENTS'] = [{'start': s['start'], 'head': s.get('head_count', 0), 'changed': s.get('changed', False)} for s in segments]
        decoded = _strip_to_triangles(out)
        canon = lambda t: tuple(sorted(t))
        dec_set = sorted(map(canon, decoded))
        exp_set = sorted(map(canon, (tuple(expected[i:i + 3]) for i in range(0, len(expected), 3))))
        if dec_set != exp_set:
            missing = [t for t in exp_set if t not in dec_set][:3]
            extra = [t for t in dec_set if t not in exp_set][:3]
            raise ValueError(f'internal error: rebuilt strip failed verification ({len(dec_set)} decoded vs {len(exp_set)} expected; missing={missing} extra={extra}) — save aborted, file unchanged')
        data[block1:block1 + num_indices * 2] = struct.pack(f'<{num_indices}H', *out)
        strip_written = num_indices
        if shrinking:
            tail_referenced = set()
            for seg in segments:
                for tri in seg['tris'][seg['head_count']:]:
                    tail_referenced.update(tri)
            for v in range(vertex_count, rec_count):
                r = block1 + rec_off + v * rsize
                if v in tail_referenced:
                    data[pos_off + v * 8:pos_off + v * 8 + 8] = original_pos[v * 8:v * 8 + 8]
                    data[r:r + rsize] = original_rec[v * rsize:v * rsize + rsize]
                    continue
                data[pos_off + v * 8:pos_off + v * 8 + 8] = b'\x00\x00\x00\x00\x00\x00\x00\x00'
                data[r:r + rsize] = b'\x00' * rsize
        tail_triangles_kept = sum((len(s['tris']) - s['head_count'] for s in segments)) - tail_dropped
        strip_rebuilt_segments = len(blocks)
    opened.data = bytes(data)
    return {'vertices_patched': patched_positions, 'normals_patched': patched_normals, 'uvs_patched': patched_uvs, 'vertices_added': 0, 'vertices_removed': rec_count - vertex_count if shrinking else 0, 'strip_rebuilt': rebuilding_strip, 'strip_words': strip_written, 'tail_triangles_kept': tail_triangles_kept if rebuilding_strip else 0, 'strip_segments': strip_rebuilt_segments if rebuilding_strip else 0, 'record_size': rsize, 'topology': 'shrunk' if shrinking else 'rebuilt' if rebuilding_strip else 'unchanged'}

def export_cyberface_obj(opened, out_dir: Path, name_hint: str='') -> dict:
    """Export the scene mesh as Wavefront OBJ + diffuse texture PNG.

    The OBJ references ``texture.png`` (written next to it) as its diffuse
    map, so any viewer (and the app's 3D preview) can load the pair directly.
    """
    mesh = extract_cyberface_mesh(opened)
    output = Path(out_dir)
    output.mkdir(parents=True, exist_ok=True)
    base = (name_hint or opened.path.stem or 'mesh').replace(' ', '_')
    lines = [f"# TKM cyberface mesh export ({mesh['vertices']} verts, {mesh['triangles']} tris)", 'mtllib mesh.mtl', f'o {base}']
    for x, y, z in mesh['positions']:
        lines.append(f'v {x:.6f} {y:.6f} {z:.6f}')
    for u, v in mesh['uvs']:
        lines.append(f'vt {u:.6f} {v:.6f}')
    for x, y, z in mesh['normals']:
        lines.append(f'vn {x:.4f} {y:.4f} {z:.4f}')
    lines.append('usemtl face_diffuse')
    idx = mesh['indices']
    for t in range(mesh['triangles']):
        i0, i1, i2 = idx[t * 3:t * 3 + 3]
        lines.append(f'f {i0 + 1}/{i0 + 1}/{i0 + 1} {i1 + 1}/{i1 + 1}/{i1 + 1} {i2 + 1}/{i2 + 1}/{i2 + 1}')
    obj_path = output / 'mesh.obj'
    obj_path.write_text('\n'.join(lines) + '\n', encoding='ascii')
    (output / 'mesh.mtl').write_text('newmtl face_diffuse\nKd 1.0 1.0 1.0\nmap_Kd texture.png\n', encoding='ascii')
    diffuse = None
    for texture in opened.textures:
        if texture.status == 'reference' or texture.payload_offset is None:
            continue
        if texture.format_id not in (15, 16):
            continue
        if diffuse is None or texture.width * texture.height > diffuse.width * diffuse.height:
            diffuse = texture
    texture_path = None
    if diffuse is not None:
        from . import core
        texture_path = output / 'texture.png'
        texture_path.write_bytes(core.texture_png(opened, diffuse))
    return {'obj': str(obj_path), 'texture': str(texture_path) if texture_path else None, 'vertices': mesh['vertices'], 'triangles': mesh['triangles']}
_N2KM_MAGIC = b'2KM\x00'
_N2KM_VERTEX_SIZE = 20
_N2KM_MAX_PARTS = 4096
_N2KM_MAX_VERTICES = 4000000
_N2KM_MAX_FACES = 8000000
_N2KM_FLOAT_LIMIT = 1000000.0
_N2KM_HEAD_MIN_VERTICES = 1000

def _n2km_clean_name(raw: bytes) -> str:
    return raw.split(b'\x00', 1)[0].decode('iso-8859-1', 'replace')

def parse_n2km(data: bytes) -> list[dict]:
    """Parse and fully validate an N2KM mesh file.

    Returns a list of parts: ``{"name", "positions", "uvs", "indices"}``.
    Raises ValueError on any structural or numeric violation.
    """
    if data is None or len(data) < 12:
        raise ValueError('N2KM file is too small')
    off = 0
    if data[:4] != _N2KM_MAGIC:
        raise ValueError('Invalid N2KM header; expected 2KM\x00')
    off = 4
    [part_count, vertex_size] = struct.unpack_from('<ii', data, off)
    off += 8
    if not 1 <= part_count <= _N2KM_MAX_PARTS:
        raise ValueError(f'Invalid N2KM part count: {part_count}')
    if vertex_size != _N2KM_VERTEX_SIZE:
        raise ValueError(f'Unsupported N2KM vertex size: {vertex_size}')
    parts = []
    for part_index in range(part_count):
        if len(data) - off < 12:
            raise ValueError('Truncated N2KM part header')
        name = _n2km_clean_name(data[off:off + 8])
        off += 8
        vertex_count = struct.unpack_from('<i', data, off)[0]
        off += 4
        if vertex_count < 0 or vertex_count > _N2KM_MAX_VERTICES:
            raise ValueError(f'Invalid vertex count: {vertex_count}')
        if vertex_count > (len(data) - off) // _N2KM_VERTEX_SIZE:
            raise ValueError(f'Invalid vertex count: {vertex_count}')
        positions = []
        uvs = []
        for _ in range(vertex_count):
            x, y, z, u, v = struct.unpack_from('<5f', data, off)
            off += _N2KM_VERTEX_SIZE
            for value in (x, y, z, u, v):
                if value != value or value in (float('inf'), float('-inf')):
                    raise ValueError(f'Invalid vertex data in part {name}')
                if abs(value) > _N2KM_FLOAT_LIMIT:
                    raise ValueError(f'Invalid vertex data in part {name}')
                continue
            positions.append((x, y, z))
            uvs.append((u, v))
        if len(data) - off < 4:
            raise ValueError('Truncated N2KM face count')
        face_count = struct.unpack_from('<i', data, off)[0]
        off += 4
        if face_count < 0 or face_count > _N2KM_MAX_FACES or face_count * 6 > len(data) - off:
            raise ValueError(f'Invalid face count: {face_count}')
        indices = []
        for _ in range(face_count):
            a, b, c = struct.unpack_from('<3H', data, off)
            off += 6
            if a >= vertex_count or b >= vertex_count or c >= vertex_count:
                raise ValueError(f'N2KM face index out of range in part {name}')
            indices.extend((a, b, c))
        parts.append({'name': name, 'positions': positions, 'uvs': uvs, 'indices': indices})
    if off != len(data):
        raise ValueError('Unexpected trailing data after N2KM')
    return parts

def n2km_to_obj(data: bytes) -> str:
    """Convert a validated N2KM file to OBJ text (SebTool's basis switch).

    The facial-shell part ``0-1`` is exported alone when present (that is
    what a HEAD mesh means); otherwise all parts are concatenated.  OBJ
    coordinates are N2KM (x, y, z) -> OBJ (x, -z, y).
    """
    parts = parse_n2km(data)
    shell = next((p for p in parts if p['name'] == '0-1'), None)
    if shell is not None:
        if len(shell['positions']) < _N2KM_HEAD_MIN_VERTICES:
            raise ValueError(f"N2KM part 0-1 is too small to be a HEAD mesh: {len(shell['positions'])} vertices")
        export_parts = [shell]
        header = '# TKM HEAD OBJ - source N2KM part 0-1 (facial shell only)\n'
    else:
        export_parts = parts
        header = '# TKM OBJ - source N2KM (all parts)\n'
    out = [header + '# coordinate basis: N2KM X,Y,Z -> OBJ X,-Z,Y\n']
    base = 1
    for part in export_parts:
        out.append(f"# part {part['name']}\n")
        for x, y, z in part['positions']:
            out.append(f'v {x:.6f} {-z:.6f} {y:.6f}\n')
        for u, v in part['uvs']:
            out.append(f'vt {u:.6f} {v:.6f}\n')
        for i in range(0, len(part['indices']), 3):
            a = part['indices'][i] + base
            b = part['indices'][i + 1] + base
            c = part['indices'][i + 2] + base
            out.append(f'f {a}/{a} {b}/{b} {c}/{c}\n')
        base += len(part['positions'])
    return ''.join(out)

def _obj_group_key(label: str) -> str:
    """SebTool's fuzzy group naming: anything hair-ish -> HAIR, head-ish -> HEAD."""
    import re
    norm = re.sub('[^a-z0-9]+', '_', (label or '').lower())
    if 'hair' in norm or norm == 'ha' or norm.startswith('hair_'):
        return 'HAIR'
    if 'head' in norm or norm == 'face' or norm.startswith('head_'):
        return 'HEAD'
    return ''

def _obj_face_vertices(line: str) -> list[int]:
    text = line.strip()
    if text.startswith('fo '):
        text = text[3:].strip()
    elif text.startswith('f '):
        text = text[2:].strip()
    elif text == 'f':
        return []
    out = []
    for token in text.split():
        if not token:
            continue
        slash = token.find('/')
        if slash >= 0:
            token = token[:slash]
        try:
            out.append(int(token))
        except ValueError:
            return []
    return out

def parse_obj_preview(obj_text: str) -> dict:
    """Parse an OBJ file into GPU-ready buffers for the interactive 3D preview.

    Uses only v/vt/vn/f/o/g/usemtl statements; every other line is ignored.
    Faces are re-indexed against the observed v/vt/vn tables, polygons with
    more than 3 vertices are fan-triangulated, and faces referencing missing
    normals or UVs get zeroed attributes so a single bad line cannot abort the
    whole preview.  Raises ValueError for empty files or files without faces.
    """
    if isinstance(obj_text, bytes):
        obj_text = obj_text.decode('utf-8', 'replace')
    verts = []
    uvs = []
    nrms = []
    groups = {}
    current = 'default'
    tri_total = 0
    for raw in obj_text.replace('\r', '').split('\n'):
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split()
        tag = parts[0]
        if tag == 'v':
            if len(parts) >= 4:
                try:
                    verts.append((float(parts[1]), float(parts[2]), float(parts[3])))
                    continue
                except ValueError:
                    continue
        if tag == 'vt':
            if len(parts) >= 3:
                try:
                    uvs.append((float(parts[1]), float(parts[2])))
                    continue
                except ValueError:
                    continue
        if tag == 'vn':
            if len(parts) >= 4:
                try:
                    nrms.append((float(parts[1]), float(parts[2]), float(parts[3])))
                    continue
                except ValueError:
                    continue
        if tag in ('o', 'g'):
            if len(parts) > 1:
                current = ' '.join(parts[1:])
            continue
        if tag == 'usemtl' and current == 'default':
            if len(parts) > 1:
                current = parts[1]
            continue
        if tag == 'f':
            idx = []
            for token in parts[1:]:
                if not token:
                    continue
                slash = token.find('/')
                if slash >= 0:
                    token = token[:slash]
                try:
                    n = int(token)
                except ValueError:
                    idx = []
                    break
                if n < 0:
                    n += len(verts) + 1
                if n < 1 or n > len(verts):
                    idx = []
                    break
                idx.append(n - 1)
            if len(idx) < 3:
                continue
            tris = groups.setdefault(current, [])
            for k in range(1, len(idx) - 1):
                tris.append((idx[0], idx[k], idx[k + 1]))
                tri_total += 1
    if not tri_total:
        raise ValueError("OBJ has no usable faces (need 'v' vertices and 'f' faces).")
    positions = []
    normals = []
    texcoords = []
    indices = []
    meta = []
    for gname, tris in groups.items():
        if not tris:
            continue
        base = len(positions)
        used = set()
        for a, b, c in tris:
            used.update((a, b, c))
        remap = {}
        for v in sorted(used):
            remap[v] = len(remap)
        for vi in sorted(used):
            v = verts[vi]
            positions.append(v)
            normals.append(nrms[vi] if vi < len(nrms) else (0.0, 1.0, 0.0))
            texcoords.append(uvs[vi] if vi < len(uvs) else (0.0, 0.0))
        for a, b, c in tris:
            indices.extend((base + remap[a], base + remap[b], base + remap[c]))
        meta.append({'name': gname, 'triangles': len(tris), 'vertices': len(remap)})
    return {'vertices': len(positions), 'triangles': tri_total, 'positions': positions, 'normals': normals, 'uvs': texcoords, 'indices': indices, 'groups': meta}

def split_obj_head_hair(obj_text: str) -> dict:
    """Split an OBJ with named HEAD and HAIR groups into two standalone OBJs.

    Both outputs preserve the original vertex/UV/normal numbering (indices are
    NOT remapped), matching SebTool's behaviour.  Raises ValueError unless both
    groups exist and carry faces.
    """
    import io
    import zipfile
    lines = obj_text.replace('\r', '').split('\n')
    head_lines = []
    hair_lines = []
    prologue = []
    group = ''
    seen_head = seen_hair = seen_group = False
    for line in lines:
        trimmed = line.strip()
        if trimmed.startswith('o ') or trimmed.startswith('g '):
            label = trimmed[2:].strip() if len(trimmed) > 2 else ''
            key = _obj_group_key(label)
            if key == 'HEAD':
                seen_head = True
            if key == 'HAIR':
                seen_hair = True
            seen_group = True
            group = key
            continue
        if trimmed.startswith('f ') or trimmed.startswith('fo ') or trimmed == 'f':
            if group == 'HEAD':
                head_lines.append(line)
            elif group == 'HAIR':
                hair_lines.append(line)
            continue
        if trimmed.startswith(('v ', 'vt ', 'vn ', 'vp ', '#', 's ', 'mtllib ', 'usemtl ')):
            prologue.append(line)
    if not seen_group or not seen_head or (not seen_hair):
        raise ValueError('OBJ must contain named HEAD and HAIR objects/groups with faces. Example: g HEAD ... faces ... g HAIR ... faces.')
    if not head_lines or not hair_lines:
        raise ValueError('OBJ must contain named HEAD and HAIR objects/groups with faces.')

    def build(face_lines: list[str], tag: str) -> bytes:
        buf = io.StringIO()
        buf.write(f'# TKM OBJ -> {tag} (faces assigned to {tag} only)\n')
        buf.write('\n'.join(prologue).rstrip('\n') + '\n')
        buf.write('\n'.join(face_lines).rstrip('\n') + '\n')
        return buf.getvalue().encode('utf-8')
    archive = io.BytesIO()
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_STORED) as zf:
        zf.writestr('HEAD.obj', build(head_lines, 'HEAD'))
        zf.writestr('HAIR.obj', build(hair_lines, 'HAIR'))
        zf.writestr('README.txt', 'TKM OBJ -> HEAD + HAIR\n\nHEAD.obj contains only the faces assigned to HEAD.\nHAIR.obj contains only the faces assigned to HAIR.\nVertex / UV / normal numbering is preserved from the source OBJ.\n')
    return {'zip_bytes': archive.getvalue(), 'head_faces': len(head_lines), 'hair_faces': len(hair_lines)}

def build_n2km(parts: list[dict]) -> bytes:
    """Serialize parts to N2KM bytes (cmomoney plugin-compatible).

    Each part: ``{"name": str(<=8 chars), "positions": [(x,y,z)...],
    "uvs": [(u,v)...], "indices": [a,b,c,...]}`` with positions already in
    the GAME basis (no axis swap applied here).
    """
    if not parts:
        raise ValueError('N2KM needs at least one part')
    out = bytearray()
    out += _N2KM_MAGIC
    out += struct.pack('<2i', len(parts), _N2KM_VERTEX_SIZE)
    for part in parts:
        name = (part.get('name') or 'part').strip()
        if not name:
            name = 'part'
        if len(name) > 8:
            name = name[:8]
        positions = part.get('positions') or []
        uvs = part.get('uvs') or []
        indices = part.get('indices') or []
        vertex_count = len(positions)
        if vertex_count == 0:
            raise ValueError(f'N2KM part {name!r} has no vertices')
        if vertex_count > _N2KM_MAX_VERTICES:
            raise ValueError(f'N2KM part {name!r} too big: {vertex_count}')
        if len(uvs) != vertex_count:
            raise ValueError(f'N2KM part {name!r}: {len(uvs)} uvs for {vertex_count} vertices')
        if len(indices) == 0 or len(indices) % 3:
            raise ValueError(f'N2KM part {name!r}: index list must be triangles')
        if max(indices) >= vertex_count:
            raise ValueError(f'N2KM part {name!r}: index out of range')
        out += name.encode('iso-8859-1', 'replace')[:8].ljust(8, b'\x00')
        out += struct.pack('<i', vertex_count)
        for v in range(vertex_count):
            x, y, z = positions[v]
            [u, vv] = uvs[v]
            for value in (x, y, z, u, vv):
                if value != value or value in (float('inf'), float('-inf')):
                    raise ValueError(f'N2KM part {name!r}: bad vertex data')
                if abs(value) > _N2KM_FLOAT_LIMIT:
                    raise ValueError(f'N2KM part {name!r}: vertex out of range')
                continue
            out += struct.pack('<5f', x, y, z, u, vv)
        out += struct.pack('<i', len(indices) // 3)
        for t in range(0, len(indices), 3):
            out += struct.pack('<3H', indices[t], indices[t + 1], indices[t + 2])
    return bytes(out)

def obj_to_n2km(obj_text: str, part_name: str='0-1') -> bytes:
    """Convert OBJ text to a single-part N2KM (the Blender plugin's format).

    OBJ positions are in the plugin's post-import basis (our OBJ exports use
    it too), so the inverse of the plugin's import swap is applied:
    OBJ (x, y, z) -> N2KM (x, z, -y). Negative OBJ indices are resolved;
    polygons are fan-triangulated; UVs are required (faces are v/vt pairs
    like every OBJ this engine writes).
    """
    positions = []
    uvs = []
    triangles = []
    for raw in obj_text.splitlines():
        line = raw.strip()
        if line.startswith('v '):
            fields = line.split()
            if len(fields) < 4:
                raise ValueError('OBJ vertex line needs 3 coordinates')
            x, y, z = (float(f) for f in fields[1:4])
            positions.append((x, z, -y))
            continue
        if line.startswith('vt '):
            fields = line.split()
            if len(fields) < 3:
                raise ValueError('OBJ vt line needs 2 coordinates')
            uvs.append((float(fields[1]), float(fields[2])))
            continue
        if line.startswith('f '):
            corners = _obj_face_vertices(line)
            if len(corners) < 3:
                raise ValueError('OBJ face needs at least 3 vertices')
            zero = []
            for i in corners:
                idx = i - 1 if i > 0 else len(positions) + i
                if idx < 0 or idx >= len(positions):
                    raise ValueError('OBJ face index out of range')
                zero.append(idx)
            for k in range(1, len(zero) - 1):
                triangles.extend((zero[0], zero[k], zero[k + 1]))
    if not positions:
        raise ValueError('OBJ has no vertices')
    if not uvs:
        raise ValueError('OBJ has no UVs — export the mesh with UVs enabled')
    if not triangles:
        raise ValueError('OBJ has no faces')
    if len(uvs) != len(positions):
        raise ValueError(f'OBJ has {len(uvs)} vt for {len(positions)} v — N2KM needs one UV per vertex; export with per-vertex UVs')
    return build_n2km([{'name': part_name, 'positions': positions, 'uvs': uvs, 'indices': triangles}])

def cyberface_to_n2km(opened) -> bytes:
    """Serialize a cyberface scene to N2KM for the Blender plugin.

    Positions are stored with the same (x, -z, y) swap the plugin applies on
    import, so the plugin's own export inverse (x, z, -y) brings them back
    and our injector restores the scene basis exactly — i.e. the full
    app → Blender → app round-trip is lossless. (Blender's up-axis differs
    from the in-app preview by that rigid rotation; the shape is identical.)
    """
    mesh = extract_cyberface_mesh(opened)
    positions = [(x, -z, y) for x, y, z in mesh['positions']]
    return build_n2km([{'name': '0-1', 'positions': positions, 'uvs': [(u, v) for u, v in mesh['uvs']], 'indices': list(mesh['indices'])}])

def n2km_write_into_scene(opened, n2km_data: bytes) -> dict:
    """Inject a Blender-exported N2KM into an open cyberface scene.

    The plugin's import applies (x, -z, y) to the file's game-basis data, so
    N2KM positions are converted back to the scene's basis with the inverse
    (x, z, -y). Vertex/UV data is then rewritten in place through
    ``update_mesh_data`` (which rebuilds the strip buffer when the topology
    changed and refuses vertex growth beyond the scene's allocation).
    """
    parts = parse_n2km(n2km_data)
    shell = next((p for p in parts if p['name'] == '0-1'), None) or parts[0]
    positions = [(x, z, -y) for x, y, z in shell['positions']]
    uvs = [(u, v) for u, v in shell['uvs']]
    indices = list(shell['indices'])
    current = extract_cyberface_mesh(opened)
    original_count = current['vertices']
    new_count = len(positions)
    if new_count > original_count:
        raise ValueError(f'N2KM has {new_count} vertices but the scene only holds {original_count} — adding vertices is not supported; edit in place or delete first')
    same_topology = new_count == original_count and indices == list(current['indices'])
    remap = None
    if not same_topology:
        remap = list(range(original_count))
        if new_count < original_count:
            remap = list(range(new_count)) + [-1] * (original_count - new_count)
    normals = _recompute_normals(positions, indices)
    return update_mesh_data(opened, [c for p in positions for c in p], [c for n in normals for c in n], [c for uv in uvs for c in uv], indices_u16=None if same_topology else indices, remap_u16=None if same_topology else remap)

def _recompute_normals(positions, indices):
    """Area-weighted vertex normals (pure Python, ~3k-vert meshes are fine)."""
    normals = [(0.0, 0.0, 0.0)] * len(positions)
    acc = [[0.0, 0.0, 0.0] for _ in positions]
    for t in range(0, len(indices), 3):
        a, b, c = (indices[t], indices[t + 1], indices[t + 2])
        ax, ay, az = positions[a]
        bx, by, bz = positions[b]
        cx, cy, cz = positions[c]
        ux, uy, uz = (bx - ax, by - ay, bz - az)
        vx, vy, vz = (cx - ax, cy - ay, cz - az)
        nx, ny, nz = (uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx)
        for i in (a, b, c):
            acc[i][0] += nx
            acc[i][1] += ny
            acc[i][2] += nz
    for i, (x, y, z) in enumerate(acc):
        length = (x * x + y * y + z * z) ** 0.5
        if length > 1e-12:
            normals[i] = (x / length, y / length, z / length)
        else:
            normals[i] = (0.0, 0.0, 1.0)
    return normals
