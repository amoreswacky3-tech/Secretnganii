package com.nocluetools.prov1;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import java.io.*;
import java.util.HashMap;
import java.util.Iterator;
import org.json.JSONObject;
import org.json.JSONArray;

import com.chaquo.python.Python;
import com.chaquo.python.PyObject;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends AppCompatActivity {

    private TextView tvLog;
    private ListView listObbFiles;
    private ArrayAdapter<String> listAdapter;
    private HashMap<String, String> realNamesMap = new HashMap<>();
    private PyObject bridge;

    private final int REQ_OBB = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvLog = findViewById(R.id.tvLog);
        listObbFiles = findViewById(R.id.listObbFiles);
        Button btnObb = findViewById(R.id.btnOpenObb);
        Button btnIff = findViewById(R.id.btnOpenIff);

        // Setup the ListView
        listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        listObbFiles.setAdapter(listAdapter);

        // Start Python
        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }
        Python py = Python.getInstance();
        bridge = py.getModule("noclue2k_bridge");

        // Load the CSV of real names in the background
        new Thread(this::loadCsvNames).start();

        btnObb.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("*/*");
            startActivityForResult(intent, REQ_OBB);
        });

        btnIff.setOnClickListener(v -> log("IFF button clicked. Logic coming soon."));
    }

    // --- READ THE CSV FILE ---
    private void loadCsvNames() {
        try {
            InputStream is = getAssets().open("nba2k20_Real_names.csv");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = reader.readLine()) != null) {
                // Assuming format is: hash,name (e.g., 000383a3,LeBron James)
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    realNamesMap.put(parts[0].trim().toLowerCase(), parts[1].trim());
                }
            }
            reader.close();
            runOnUiThread(() -> log("CSV Real Names Loaded: " + realNamesMap.size() + " entries."));
        } catch (Exception e) {
            runOnUiThread(() -> log("Failed to load CSV: " + e.getMessage()));
        }
    }

    // --- OPEN OBB LOGIC ---
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && data != null && requestCode == REQ_OBB) {
            Uri uri = data.getData();
            if (uri != null) {
                File realFile = copyUriToFile(uri, "temp.obb");
                if (realFile != null) {
                    log("Selected OBB: " + realFile.getName());
                    runOpenObb(realFile.getAbsolutePath());
                }
            }
        }
    }

    private void runOpenObb(String path) {
        log("Parsing OBB... Please wait.");
        new Thread(() -> {
            try {
                String workDir = getFilesDir().getAbsolutePath() + "/work";
                new File(workDir).mkdirs(); 

                // Call Python bridge
                PyObject result = bridge.callAttr("open_obb_bridge", path, workDir);
                String jsonString = result.toString();
                
                // Process the JSON result
                parseAndDisplayObb(jsonString);

            } catch (Exception e) {
                runOnUiThread(() -> log("PYTHON ERROR: " + e.getMessage()));
            }
        }).start();
    }

    // --- PARSE PYTHON JSON AND UPDATE LIST ---
    private void parseAndDisplayObb(String jsonString) {
        try {
            JSONObject json = new JSONObject(jsonString);
            if (!json.getBoolean("ok")) {
                runOnUiThread(() -> log("Python Error: " + json.optString("error")));
                return;
            }

            JSONArray rows = json.getJSONArray("rows");
            runOnUiThread(() -> {
                listAdapter.clear();
                log("Found " + rows.length() + " files inside OBB.");
            });

            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.getJSONObject(i);
                String hashName = row.optString("name", "unknown").toLowerCase();
                int index = row.optInt("index", i);
                
                // Look up real name in our CSV map
                String realName = realNamesMap.getOrDefault(hashName, hashName);

                // Format: [0] LeBron James (000383a3)
                String displayString = "[" + index + "] " + realName + " (" + hashName + ")";

                // Add to UI list
                runOnUiThread(() -> listAdapter.add(displayString));
            }

        } catch (Exception e) {
            runOnUiThread(() -> log("JSON Parse Error: " + e.getMessage()));
        }
    }

    private void log(String message) {
        runOnUiThread(() -> {
            tvLog.append(message + "\n");
            // Auto-scroll to bottom
            if (tvLog.getParent() instanceof ScrollView) {
                ((ScrollView) tvLog.getParent()).post(() -> ((ScrollView) tvLog.getParent()).fullScroll(ScrollView.FOCUS_DOWN));
            }
        });
    }

    private File copyUriToFile(Uri uri, String fileName) {
        try {
            File destFile = new File(getCacheDir(), fileName);
            InputStream inputStream = getContentResolver().openInputStream(uri);
            FileOutputStream outputStream = new FileOutputStream(destFile);
            byte[] buffer = new byte[8192];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            outputStream.close();
            inputStream.close();
            return destFile;
        } catch (Exception e) {
            log("Failed to copy file: " + e.getMessage());
            return null;
        }
    }
}