package com.nocluetools.prov1;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONObject;
import org.json.JSONArray;

import com.chaquo.python.Python;
import com.chaquo.python.PyObject;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends AppCompatActivity {

    private TextView tvLog;
    private ListView listFiles;
    private ArrayAdapter<String> listAdapter;
    private HashMap<String, String> realNamesMap = new HashMap<>();
    private PyObject bridge;

    private final int REQ_OBB = 1;
    private final int REQ_IFF = 2;
    
    private String currentObbSession = "";
    private ArrayList<Integer> currentIndices = new ArrayList<>();
    
    private boolean isAudioExplorerMode = false; 
    private boolean insideBinFile = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvLog = findViewById(R.id.tvLog);
        listFiles = findViewById(R.id.listObbFiles);
        
        com.google.android.material.card.MaterialCardView btnObb = findViewById(R.id.btnOpenObb);
        com.google.android.material.card.MaterialCardView btnIff = findViewById(R.id.btnOpenIff);
        com.google.android.material.card.MaterialCardView btnAudio = findViewById(R.id.btnOpenAudio);
        com.google.android.material.card.MaterialCardView btnExplorer = findViewById(R.id.btnAudioExplorer);

        listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        listFiles.setAdapter(listAdapter);

        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }
        Python py = Python.getInstance();
        bridge = py.getModule("noclue2k_bridge");

        // Load the CSV in the background
        new Thread(this::loadCsvNames).start();

        // 1. Open OBB (Standard view)
        btnObb.setOnClickListener(v -> {
            isAudioExplorerMode = false;
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("*/*");
            startActivityForResult(intent, REQ_OBB);
        });

        // 2. Open IFF
        btnIff.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("*/*");
            startActivityForResult(intent, REQ_IFF);
        });

        // 3. Audio from OBB (Deep scan)
        btnAudio.setOnClickListener(v -> {
            if (currentObbSession.isEmpty()) {
                log("Please Open OBB first!");
                return;
            }
            log("Deep scanning OBB for OGGs...");
            new Thread(() -> {
                try {
                    PyObject result = bridge.callAttr("scan_obb_audio_bridge", currentObbSession);
                    runOnUiThread(() -> log("Audio scan complete! (Check Log)"));
                } catch (Exception e) {
                    runOnUiThread(() -> log("Error: " + e.getMessage()));
                }
            }).start();
        });

        // 4. Audio Explorer (.bin view)
        btnExplorer.setOnClickListener(v -> {
            if (currentObbSession.isEmpty()) {
                log("Please Open OBB first!");
                return;
            }
            isAudioExplorerMode = true;
            log("Filtering for .bin files...");
            // We need to re-parse the OBB if we already have the data, but for simplicity, just ask user to open OBB again if needed.
        });

        // Handle ListView clicks
        listFiles.setOnItemClickListener((parent, view, position, id) -> {
            if (insideBinFile) {
                log("Selected OGG at offset: " + currentIndices.get(position));
                // Logic to extract/play audio goes here
            } else {
                if (isAudioExplorerMode) {
                    int obbIndex = currentIndices.get(position);
                    log("Opening .bin at index " + obbIndex + "...");
                    extractAndScanBin(obbIndex);
                } else {
                    log("Selected OBB Entry: " + listAdapter.getItem(position));
                }
            }
        });
    }

    // --- READ THE CSV FILE ---
    private void loadCsvNames() {
        try {
            InputStream is = getAssets().open("nba2k20_Real_names.csv");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    realNamesMap.put(parts[0].trim().toLowerCase(), parts[1].trim());
                }
            }
            reader.close();
            runOnUiThread(() -> log("CSV Loaded: " + realNamesMap.size() + " names."));
        } catch (Exception e) {
            runOnUiThread(() -> log("CSV Error: " + e.getMessage()));
        }
    }

    // --- OPEN OBB LOGIC ---
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                if (requestCode == REQ_OBB) {
                    File realFile = copyUriToFile(uri, "temp.obb");
                    if (realFile != null) {
                        insideBinFile = false;
                        runOpenObb(realFile.getAbsolutePath());
                    }
                } else if (requestCode == REQ_IFF) {
                    File realFile = copyUriToFile(uri, "temp.iff");
                    if (realFile != null) {
                        log("IFF Selected: " + realFile.getAbsolutePath());
                        // IFF parsing logic goes here later
                    }
                }
            }
        }
    }

    private void runOpenObb(String path) {
        log("Parsing OBB... Please wait.");
        new Thread(() -> {
            try {
                String workDir = getFilesDir().getAbsolutePath() + "/work";
                new File(workDir).mkdirs(); 
                PyObject result = bridge.callAttr("open_obb_bridge", path, workDir);
                parseAndDisplayObb(result.toString());
            } catch (Exception e) {
                runOnUiThread(() -> log("PYTHON ERROR: " + e.getMessage()));
            }
        }).start();
    }

    // --- PARSE PYTHON JSON AND UPDATE LIST ---
    private void parseAndDisplayObb(String jsonString) {
        try {
            JSONObject json = new JSONObject(jsonString);
            if (!json.getBoolean("ok")) {
                runOnUiThread(() -> log("Python Error: " + json.optString("error")));
                return;
            }

            currentObbSession = json.getString("session_id");
            JSONArray rows = json.getJSONArray("rows");
            currentIndices.clear();

            ArrayList<String> filteredItems = new ArrayList<>();
            int foundBins = 0;

            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.getJSONObject(i);
                String hashName = row.optString("name", "unknown").toLowerCase();
                int index = row.optInt("index", i);
                
                String realName = realNamesMap.getOrDefault(hashName, hashName);

                // FILTER LOGIC
                if (isAudioExplorerMode) {
                    // Only show .bin files or audio files
                    if (realName.toLowerCase().contains(".bin") || realName.toLowerCase().contains("audio")) {
                        currentIndices.add(index);
                        filteredItems.add("[" + index + "] " + realName);
                        foundBins++;
                    }
                } else {
                    // Show all files
                    currentIndices.add(index);
                    filteredItems.add("[" + index + "] " + realName);
                }
            }
            
            final int finalFound = foundBins;
            runOnUiThread(() -> {
                listAdapter.clear();
                listAdapter.addAll(filteredItems);
                if (isAudioExplorerMode) {
                    log("Filtered OBB. Found " + finalFound + " .bin files.");
                } else {
                    log("OBB Opened. Found " + filteredItems.size() + " total files.");
                }
            });

        } catch (Exception e) {
            runOnUiThread(() -> log("JSON Error: " + e.getMessage()));
        }
    }

    // --- EXTRACT AND SCAN .BIN FOR OGGs ---
    private void extractAndScanBin(int obbIndex) {
        new Thread(() -> {
            try {
                String workDir = getFilesDir().getAbsolutePath() + "/work";
                String binPath = workDir + "/temp_audio.bin";

                // 1. Extract the .bin file from the OBB using the bridge
                bridge.callAttr("extract_iff_bridge", currentObbSession, obbIndex, workDir);
                
                // 2. Scan the extracted file for OGGs
                PyObject scanResult = bridge.callAttr("scan_single_bin_for_audio", binPath);
                JSONObject json = new JSONObject(scanResult.toString());

                if (json.getBoolean("ok")) {
                    JSONArray oggs = json.getJSONArray("oggs");
                    insideBinFile = true;
                    currentIndices.clear();

                    ArrayList<String> oggList = new ArrayList<>();
                    for (int i = 0; i < oggs.length(); i++) {
                        int offset = oggs.getJSONObject(i).getInt("offset");
                        currentIndices.add(offset);
                        oggList.add("OGG " + (i+1) + " (Offset: " + offset + ")");
                    }

                    runOnUiThread(() -> {
                        listAdapter.clear();
                        listAdapter.addAll(oggList);
                        log("Found " + oggs.length() + " OGGs inside this .bin!");
                    });
                } else {
                    runOnUiThread(() -> log("Scan Error: " + json.optString("error")));
                }

            } catch (Exception e) {
                runOnUiThread(() -> log("Extraction ERROR: " + e.getMessage()));
            }
        }).start();
    }

    // --- HELPER METHODS ---
    private void log(String message) {
        runOnUiThread(() -> {
            tvLog.append(message + "\n");
            if (tvLog.getParent() instanceof ScrollView) {
                ((ScrollView) tvLog.getParent()).post(() -> ((ScrollView) tvLog.getParent()).fullScroll(ScrollView.FOCUS_DOWN));
            }
        });
    }

    private File copyUriToFile(Uri uri, String fileName) {
        try {
            File destFile = new File(getCacheDir(), fileName);
            InputStream inputStream = getContentResolver().openInputStream(uri);
            FileOutputStream outputStream = new FileOutputStream(destFile);
            byte[] buffer = new byte[8192];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            outputStream.close();
            inputStream.close();
            return destFile;
        } catch (Exception e) {
            log("Failed to copy file: " + e.getMessage());
            return null;
        }
    }
}