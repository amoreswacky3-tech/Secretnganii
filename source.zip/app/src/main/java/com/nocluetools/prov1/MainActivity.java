package com.nocluetools.prov1;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONObject;
import org.json.JSONArray;

import com.chaquo.python.Python;
import com.chaquo.python.PyObject;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends AppCompatActivity {

    private TextView tvLog;
    private ListView listFiles;
    private ArrayAdapter<String> listAdapter;
    private HashMap<String, String> realNamesMap = new HashMap<>();
    private PyObject bridge;

    private final int REQ_OBB = 1;
    private final int REQ_IFF = 2;
    
    private String currentObbSession = "";
    private ArrayList<Integer> currentIndices = new ArrayList<>();
    
    // Mode flags
    private boolean isAudioExplorerMode = false; 
    private boolean insideBinFile = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvLog = findViewById(R.id.tvLog);
        listFiles = findViewById(R.id.listObbFiles);
        
        com.google.android.material.card.MaterialCardView btnObb = findViewById(R.id.btnOpenObb);
        com.google.android.material.card.MaterialCardView btnIff = findViewById(R.id.btnOpenIff);
        com.google.android.material.card.MaterialCardView btnAudio = findViewById(R.id.btnOpenAudio);
        com.google.android.material.card.MaterialCardView btnExplorer = findViewById(R.id.btnAudioExplorer);

        listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        listFiles.setAdapter(listAdapter);

        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }
        Python py = Python.getInstance();
        bridge = py.getModule("noclue2k_bridge");

        new Thread(this::loadCsvNames).start();

        // 1. Open OBB (Standard)
        btnObb.setOnClickListener(v -> {
            isAudioExplorerMode = false;
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("*/*");
            startActivityForResult(intent, REQ_OBB);
        });

        // 2. Open IFF
        btnIff.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("*/*");
            startActivityForResult(intent, REQ_IFF);
        });

        // 3. Open Audio (Scan whole OBB for OGGs)
        btnAudio.setOnClickListener(v -> {
            if (currentObbSession.isEmpty()) {
                log("Please Open OBB first!");
                return;
            }
            log("Deep scanning OBB for OGGs...");
            new Thread(() -> {
                try {
                    PyObject result = bridge.callAttr("scan_obb_audio_bridge", currentObbSession);
                    // Note: The bridge returns a massive JSON with all OGG offsets
                    // You will need to parse this JSON and add to listAdapter
                    runOnUiThread(() -> log("Audio scan complete! (Check Log)"));
                } catch (Exception e) {
                    runOnUiThread(() -> log("Error: " + e.getMessage()));
                }
            }).start();
        });

        // 4. Audio Explorer (Filter .bin -> Tap to see OGGs inside)
        btnExplorer.setOnClickListener(v -> {
            if (currentObbSession.isEmpty()) {
                log("Please Open OBB first!");
                return;
            }
            isAudioExplorerMode = true;
            log("Filtering for .bin files...");
            // Re-trigger the list display using the cached session
            // We will just reload the OBB rows logic here
        });

        // Handle ListView clicks
        listFiles.setOnItemClickListener((parent, view, position, id) -> {
            if (insideBinFile) {
                log("Selected OGG at offset: " + currentIndices.get(position));
                // Logic to extract/play audio goes here
            } else {
                if (isAudioExplorerMode) {
                    int obbIndex = currentIndices.get(position);
                    log("Opening .bin at index " + obbIndex + "...");
                    extractAndScanBin(obbIndex);
                } else {
                    log("Selected OBB Entry: " + listAdapter.getItem(position));
                }
            }
        });
    }

    // ... Keep your loadCsvNames(), onActivityResult(), runOpenObb(), parseAndDisplayObb() and extractAndScanBin() methods exactly as they are from the previous message ...
    // (Just make sure to check if isAudioExplorerMode is true inside parseAndDisplayObb to filter for .bin files)
    
    // Helper to print to log
    private void log(String message) {
        runOnUiThread(() -> {
            tvLog.append(message + "\n");
            if (tvLog.getParent() instanceof ScrollView) {
                ((ScrollView) tvLog.getParent()).post(() -> ((ScrollView) tvLog.getParent()).fullScroll(ScrollView.FOCUS_DOWN));
            }
        });
    }
    
    // ... Include the copyUriToFile() method here ...
}