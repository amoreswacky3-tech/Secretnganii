"""noclue2k_bridge - the thin Python entry point the Android app calls.

The Kotlin side only ever passes plain lists/strings and gets back a JSON
string, so no Python objects ever leak across the boundary.

Editor flow (one OBB -> IFF -> textures -> save -> rebuild):

    open_obb(obb_path, work_dir)       -> {"ok", "session_id", "rows": [...]}
    extract_iff(obb_session, index, out_dir) -> {"ok", "path", "name", "size"}
    open_iff(path)                     -> {"ok", "session_id", "files": [...]}
    preview_png(session_id, f, n)      -> PNG bytes (or {"ok": false, ...})
    export_texture_png(session_id, f, n, out_path) -> {"ok", "path", ...}
    replace_texture(session_id, f, n, png_path)    -> {"ok", "change": {...}}
    save_iff(session_id, f, out_path)  -> {"ok", "output", ...}
    stage_iff(obb_session, index, edited_iff_path) -> {"ok", "staged": {...}}
    rebuild_obb(obb_session, out_path) -> {"ok", "output_obb", ...}
    close_iff(session_id) / close_obb(obb_session)

Batch flow (several standalone IFFs + PNGs -> one operation):

    run_batch(iff_paths, png_paths, out_dir) -> {"ok", "replaced", "exported"}
"""

import json
import traceback
from pathlib import Path
from iffengine import _obb_session, _session, apply_replacements, close_obb_session, close_session, core, export_modified, export_obb_entry, extract_audio_stream, extract_obb_iff, list_bank_textures, manual_resolve_texture, new_session, obb_rows, open_obb, preview_png, raw_texture_to_file, replace_audio_stream_in_obb, replace_obb_entries, replace_texture, save_iff, save_obb, session_summary, scan_obb_assets, scan_obb_audio, scan_obb_cyberfaces, stage_obb_iff, template_batch_replace, texture_png_to_file, texture_thumb_to_file


def _report(fn, *args):
    """Run a callable and return its result as a JSON string, or an error."""
    try:
        from iffengine.integrity import ensure_verified
        ensure_verified()
        return json.dumps({'ok': True,**fn(*args)}, default=str)
    except Exception as error:
        return json.dumps({'ok': False, 'error': str(error), 'traceback': traceback.format_exc()}, default=str)


def open_obb_bridge(obb_path, work_dir):
    return _report(open_obb, obb_path, work_dir)


def extract_iff_bridge(obb_session, index, out_dir):
    return _report(extract_obb_iff, obb_session, int(index), out_dir)


def close_obb_bridge(obb_session):
    return _report(close_obb_session, obb_session)


def obb_rows_bridge(obb_session):
    """Return the current OBB entry list with staging status."""
    return _report(obb_rows, obb_session)


def scan_cyberfaces_bridge(obb_session, work_dir):
    """Deep-scan the open OBB for cyberface scene/bank entries."""
    return _report(scan_obb_cyberfaces, obb_session, work_dir)


def scan_assets_bridge(obb_session, work_dir):
    """Deep-scan the open OBB and categorize every entry as a modding asset."""
    return _report(scan_obb_assets, obb_session, work_dir)


def session_summary_bridge(session_id):
    """Live file + texture inventory for one open IFF session (3D editor's
    texture panel). Reads the CURRENT session state, so replaced textures and
    fresh role labels are reflected without reopening the file."""
    return _report(session_summary, session_id)


def open_iff_bridge(path, obb_session=None):
    """Open one IFF; when opened from an OBB session, resolve cyberface scene
    references (shared face atlases) against that OBB's texture banks so the
    scene shows the actual face textures."""

    def run():
        obb_path = None
        if obb_session:
            obb_path = str(_obb_session(obb_session).path)
        created = new_session([path], obb_path=obb_path)
        return {'session_id': created['session_id'], 'files': created['files']}

    return _report(run)


def preview_png_bridge(session_id, file_index, texture_number):
    """Return raw PNG bytes; raises so Kotlin can surface the error directly."""
    try:
        return preview_png(session_id, int(file_index), int(texture_number))
    except ValueError as error:
        error_msg = str(error)
        if 'Referenced texture' in error_msg or 'reference' in error_msg.lower():
            try:
                session = _session(session_id)
                opened = session['opened'][int(file_index)]
                summary = core.face_reference_summary(opened)
                return json.dumps({'ok': False, 'error': error_msg, 'is_reference': True, 'reference_summary': summary})
            except Exception:
                pass
        raise


def export_texture_png_bridge(session_id, file_index, texture_number, out_path):
    """Write one texture's PNG to ``out_path`` (streamed, bounded memory)."""
    return _report(texture_png_to_file, session_id, int(file_index), int(texture_number), out_path)


def export_texture_thumb_bridge(session_id, file_index, texture_number, out_path, max_dim):
    """Write one texture's downscaled thumbnail PNG to ``out_path``."""
    return _report(texture_thumb_to_file, session_id, int(file_index), int(texture_number), out_path, int(max_dim))


def export_raw_resource_bridge(session_id, file_index, texture_number, out_path):
    """Write the texture's original binary resource bytes to ``out_path``."""
    return _report(raw_texture_to_file, session_id, int(file_index), int(texture_number), out_path)


def replace_texture_bridge(session_id, file_index, texture_number, png_path):
    return _report(replace_texture, session_id, int(file_index), int(texture_number), png_path)


def uvremap_transfer_bridge(session_id, file_index, texture_number, png_path, src_layout_id, dst_layout_id,
                           target_width=0,
                           target_height=0):
    """Warp a painted atlas from one UV layout to another and import it.

    Reads the user's edited PNG (painted against src_layout_id), runs the
    piecewise-affine transfer (source layout -> target layout), resamples it
    onto the destination texture's exact dimensions, and imports the result
    (dimension-checked, alpha-preserving).
    """

    def run():
        from iffengine import uvremap
        session = _session(session_id)
        opened = session['opened'][int(file_index)]
        from iffengine import core as _core
        from iffengine.__init__ import _texture_at
        texture = _texture_at(opened, int(texture_number))
        png_bytes = Path(png_path).read_bytes()
        width, height, rgba = _core.pngio.read_png_rgba(png_bytes)
        warped = uvremap.transfer_between_games(rgba, width, height, src_layout_id, dst_layout_id)
        dst_w = int(target_width) or texture.width
        dst_h = int(target_height) or texture.height
        if (width, height) != (dst_w, dst_h):
            warped = uvremap.resize_rgba(warped, width, height, dst_w, dst_h)
        warped_png = _core.pngio.write_png_rgba(dst_w, dst_h, warped)
        change = _core.import_png_bytes(opened, texture, warped_png)
        return {'change': change, 'warped_from': src_layout_id, 'warped_to': dst_layout_id, 'source_size': [width, height], 'target_size': [dst_w, dst_h]}

    return _report(run)


def uvremap_layouts_bridge():
    """List the available atlas layouts for the UI."""

    def run():
        from iffengine import uvremap
        return {'layouts': [{'id': layout['id'], 'games': list(layout.get('games', ())), 'canonical': bool(layout.get('canonical'))} for layout in uvremap.ATLAS_LAYOUTS.values()]}

    return _report(run)


def export_mesh_obj_bridge(session_id, file_index, out_dir):
    """Export the scene mesh as OBJ + diffuse PNG (Blender-ready)."""

    def run():
        session = _session(session_id)
        opened = session['opened'][int(file_index)]
        from iffengine import mesh3d
        return mesh3d.export_cyberface_obj(opened, Path(out_dir), opened.path.stem)

    return _report(run)


def save_iff_bridge(session_id, file_index, out_path):
    return _report(save_iff, session_id, int(file_index), out_path)


def stage_iff_bridge(obb_session, index, edited_iff_path):
    """Stage an edited IFF (saved as a compressed wrapper) into the OBB."""

    def run():
        raw = open(edited_iff_path, 'rb').read()
        decompressed, _sizes, _wrapper, _info = core.decompress_wrapper(raw)
        return {'staged': stage_obb_iff(obb_session, int(index), raw, bytes(decompressed))}

    return _report(run)


_REBUILD_PROGRESS = {'copied': 0, 'total': 0, 'percent': 0}


def rebuild_obb_progress_bridge():
    """Return JSON string with current rebuild copy progress."""
    return json.dumps(_REBUILD_PROGRESS)


def rebuild_obb_bridge(obb_session, out_path):
    global _REBUILD_PROGRESS
    _REBUILD_PROGRESS = {'copied': 0, 'total': 0, 'percent': 0}

    def progress_cb(copied, total):
        global _REBUILD_PROGRESS
        pct = int(copied * 100 / total) if total > 0 else 0
        _REBUILD_PROGRESS = {'copied': copied, 'total': total, 'percent': pct}

    return _report(save_obb, obb_session, out_path, progress_cb)


def close_iff_bridge(session_id):
    return _report(close_session, session_id)


def resolve_references_bridge(session_id, file_index, obb_session):
    """Re-resolve scene references for an already-open IFF against an OBB.

    Allows the UI to trigger resolution when the OBB session becomes
    available later (e.g. the user opened a standalone IFF first, then
    provided the OBB).
    """

    def run():
        session = _session(session_id)
        opened = session['opened'][int(file_index)]
        obb_path = str(_obb_session(obb_session).path)
        count = core.resolve_scene_references(opened, Path(obb_path))
        return {'resolved_count': count, 'textures': [texture.as_dict() for texture in opened.textures], 'reference_summary': core.face_reference_summary(opened)}

    return _report(run)


def face_reference_status_bridge(session_id, file_index):
    """Return structured diagnostic info for each reference texture.

    Useful for the UI to display a resolution pipeline status per texture:
    Referenced Texture -> Searching Texture Bank -> Atlas Found -> Decoded.
    """

    def run():
        session = _session(session_id)
        opened = session['opened'][int(file_index)]
        return core.face_reference_summary(opened)

    return _report(run)


def template_batch_preview_bridge(obb_session, pairs_json):
    """Dry-run: report ready/error for each entry+PNG pair without mutating."""
    pairs = json.loads(pairs_json)
    return _report(template_batch_replace, obb_session, pairs, '', False)


def template_batch_apply_bridge(obb_session, pairs_json, work_dir):
    """Import PNGs into the matched OBB entries and stage them for rebuild."""
    pairs = json.loads(pairs_json)
    return _report(template_batch_replace, obb_session, pairs, work_dir, True)


def replace_obb_entries_preview_bridge(obb_session, pairs_json):
    """Dry-run: report ready/error for each entry+replacement pair."""
    pairs = json.loads(pairs_json)
    return _report(replace_obb_entries, obb_session, pairs, '', False)


def replace_obb_entries_apply_bridge(obb_session, pairs_json, work_dir):
    """Re-encode replacement IFFs into their OBB entries and stage them."""
    pairs = json.loads(pairs_json)
    return _report(replace_obb_entries, obb_session, pairs, work_dir, True)


def export_obb_entry_bridge(obb_session, index, out_path):
    """Write one OBB entry's exact container bytes to ``out_path``."""
    return _report(export_obb_entry, obb_session, int(index), out_path)


def list_bank_textures_bridge(session_id, file_index, texture_number, obb_session):
    """List all available texture slots in the OBB's banks for manual selection."""
    return _report(list_bank_textures, session_id, int(file_index), int(texture_number), obb_session)


def manual_resolve_texture_bridge(session_id, file_index, texture_number, obb_session, bank_entry_index, bank_texture_number):
    """Manually resolve a scene reference to a specific bank texture."""
    return _report(manual_resolve_texture, session_id, int(file_index), int(texture_number), obb_session, int(bank_entry_index), int(bank_texture_number))


def scan_obb_audio_bridge(obb_session):
    """Scan the open OBB for all OGG streams and return metadata list."""
    return _report(scan_obb_audio, obb_session)


def extract_audio_stream_bridge(obb_session, start_offset, size, out_path):
    """Extract a single audio stream on-demand for playback or export."""
    return _report(extract_audio_stream, obb_session, int(start_offset), int(size), out_path)


def replace_audio_stream_bridge(obb_session, start_offset, size, replacement_path,
                                output_obb_path=None):
    """Replace an existing audio stream inside the OBB."""
    return _report(replace_audio_stream_in_obb, obb_session, int(start_offset), int(size), replacement_path, output_obb_path)


def _mesh_tools_b64_mesh(preview: dict) -> dict:
    """Pack a mesh3d preview dict into base64 buffers for Mesh3DView."""
    import array
    import base64
    import itertools
    pos = array.array('f', itertools.chain.from_iterable(preview['positions'])).tobytes()
    nrm = array.array('f', itertools.chain.from_iterable(preview['normals'])).tobytes()
    uv = array.array('f', itertools.chain.from_iterable(preview['uvs'])).tobytes()
    idx = array.array('H', preview['indices']).tobytes()
    return {'vertices': preview['vertices'], 'triangles': preview['triangles'], 'groups': preview.get('groups', []), 'positions_b64': base64.b64encode(pos).decode('ascii'), 'normals_b64': base64.b64encode(nrm).decode('ascii'), 'uvs_b64': base64.b64encode(uv).decode('ascii'), 'indices_b64': base64.b64encode(idx).decode('ascii')}


def extract_mesh_bridge(session_id, file_index):
    """Extract cyberface head mesh for interactive 3D preview in IffEditor."""

    def run():
        from iffengine import mesh3d
        session = _session(session_id)
        opened = session['opened'][int(file_index)]
        try:
            mesh = mesh3d.extract_cyberface_mesh(opened)
        except Exception as error:
            raise ValueError(f"""3D preview failed on {opened.path.name}: {type(error).__name__}: {error}""") from error
        clean_tris_count = min(3107, mesh['triangles'])
        clean_indices = mesh['indices'][:clean_tris_count * 3]
        if len(clean_indices) % 3:
            clean_indices = clean_indices[:len(clean_indices) - len(clean_indices) % 3]
        nverts = mesh['vertices']
        if clean_indices and max(clean_indices) >= nverts:
            clean_indices = [v for t in range(0, len(clean_indices) - 2, 3) if max(clean_indices[t], clean_indices[t + 1], clean_indices[t + 2]) < nverts for v in clean_indices[t:t + 3]]

        if not clean_indices:
            raise ValueError('cyberface mesh has no usable triangles')
        clean_preview = {'vertices': mesh['vertices'], 'triangles': clean_tris_count, 'positions': mesh['positions'], 'normals': mesh['normals'], 'uvs': mesh['uvs'], 'indices': clean_indices}
        return _mesh_tools_b64_mesh(clean_preview)

    return _report(run)


def patch_mesh_bridge(session_id, file_index, positions_b64, normals_b64, uvs_b64,
                      indices_b64=None, remap_b64=None):
    """Rewrite edited vertex data back into the live session scene (save-to-IFF).

    Accepts little-endian f32 payloads (base64) exactly as the editor's
    EditableMesh stores them. Positions/normals/UVs are rewritten byte-exact,
    in place. When the editor also supplies its edited triangle list
    (``indices_b64``) and optional original→current vertex map
    (``remap_b64``, i16, -1 = removed), the strip buffer is rebuilt so
    merge/delete topology edits persist too. Vertex growth (extrude beyond
    the original count) is refused.
    """

    def run():
        import base64
        import struct
        from iffengine import mesh3d
        session = _session(session_id)
        opened = session['opened'][int(file_index)]

        def unpack_f32(payload):
            raw = base64.b64decode(payload)
            return struct.unpack(f"""<{len(raw) // 4}f""", raw)

        def unpack_u16(payload):
            if payload is None:
                return None
            raw = base64.b64decode(payload)
            return struct.unpack(f"""<{len(raw) // 2}H""", raw)

        def unpack_i16(payload):
            if payload is None:
                return None
            raw = base64.b64decode(payload)
            return struct.unpack(f"""<{len(raw) // 2}h""", raw)

        try:
            positions = unpack_f32(positions_b64)
            normals = unpack_f32(normals_b64)
            uvs = unpack_f32(uvs_b64)
            indices = unpack_u16(indices_b64)
            remap = unpack_i16(remap_b64)
        except Exception as error:
            raise ValueError(f"""invalid mesh payload from editor: {error}""") from error
        try:
            report = mesh3d.update_mesh_data(opened, positions, normals, uvs, indices_u16=indices, remap_u16=remap)
        except Exception as error:
            raise ValueError(f"""Save failed on {opened.path.name}: {type(error).__name__}: {error}""") from error
        report['file'] = opened.path.name
        return report

    return _report(run)


def export_n2km_bridge(session_id, file_index, out_path):
    """Write the open cyberface scene as a .n2km file for the Blender
    io_n2km plugin (File > Import > NBA 2K model format).

    Positions are stored in the plugin's post-import basis so Blender shows
    the model exactly like the in-app preview; an unmodified Blender export
    round-trips back to the original coordinates.
    """

    def run():
        from iffengine import mesh3d
        session = _session(session_id)
        opened = session['opened'][int(file_index)]
        data = mesh3d.cyberface_to_n2km(opened)
        destination = Path(out_path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        return {'path': str(destination), 'size': len(data), 'vertices': len(opened.textures)}

    report = _report(run)
    if report.get('ok'):
        try:
            from iffengine import mesh3d
            parts = mesh3d.parse_n2km(Path(out_path).read_bytes())
            report['parts'] = [{'name': p['name'], 'vertices': len(p['positions']), 'triangles': len(p['indices']) // 3} for p in parts]
            report['vertices'] = sum((len(p['positions']) for p in parts))
            report['triangles'] = sum((len(p['indices']) // 3 for p in parts))
        except Exception:
            pass
    return report


def import_n2km_bridge(session_id, file_index, n2km_path):
    """Inject a Blender-exported .n2km into the open cyberface scene.

    Reads CURRENT session state (already carries the user's replaced
    textures). Validate the file fully (parse_n2km) before touching the
    scene; on success the caller saves the IFF through the proven pipeline.
    """

    def run():
        from iffengine import mesh3d
        session = _session(session_id)
        opened = session['opened'][int(file_index)]
        data = Path(n2km_path).read_bytes()
        parts = mesh3d.parse_n2km(data)
        report = mesh3d.n2km_write_into_scene(opened, data)
        report['file'] = opened.path.name
        report['parts'] = [{'name': p['name'], 'vertices': len(p['positions']), 'triangles': len(p['indices']) // 3} for p in parts]
        return report

    return _report(run)


def parse_n2km_bridge(n2km_path):
    """Parse + validate a 2KM file and return shells, checks and stats."""

    def run():
        from iffengine import mesh3d
        data = Path(n2km_path).read_bytes()
        shells = mesh3d.parse_n2km(data)
        return {'shells': [{'name': s.get('name', ''), 'vertices': s['vertices'], 'triangles': s['triangles'], 'record_size': s.get('record_size'), 'topology_ok': s.get('topology_ok', s.get('validated')), 'raw': {k: v for k, v in s.items() if isinstance(v, (int, float, str, bool))}} for s in shells], 'total_shells': len(shells), 'total_vertices': sum((s['vertices'] for s in shells)), 'total_triangles': sum((s['triangles'] for s in shells)), 'file_size': len(data), 'magic_ok': data[:4] == b'2KM\x00'}

    return _report(run)


def export_n2km_obj_bridge(n2km_path, out_dir):
    """Convert a 2KM file to OBJ text files (one per shell) in out_dir."""

    def run():
        from iffengine import mesh3d
        data = Path(n2km_path).read_bytes()
        shells = mesh3d.parse_n2km(data)
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        written = []
        stem = Path(n2km_path).stem or 'shell'
        for i, shell in enumerate(shells):
            name = str(shell.get('name') or f"""{stem}_{i + 1}""")
            safe = ''.join((c if c.isalnum() or c in '_- ' else '_' for c in name)).strip() or f"""{stem}_{i + 1}"""
            obj_path = out / f"""{safe}.obj"""
            obj_path.write_text(mesh3d.n2km_to_obj(data), encoding='utf-8')
            written.append(str(obj_path))
        return {'written': written, 'count': len(written)}

    return _report(run)


def n2km_obj_text_bridge(n2km_path):
    """Return the converted OBJ text of a 2KM file (for Save-As flows)."""

    def run():
        from iffengine import mesh3d
        data = Path(n2km_path).read_bytes()
        shells = mesh3d.parse_n2km(data)
        return {'obj_text': mesh3d.n2km_to_obj(data), 'shells': len(shells)}

    return _report(run)


def preview_obj_bridge(obj_path):
    """Parse an OBJ file for the interactive 3D preview (grouped buffers)."""

    def run():
        from iffengine import mesh3d
        text = Path(obj_path).read_text(encoding='utf-8', errors='replace')
        return _mesh_tools_b64_mesh(mesh3d.parse_obj_preview(text))

    return _report(run)


def preview_n2km_bridge(n2km_path):
    """Parse a 2KM file directly into 3D preview buffers."""

    def run():
        from iffengine import mesh3d
        data = Path(n2km_path).read_bytes()
        obj_text = mesh3d.n2km_to_obj(data)
        return _mesh_tools_b64_mesh(mesh3d.parse_obj_preview(obj_text))

    return _report(run)


def _mesh_obj_text(mesh: dict, name_hint: str) -> str:
    """Render a mesh3d dict (extract_cyberface_mesh shape) as OBJ text."""
    lines = [f"# TKM cyberface mesh export ({mesh['vertices']} verts, {mesh['triangles']} tris)", f"o {(name_hint or 'mesh').replace(' ', '_')}"]
    for x, y, z in mesh['positions']:
        lines.append(f"""v {x:.6f} {y:.6f} {z:.6f}""")

    for u, v in mesh['uvs']:
        lines.append(f"""vt {u:.6f} {v:.6f}""")

    for x, y, z in mesh['normals']:
        lines.append(f"""vn {x:.6f} {y:.6f} {z:.6f}""")

    idx = mesh['indices']
    for i in range(0, len(idx), 3):
        lines.append(f"""f {idx[i] + 1}/{idx[i] + 1}/{idx[i] + 1} {idx[i + 1] + 1}/{idx[i + 1] + 1}/{idx[i + 1] + 1} {idx[i + 2] + 1}/{idx[i + 2] + 1}/{idx[i + 2] + 1}""")
    return '\n'.join(lines) + '\n'


def preview_iff_mesh_bridge(iff_path):
    """Extract the cyberface mesh from an IFF path (no session needed).

    Opens a throwaway engine session internally so Mesh Tools can preview a
    PNG####.IFF cyberface straight from the file picker.
    """

    def run():
        import base64
        import tempfile
        from iffengine import mesh3d
        created = new_session([str(iff_path)])
        sid = created['session_id']
        try:
            opened = _session(sid)['opened'][0]
            mesh = mesh3d.extract_cyberface_mesh(opened)
            name = opened.path.stem
            diffuse_b64 = ''
            textures = (created.get('files') or [{}])[0].get('textures') or []
            face = next((t for t in textures if 'face diffuse' in str(t.get('role', '')).lower() or 'face diffuse' in str(t.get('label', '')).lower()), None) or (textures[0] if textures else None)
            if face is not None and face.get('status') != 'reference':
                try:
                    with tempfile.TemporaryDirectory() as tmp:
                        png_path = str(Path(tmp) / 'diffuse.png')
                        texture_thumb_to_file(sid, 0, int(face['number']), png_path, 256)
                        diffuse_b64 = base64.b64encode(Path(png_path).read_bytes()).decode('ascii')
                except Exception:
                    diffuse_b64 = ''
        finally:
            close_session(sid)
        payload = _mesh_tools_b64_mesh({'vertices': mesh['vertices'], 'triangles': mesh['triangles'], 'positions': mesh['positions'], 'normals': mesh['normals'], 'uvs': mesh['uvs'], 'indices': mesh['indices'], 'groups': [{'name': name, 'triangles': mesh['triangles'], 'vertices': mesh['vertices']}]})
        payload['name'] = name
        payload['diffuse_b64'] = diffuse_b64
        return payload

    return _report(run)


def iff_obj_text_bridge(iff_path):
    """Return the OBJ text of a cyberface IFF (session-less, for Save-As)."""

    def run():
        from iffengine import mesh3d
        created = new_session([str(iff_path)])
        sid = created['session_id']
        try:
            opened = _session(sid)['opened'][0]
            mesh = mesh3d.extract_cyberface_mesh(opened)
            name = opened.path.stem
        finally:
            close_session(sid)
        return {'obj_text': _mesh_obj_text(mesh, name), 'vertices': mesh['vertices'], 'triangles': mesh['triangles']}

    return _report(run)


def obj_transform_bridge(obj_text, transform_json):
    """Apply affine transform (translate, rotate, scale) to OBJ text."""

    def run():
        import json
        import math
        transforms = json.loads(transform_json)
        tx, ty, tz = transforms.get('translate', [0.0, 0.0, 0.0])
        rx, ry, rz = transforms.get('rotate', [0.0, 0.0, 0.0])
        sx, sy, sz = transforms.get('scale', [1.0, 1.0, 1.0])
        rad_x, rad_y, rad_z = math.radians(rx), math.radians(ry), math.radians(rz)
        cos_x, sin_x = math.cos(rad_x), math.sin(rad_x)
        cos_y, sin_y = math.cos(rad_y), math.sin(rad_y)
        cos_z, sin_z = math.cos(rad_z), math.sin(rad_z)
        out_lines = []
        for line in obj_text.splitlines():
            if line.startswith('v '):
                parts = line.strip().split()
                if len(parts) >= 4:
                    try:
                        x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
                        x, y, z = x * sx, y * sy, z * sz
                        y, z = y * cos_x - z * sin_x, y * sin_x + z * cos_x
                        x, z = x * cos_y + z * sin_y, -x * sin_y + z * cos_y
                        x, y = x * cos_z - y * sin_z, x * sin_z + y * cos_z
                        x, y, z = x + tx, y + ty, z + tz
                        out_lines.append(f"""v {x:.6f} {y:.6f} {z:.6f}""")
                        continue
                    except ValueError:
                        pass
            out_lines.append(line)
        new_obj = '\n'.join(out_lines) + '\n'
        from iffengine import mesh3d
        preview = mesh3d.parse_obj_preview(new_obj)
        packed = _mesh_tools_b64_mesh(preview)
        packed['obj_text'] = new_obj
        return packed

    return _report(run)


def obj_uv_preview_bridge(obj_text):
    """Render UV layout wireframe as a 512x512 PNG image."""

    def run():
        import base64
        from iffengine import mesh3d
        from iffengine import core
        preview = mesh3d.parse_obj_preview(obj_text)
        dim = 512
        rgba = bytearray([15, 20, 30, 255] * (dim * dim))
        uvs = preview.get('uvs', [])
        indices = preview.get('indices', [])

        def draw_line(x0, y0, x1, y1, r=60, g=170, b=250):
            dx = abs(x1 - x0)
            dy = -abs(y1 - y0)
            sx = 1 if x0 < x1 else -1
            sy = 1 if y0 < y1 else -1
            err = dx + dy
            while True:
                if 0 <= x0 < dim and 0 <= y0 < dim:
                    offset = (y0 * dim + x0) * 4
                    rgba[offset] = r
                    rgba[offset + 1] = g
                    rgba[offset + 2] = b
                    rgba[offset + 3] = 255

                if x0 == x1 and y0 == y1:
                    break
                e2 = 2 * err
                if e2 >= dy:
                    err += dy
                    x0 += sx

                if e2 <= dx:
                    err += dx
                    y0 += sy

        for i in range(0, len(indices), 3):
            if i + 2 < len(indices):
                i0, i1, i2 = indices[i], indices[i + 1], indices[i + 2]
                if i0 < len(uvs) and i1 < len(uvs) and (i2 < len(uvs)):
                    [u0, v0] = uvs[i0]
                    [u1, v1] = uvs[i1]
                    [u2, v2] = uvs[i2]
                    px0 = int(u0 * (dim - 1)) % dim
                    py0 = int((1.0 - v0) * (dim - 1)) % dim
                    px1 = int(u1 * (dim - 1)) % dim
                    py1 = int((1.0 - v1) * (dim - 1)) % dim
                    px2 = int(u2 * (dim - 1)) % dim
                    py2 = int((1.0 - v2) * (dim - 1)) % dim
                    draw_line(px0, py0, px1, py1)
                    draw_line(px1, py1, px2, py2)
                    draw_line(px2, py2, px0, py0)
        png_bytes = core.pngio.write_png_rgba(dim, dim, bytes(rgba))
        return {'uv_png_b64': base64.b64encode(png_bytes).decode('ascii'), 'width': dim, 'height': dim}

    return _report(run)


def run_batch(iff_paths, png_paths, out_dir):
    try:
        created = new_session(iff_paths)
        session_id = created['session_id']
        try:
            replaced = apply_replacements(session_id, png_paths)
            exported = export_modified(session_id, out_dir)
        finally:
            close_session(session_id)
        return json.dumps({'ok': True, 'replaced': replaced, 'exported': exported})
    except Exception as error:
        return json.dumps({'ok': False, 'error': str(error)})

def scan_single_bin_for_audio(bin_path):
    """Scan a single extracted .bin file for OGG headers."""
    try:
        oggs = []
        with open(bin_path, 'rb') as f:
            # We read the file to find the 'OggS' magic bytes
            data = f.read()
            offset = 0
            while True:
                idx = data.find(b'OggS', offset)
                if idx == -1:
                    break
                oggs.append({"offset": idx})
                offset = idx + 4
                
        return json.dumps({"ok": True, "count": len(oggs), "oggs": oggs})
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)})
