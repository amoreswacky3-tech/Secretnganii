"""iffengine.uvremap - UV-aware atlas transfer for cyberface textures.

Implements the design in ``UV_REMAP_DESIGN.md``:

    unwrap(source) -> user edits -> inverse-UV remap -> target layout

The warp is a piecewise-affine mapping over a triangulation of the layout's
anchor points (plus image corners/edge midpoints so the whole atlas is
covered).  Everything is pure Python on raw RGBA buffers - the Android engine
has no image dependencies.

Phase-0 result (see UV_REMAP_DESIGN.md section 6): 2K18/2K19/2K20 share one
canonical diffuse layout, so transfers inside that generation are pure
normalization (identity anchors); 2K16 differs moderately, so the anchor warp
matters for cross-generation transfers.
"""

from __future__ import annotations
import json
import math
import struct
from pathlib import Path

ATLAS_LAYOUTS: dict[str, dict] = {"2k18plus_face_diffuse": {"id": "2k18plus_face_diffuse", "games": ("2K18", "2K19", "2K20"), "canonical": True, "anchors": {"hairline_center": (0.5, 0.235), "r_eye_outer": (0.415, 0.31), "r_eye_inner": (0.462, 0.318), "l_eye_inner": (0.538, 0.318), "l_eye_outer": (0.585, 0.31), "nose_bridge_top": (0.5, 0.335), "nose_tip": (0.5, 0.4), "r_mouth_corner": (0.458, 0.452), "l_mouth_corner": (0.542, 0.452), "mouth_center": (0.5, 0.462), "chin": (0.5, 0.545), "neck_top": (0.5, 0.62), "r_face_edge": (0.315, 0.42), "l_face_edge": (0.685, 0.42)}}, "2k16_face_diffuse": {"id": "2k16_face_diffuse", "games": ("2K16", "2K17"), "canonical": True, "anchors": {"hairline_center": (0.5, 0.25), "r_eye_outer": (0.4, 0.322), "r_eye_inner": (0.452, 0.33), "l_eye_inner": (0.548, 0.33), "l_eye_outer": (0.6, 0.322), "nose_bridge_top": (0.5, 0.342), "nose_tip": (0.5, 0.412), "r_mouth_corner": (0.448, 0.464), "l_mouth_corner": (0.552, 0.464), "mouth_center": (0.5, 0.474), "chin": (0.5, 0.56), "neck_top": (0.5, 0.64), "r_face_edge": (0.3, 0.43), "l_face_edge": (0.7, 0.43)}}}


def get_layout(layout_id: str) -> dict:
    try:
        return ATLAS_LAYOUTS[layout_id]
    except KeyError:
        raise ValueError(f"""unknown atlas layout: {layout_id}""") from None


def load_layouts(path: Path) -> None:
    """Merge user-authored layouts from a JSON file (power-user override)."""
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    for layout in data.get("layouts", []):
        if "id" in layout and "anchors" in layout:
            ATLAS_LAYOUTS[layout["id"]] = layout


def _super_triangle(points: list[tuple[float, float]]):
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    min_x, min_y, max_x, max_y = (min(xs), min(ys), max(xs), max(ys))
    cx = (min_x + max_x) / 2
    cy = (min_y + max_y) / 2
    dx = max_x - min_x
    dy = max_y - min_y
    d = max(dx, dy) * 10 + 10
    return [(cx, cy - d), (cx - d, cy + d), (cx + d, cy + d)]


def _circumcircle(a, b, c):
    [ax, ay] = a
    [bx, by] = b
    [cx, cy] = c
    d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
    if abs(d) < 1e-12:
        return None
    ux = ((ax * ax + ay * ay) * (by - cy) + (bx * bx + by * by) * (cy - ay) + (cx * cx + cy * cy) * (ay - by)) / d
    uy = ((ax * ax + ay * ay) * (cx - bx) + (bx * bx + by * by) * (ax - cx) + (cx * cx + cy * cy) * (bx - ax)) / d
    r2 = (ax - ux)**2 + (ay - uy)**2
    return (ux, uy, r2)


def delaunay(points: list[tuple[float, float]]) -> list[tuple[int, int, int]]:
    """Bowyer-Watson triangulation of <= ~24 points (fast enough, pure Python)."""
    if len(points) < 3:
        raise ValueError("need at least 3 points to triangulate")
    sup = _super_triangle(points)
    pts = list(points) + sup
    n_real = len(points)
    sup_idx = {n_real, n_real + 1, n_real + 2}
    triangles = [(n_real, n_real + 1, n_real + 2)]
    cc = {triangles[0]: _circumcircle(pts[n_real], pts[n_real + 1], pts[n_real + 2])}
    for i in range(n_real):
        p = pts[i]
        bad = []
        for tri in triangles:
            c = cc.get(tri)
            if c is None:
                c = _circumcircle(pts[tri[0]], pts[tri[1]], pts[tri[2]])
                cc[tri] = c

            if c and (p[0] - c[0])**2 + (p[1] - c[1])**2 < c[2]:
                bad.append(tri)
        edges = []
        for tri in bad:
            for a, b in ((tri[0], tri[1]), (tri[1], tri[2]), (tri[2], tri[0])):
                edge = (min(a, b), max(a, b))
                if edge in edges:
                    edges.remove(edge)
                else:
                    edges.append(edge)
        for tri in bad:
            triangles.remove(tri)
            cc.pop(tri, None)
        for a, b in edges:
            tri = (a, b, i)
            triangles.append(tri)
            cc[tri] = _circumcircle(pts[a], pts[b], p)
    return [tri for tri in triangles if tri[0] not in sup_idx and tri[1] not in sup_idx and tri[2] not in sup_idx]


def _anchor_pairs(src_layout: dict, dst_layout: dict, width: int, height: int):
    """Build matched point lists (source px, destination px) incl. frame points."""
    src_anchors = src_layout["anchors"]
    dst_anchors = dst_layout["anchors"]
    names = [name for name in src_anchors if name in dst_anchors]
    if not names:
        raise ValueError("layouts share no anchor names")

    def frame_points():
        pts = []
        for frac in (0.25, 0.5, 0.75):
            pts.append((frac, 0.0))
            pts.append((frac, 1.0))
            pts.append((0.0, frac))
            pts.append((1.0, frac))
        pts.append((0.0, 0.0))
        pts.append((0.0, 1.0))
        pts.append((1.0, 0.0))
        pts.append((1.0, 1.0))
        return pts

    src_pts = []
    dst_pts = []
    for name in names:
        [su, sv] = src_anchors[name]
        [du, dv] = dst_anchors[name]
        src_pts.append((su * width, sv * height))
        dst_pts.append((du * width, dv * height))

    for fu, fv in frame_points():
        src_pts.append((fu * width, fv * height))
        dst_pts.append((fu * width, fv * height))
    return (src_pts, dst_pts)


def _triangle_affine(src_tri, dst_tri):
    """Affine that maps dst_tri -> src_tri (for inverse sampling)."""
    (x0, y0), (x1, y1), (x2, y2) = dst_tri
    (u0, v0), (u1, v1), (u2, v2) = src_tri
    det = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0)
    if abs(det) < 1e-09:
        return None
    a = ((u1 - u0) * (y2 - y0) - (u2 - u0) * (y1 - y0)) / det
    b = ((u2 - u0) * (x1 - x0) - (u1 - u0) * (x2 - x0)) / det
    c = u0 - a * x0 - b * y0
    d = ((v1 - v0) * (y2 - y0) - (v2 - v0) * (y1 - y0)) / det
    e = ((v2 - v0) * (x1 - x0) - (v1 - v0) * (x2 - x0)) / det
    f = v0 - d * x0 - e * y0
    return (a, b, c, d, e, f)


def remap_rgba(rgba: bytes, width: int, height: int, src_layout: dict, dst_layout: dict) -> bytes:
    """Warp ``rgba`` from the source layout's coordinate system to the target's.

    Inverse mapping: for every destination pixel, find its triangle in the
    DESTINATION point set, map back through the affine to the source pixel,
    and bilinear-sample.  Holes are impossible by construction.
    """
    if src_layout["id"] == dst_layout["id"] or src_layout is dst_layout:
        return rgba
    [src_pts, dst_pts] = _anchor_pairs(src_layout, dst_layout, width, height)
    tris = delaunay(dst_pts)
    mapped = []
    for tri in tris:
        i0, i1, i2 = tri
        affine = _triangle_affine((src_pts[i0], src_pts[i1], src_pts[i2]), (dst_pts[i0], dst_pts[i1], dst_pts[i2]))
        if affine is None:
            continue
        xs = (dst_pts[i0][0], dst_pts[i1][0], dst_pts[i2][0])
        ys = (dst_pts[i0][1], dst_pts[i1][1], dst_pts[i2][1])
        x0 = max(0, int(min(xs)))
        x1 = min(width - 1, int(max(xs)) + 1)
        y0 = max(0, int(min(ys)))
        y1 = min(height - 1, int(max(ys)) + 1)
        if x1 < x0 or y1 < y0:
            continue
        mapped.append((affine, x0, y0, x1, y1))
    out = bytearray(len(rgba))
    for affine, x0, y0, x1, y1 in mapped:
        a, b, c, d, e, f = affine
        for dy in range(y0, y1 + 1):
            row = dy * width
            for dx in range(x0, x1 + 1):
                su = a * dx + b * dy + c
                sv = d * dx + e * dy + f
                if su < 0 or sv < 0 or su > width - 1 or sv > height - 1:
                    continue
                x_f = int(su)
                y_f = int(sv)
                x_c = x_f + 1 if x_f + 1 < width else x_f
                y_c = y_f + 1 if y_f + 1 < height else y_f
                fx = su - x_f
                fy = sv - y_f
                i00 = (row + x_f) * 4
                i10 = (row + x_c) * 4
                i01 = (y_c * width + x_f) * 4
                i11 = (y_c * width + x_c) * 4
                w00 = (1 - fx) * (1 - fy)
                w10 = fx * (1 - fy)
                w01 = (1 - fx) * fy
                w11 = fx * fy
                base = (row + dx) * 4
                for ch in range(4):
                    out[base + ch] = int(rgba[i00 + ch] * w00 + rgba[i10 + ch] * w10 + rgba[i01 + ch] * w01 + rgba[i11 + ch] * w11)
    return bytes(out)


def normalize_to_canonical(rgba: bytes, width: int, height: int, layout_id: str) -> bytes:
    """Stage A: warp a source atlas into its generation's canonical layout."""
    return remap_rgba(rgba, width, height, get_layout(layout_id), _canonical_of(layout_id))


def remap_from_canonical(rgba: bytes, width: int, height: int, layout_id: str) -> bytes:
    """Stage C: warp a canonical-layout atlas into the target layout."""
    canonical = _canonical_of(layout_id)
    return remap_rgba(rgba, width, height, canonical, get_layout(layout_id))


def _canonical_of(layout_id: str) -> dict:
    layout = get_layout(layout_id)
    if layout.get("canonical"):
        return layout

    for candidate in ATLAS_LAYOUTS.values():
        if candidate.get("canonical") and set(candidate.get("games", ())) & set(layout.get("games", ())):
            return candidate

    raise ValueError(f"""no canonical layout for generation of {layout_id}""")


def transfer_between_games(rgba: bytes, width: int, height: int, src_layout_id: str, dst_layout_id: str) -> bytes:
    """Full transfer: source layout -> source canonical -> target canonical -> target layout.

    When both generations share a canonical layout this collapses to the
    identity (pure format/resolution normalization happens in the caller).
    """
    src_canon = _canonical_of(src_layout_id)
    dst_canon = _canonical_of(dst_layout_id)
    result = remap_rgba(rgba, width, height, get_layout(src_layout_id), src_canon)
    if src_canon["id"] != dst_canon["id"]:
        result = remap_rgba(result, width, height, src_canon, dst_canon)

    if dst_canon["id"] != get_layout(dst_layout_id)["id"]:
        result = remap_rgba(result, width, height, dst_canon, get_layout(dst_layout_id))
    return result


def resize_rgba(rgba: bytes, src_w: int, src_h: int, dst_w: int, dst_h: int) -> bytes:
    """Nearest-neighbour resample (pure Python, bilinear-free fast path).

    Used to normalize a user-painted atlas of any resolution onto the exact
    dimensions of the destination texture before import.  Anchors are
    normalized, so scaling does not affect the warp geometry.
    """
    if src_w == dst_w and src_h == dst_h:
        return rgba
    out = bytearray(dst_w * dst_h * 4)
    x_ratios = [min(src_w - 1, dx * src_w // dst_w) for dx in range(dst_w)]
    for dy in range(dst_h):
        sy = min(src_h - 1, dy * src_h // dst_h)
        src_row = sy * src_w * 4
        dst_row = dy * dst_w * 4
        for dx in range(dst_w):
            s = src_row + x_ratios[dx] * 4
            d = dst_row + dx * 4
            out[d] = rgba[s]
            out[d + 1] = rgba[s + 1]
            out[d + 2] = rgba[s + 2]
            out[d + 3] = rgba[s + 3]
    return bytes(out)
