"""APK integrity gate inside the Python engine (second enforcement layer).

Why this exists
---------------
The Kotlin ``TamperGuard`` verifies the APK signature in the dex layer, but a
cracker can patch that one call out of smali and rebuild (this is exactly how
 SebTool was cracked).  This module re-implements the same verification
*inside the compiled Python engine*, so a repack must now defeat two
independent layers: the dex gate AND the Chaquopy bytecode shipped inside
``app.imy``.

How it works
------------
* The build bakes the expected signing-certificate SHA-256 into
  ``iffengine/integrity_constants.py`` (generated per build variant by
  Gradle, from the same certificate the APK is signed with).
* At engine start (first bridge/engine call on Android) this module reads
  the *actual* signing certificate of the running package through the JNI
  bridge and compares digests.
* Any mismatch — or a failure to read the certificate — raises
  :class:`IntegrityError`, which fails every engine operation closed.
* Desktop (non-Android) runs are never gated: development and tests keep
  working.

The gate is called from every bridge entry point, so there is no single
patchable choke point on the Python side either.
"""
from __future__ import annotations
import hashlib
__all__ = ['IntegrityError', 'ensure_verified', 'in_chaquopy', 'reset_gate']
_GATE_STATE = {'verified': None}

class IntegrityError(RuntimeError):
    """Raised when the running APK does not match the signed build."""

def in_chaquopy() -> bool:
    """True when the engine runs inside the Android/Chaquopy runtime."""
    import sys
    return sys.platform == 'android' or 'java' in sys.modules or 'com.chaquo.python' in sys.modules

def _expected_signatures() -> set:
    """Certificates the build vouches for (debug + release variant certs)."""
    try:
        from . import integrity_constants as constants
        values = set()
        for name in ('EXPECTED_SIGNATURE_SHA256', 'EXPECTED_SIGNATURE_SHA256_RELEASE'):
            value = (getattr(constants, name, '') or '').strip().lower()
            if len(value) == 64:
                values.add(value)
        return values
    except Exception:
        return set()

def _actual_signature() -> str:
    """SHA-256 over the APK's current signing certificate (hex, lowercase)."""
    from java import jclass
    ActivityThread = jclass('android.app.ActivityThread')
    app = ActivityThread.currentApplication()
    if app is None:
        raise IntegrityError('integrity: no application context')
    pm = app.getPackageManager()
    package = app.getPackageName()
    GET_SIGNING_CERTS = 134217728
    GET_SIGNATURES = 64
    try:
        info = pm.getPackageInfo(package, GET_SIGNING_CERTS)
        signing = info.signingInfo
        certs = signing.getApkContentsSigners()
        if certs is None or len(certs) == 0:
            raise IntegrityError('integrity: no signing certificates')
        raw = certs[0].toByteArray()
    except IntegrityError:
        raise
    except Exception:
        try:
            info = pm.getPackageInfo(package, GET_SIGNATURES)
            raw = info.signatures[0].toByteArray()
        except Exception as error:
            raise IntegrityError(f'integrity: unreadable signature: {error}') from error
    return hashlib.sha256(bytes(raw)).hexdigest()

def ensure_verified() -> None:
    """Raise :class:`IntegrityError` unless the APK matches the baked cert.

    The result is cached after the first successful check; a failure is never
    cached so a tamper attempt cannot be retried into a pass.
    """
    if not in_chaquopy():
        return
    if _GATE_STATE['verified'] is True:
        return
    expected = _expected_signatures()
    if not expected:
        raise IntegrityError('integrity: expected signature not configured')
    try:
        actual = _actual_signature()
    except IntegrityError:
        _GATE_STATE['verified'] = False
        raise
    except Exception as error:
        _GATE_STATE['verified'] = False
        raise IntegrityError(f'integrity: verification failed: {error}') from error
    if actual not in expected:
        _GATE_STATE['verified'] = False
        raise IntegrityError('integrity: APK signature mismatch (repackaged build?)')
    _GATE_STATE['verified'] = True

def reset_gate() -> None:
    """Test helper: forget the cached verification result."""
    _GATE_STATE['verified'] = None
