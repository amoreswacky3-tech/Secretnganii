"""iffengine.audio - Scan, extract, stream and replace OGG audio inside NBA 2K OBB containers.

Adapted from bykingdaves' toolsogg.py for seamless in-app streaming playback and modding.
Supports Ogg Vorbis, Opus, FLAC, and Speex streams.
"""
from __future__ import annotations
import hashlib
import os
import struct
from pathlib import Path
from typing import BinaryIO
MAGIC = b'OggS'
CHUNK_SIZE = 4194304
COPY_SIZE = 1048576

def read_page(f: BinaryIO, offset: int, file_size: int) -> dict | None:
    """Read a single OggS page header and compute its boundaries."""
    if offset + 27 > file_size:
        return None
    try:
        f.seek(offset)
        header = f.read(27)
        if len(header) != 27 or header[:4] != MAGIC or header[4] != 0:
            return None
        header_type = header[5]
        serial = struct.unpack_from('<I', header, 14)[0]
        sequence = struct.unpack_from('<I', header, 18)[0]
        segment_count = header[26]
        segments = f.read(segment_count)
        if len(segments) != segment_count:
            return None
        payload_size = sum(segments)
        end = offset + 27 + segment_count + payload_size
        if end > file_size:
            return None
        return {'offset': offset, 'end': end, 'size': end - offset, 'serial': serial, 'sequence': sequence, 'header_type': header_type}
    except Exception:
        return None

def detect_codec(data: bytes) -> str:
    """Detect audio codec from initial stream bytes."""
    if b'\x01vorbis' in data[:500]:
        return 'Vorbis'
    if b'OpusHead' in data[:500]:
        return 'Opus'
    if b'fLaC' in data[:500]:
        return 'FLAC'
    if b'Speex' in data[:500]:
        return 'Speex'
    return 'OGG Audio'

def audio_info(data: bytes) -> tuple[str, int | None, int | None]:
    """Extract (codec, channels, sample_rate) from initial stream bytes."""
    codec = detect_codec(data)
    channels = None
    sample_rate = None
    pos = data.find(b'\x01vorbis')
    if pos >= 0:
        try:
            channels = data[pos + 11]
            sample_rate = struct.unpack_from('<I', data, pos + 12)[0]
        except Exception:
            pass
    pos = data.find(b'OpusHead')
    if pos >= 0:
        try:
            channels = data[pos + 9]
            sample_rate = struct.unpack_from('<I', data, pos + 12)[0]
        except Exception:
            pass
    return (codec, channels, sample_rate)

def parse_adts_header(header_bytes: bytes) -> tuple[str, int, int] | None:
    """Parse AAC ADTS 7-byte fixed header."""
    if len(header_bytes) < 7:
        return None
    b0, b1, b2, b3 = header_bytes[:4]
    if b0 != 255 or b1 & 240 != 240:
        return None
    mpeg_ver = 'MPEG-4' if b1 & 8 == 0 else 'MPEG-2'
    profile_code = b2 >> 6 & 3
    profile_names = ['Main', 'LC', 'SSR', 'LTP']
    profile_str = profile_names[profile_code] if profile_code < len(profile_names) else 'LC'
    sf_idx = b2 >> 2 & 15
    sampling_freqs = {0: 96000, 1: 88200, 2: 64000, 3: 48000, 4: 44100, 5: 32000, 6: 24000, 7: 22050, 8: 16000, 9: 12000, 10: 11025, 11: 8000, 12: 7350}
    sample_rate = sampling_freqs.get(sf_idx, 44100)
    channels = (b2 & 1) << 2 | b3 >> 6 & 3
    return (f'AAC {profile_str} ({mpeg_ver})', channels, sample_rate)

def scan_obb_audio_streams(obb_path: str | Path) -> list[dict]:
    """Scan the entire OBB for all distinct OggS and AAC audio streams.

    Uses the OBB container table for instant scanning when opening 2K OBB containers,
    falling back to linear chunk scanning for arbitrary files.
    """
    path = str(obb_path)
    if not os.path.isfile(path):
        raise FileNotFoundError(f'OBB file not found: {path}')
    else:
        file_size = os.path.getsize(path)
    try:
        from . import obb as obbmod
        parsed = obbmod.Obb(Path(path))
        ogg_entries = [e for e in parsed.entries if parsed.type_name(e) == 'ogg']
        ogg_pages = []
        if ogg_entries:
            with open(path, 'rb') as f:
                for entry in ogg_entries:
                    pos = entry.offset
                    end_pos = min(file_size, entry.offset + entry.length)
                    while pos < end_pos:
                        page = read_page(f, pos, end_pos)
                        if page is None:
                            f.seek(pos)
                            buf = f.read(min(1048576, end_pos - pos))
                            found = buf.find(MAGIC)
                            if found == -1:
                                break
                            else:
                                pos += found
                                continue
                        ogg_pages.append(page)
                        pos = page['end']
        ogg_streams = _group_and_validate_pages(path, ogg_pages) if ogg_pages else []
        aac_streams = []
        with open(path, 'rb') as f:
            for idx, entry in enumerate(parsed.entries):
                f.seek(entry.offset)
                hdr = f.read(min(32, entry.length))
                if len(hdr) >= 7 and hdr[0] == 255 and (hdr[1] & 240 == 240):
                    adts_info = parse_adts_header(hdr)
                    if not adts_info:
                        continue
                    elif not _adts_entry_confirmed(f, entry.offset, entry.length):
                        continue
                    else:
                        codec_name, channels, sample_rate = adts_info
                        aac_streams.append({'serial': entry.name_hash, 'start_offset': entry.offset, 'end_offset': entry.offset + entry.length, 'size': entry.length, 'page_count': 1, 'codec': codec_name, 'channels': channels, 'sample_rate': sample_rate})
        if aac_streams:
            aac_streams.sort(key=lambda s: s['size'], reverse=True)
            return aac_streams
        if ogg_streams:
            return ogg_streams
        if ogg_entries:
            pages = []
            with open(path, 'rb') as f:
                for entry in ogg_entries:
                    pos = entry.offset
                    end_pos = min(file_size, entry.offset + entry.length)
                    while pos < end_pos:
                        page = read_page(f, pos, end_pos)
                        if page is None:
                            f.seek(pos)
                            buf = f.read(min(1048576, end_pos - pos))
                            found = buf.find(MAGIC)
                            if found == -1:
                                break
                            pos += found
                            continue
                        pages.append(page)
                        pos = page['end']
            if pages:
                return _group_and_validate_pages(path, pages)
    except Exception:
        pass
    pages = []
    position = 0
    overlap = len(MAGIC) - 1
    buffer = b''
    buffer_start = 0
    with open(path, 'rb') as f:
        while position < file_size:
            f.seek(position)
            chunk = f.read(CHUNK_SIZE)
            if not chunk:
                break
            data = buffer + chunk
            search = 0
            while True:
                found = data.find(MAGIC, search)
                if found == -1:
                    break
                absolute = buffer_start + found
                page = read_page(f, absolute, file_size)
                if page is not None:
                    pages.append(page)
                search = found + 1
            if len(data) >= overlap:
                buffer = data[-overlap:]
                buffer_start = position + len(chunk) - overlap
            else:
                buffer = data
                buffer_start = position
            position += len(chunk)
    if not pages:
        return []
    return _group_and_validate_pages(path, pages)

def _adts_entry_confirmed(f: BinaryIO, offset: int, length: int) -> bool:
    """Majority-vote check that an entry really holds ADTS AAC frames.

    Reads up to the first 2 KB and validates each candidate frame: the sync
    word, the CRC bit, and the declared frame length must all be consistent
    and every frame must stay inside the entry.  Random binary data rarely
    chains consistent frame lengths, so this rejects texture bytes that
    merely begin with 0xFF 0xFx.
    """
    try:
        f.seek(offset)
        buf = f.read(min(2048, length))
    except OSError:
        return False
    pos = 0
    checked = 0
    good = 0
    while pos + 7 <= len(buf) and checked < 16:
        if buf[pos] != 255 or buf[pos + 1] & 240 != 240:
            break
        is_crc = buf[pos + 1] & 1 == 0
        header_len = 9 if is_crc else 7
        if pos + header_len > len(buf):
            break
        frame_len = (buf[pos + 3] & 3) << 11 | buf[pos + 4] << 3 | buf[pos + 5] >> 5
        if frame_len < header_len or pos + frame_len > length:
            break
        checked += 1
        if frame_len > 0:
            good += 1
            pos += frame_len
        else:
            break
    return checked >= 2 and good == checked

def _group_and_validate_pages(path: str, pages: list[dict]) -> list[dict]:
    """Group pages by serial and sequence into distinct stream candidate records."""
    file_size = os.path.getsize(path)
    pages.sort(key=lambda p: p['offset'])
    candidates = []
    current = None
    for page in pages:
        bos = bool(page['header_type'] & 2)
        eos = bool(page['header_type'] & 4)
        serial = page['serial']
        if bos:
            if current is not None:
                candidates.append(current)
            current = {'serial': serial, 'pages': [page], 'start': page['offset'], 'end': page['end']}
            if eos:
                candidates.append(current)
                current = None
            continue
        elif current is None:
            continue
        elif serial != current['serial']:
            continue
        else:
            previous = current['pages'][-1]
            expected = previous['sequence'] + 1 & 4294967295
            if page['sequence'] != expected:
                candidates.append(current)
                current = None
            else:
                current['pages'].append(page)
                current['end'] = page['end']
                if eos:
                    candidates.append(current)
                    current = None
    if current is not None:
        candidates.append(current)
    valid_streams = []
    with open(path, 'rb') as f:
        for candidate in candidates:
            pages_list = candidate['pages']
            if len(pages_list) < 2:
                continue
            elif not pages_list[0]['header_type'] & 2:
                continue
            elif not pages_list[-1]['header_type'] & 4:
                continue
            else:
                size = candidate['end'] - candidate['start']
                if size < 100:
                    continue
                else:
                    f.seek(candidate['start'])
                    init_data = f.read(min(2048, size))
                    codec, channels, sample_rate = audio_info(init_data)
                    valid_streams.append({'serial': candidate['serial'], 'start_offset': candidate['start'], 'end_offset': candidate['end'], 'size': size, 'page_count': len(pages_list), 'codec': codec, 'channels': channels, 'sample_rate': sample_rate})
    valid_streams.sort(key=lambda s: s['size'], reverse=True)
    return valid_streams

def extract_single_audio_stream(obb_path: str | Path, start_offset: int, size: int, output_path: str | Path) -> bool:
    """Extract a single audio stream to output_path for instant playback or export."""
    src_path = str(obb_path)
    dst_path = str(output_path)
    os.makedirs(os.path.dirname(os.path.abspath(dst_path)), exist_ok=True)
    with open(src_path, 'rb') as src, open(dst_path, 'wb') as dst:
        src.seek(start_offset)
        remaining = size
        while remaining > 0:
            chunk = src.read(min(COPY_SIZE, remaining))
            if not chunk:
                break
            dst.write(chunk)
            remaining -= len(chunk)
    return os.path.exists(dst_path) and os.path.getsize(dst_path) == size

def replace_audio_stream(source_obb: str | Path, start_offset: int, target_size: int, replacement_ogg: str | Path,
    output_obb: str | Path | None=None
) -> bool:
    """Replace an audio stream at start_offset with a new OGG file.

    If output_obb is None or same as source_obb, updates in-place.
    Otherwise copies source to output_obb first.
    """
    src_path = str(source_obb)
    rep_path = str(replacement_ogg)
    if not os.path.isfile(rep_path):
        raise FileNotFoundError(f'Replacement OGG not found: {rep_path}')
    rep_size = os.path.getsize(rep_path)
    if rep_size > target_size:
        raise ValueError(f'Replacement OGG ({rep_size} bytes) exceeds original stream slot ({target_size} bytes)')
    with open(rep_path, 'rb') as rep_f:
        head = rep_f.read(4)
        is_ogg = head == MAGIC
        is_aac = len(head) >= 2 and head[0] == 255 and (head[1] & 240 == 240)
        if not is_ogg and (not is_aac):
            raise ValueError('Replacement file is not a valid OggS or AAC stream')
    dest_path = str(output_obb) if output_obb else src_path
    if dest_path != src_path and (not os.path.exists(dest_path)):
        import shutil
        shutil.copy2(src_path, dest_path)
    with open(dest_path, 'r+b') as dst:
        dst.seek(start_offset)
        with open(rep_path, 'rb') as src:
            remaining = rep_size
            while remaining > 0:
                chunk = src.read(min(COPY_SIZE, remaining))
                if not chunk:
                    break
                dst.write(chunk)
                remaining -= len(chunk)
        padding = target_size - rep_size
        zero_block = b'\x00' * min(COPY_SIZE, padding)
        while padding > 0:
            amt = min(len(zero_block), padding)
            dst.write(zero_block[:amt])
            padding -= amt
    return True
