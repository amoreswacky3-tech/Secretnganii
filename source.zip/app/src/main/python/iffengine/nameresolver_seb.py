"""SebTool-derived extra name candidates (display-only, CRC32-exact).

Source: the SebTool APK's OBB name engine (class n.C0067, recovered by
decompiling its protected ``classes.dex``).  SebTool resolves hash-indexed
OBB entries by brute-forcing candidate filenames against the stored 32-bit
hashes using several hash families.  Measurement across the real
2K16/2K17/2K18/2K19/2K20 main+patch OBBs showed the productive family for
these archives is plain ``zlib.crc32`` over the *lowercase* ASCII spelling
(plus uppercase for some literal system names), so only exact
``crc32(candidate) == entry hash`` matches are stored here.

Core principle (mirrors nameresolver.py, never violated):

    Every entry in this map is a CANDIDATE whose CRC32 was computed at map
    build time.  A look-up therefore only succeeds when the candidate's
    CRC32 is *exactly* the hash stored in the OBB.  Nothing is guessed;
    the container is never modified; this is display information only.

Content mining (SebTool m643/m644/m645 port)
-------------------------------------------
:func:`mine_obb_names` reads the *inside* of small entries (raw text data,
or ZLIB-block entries decompressed on the fly) and extracts filename strings
(ASCII and UTF-16LE runs, with SebTool's strict character filters).  Every
extracted string is CRC32-verified against the archive's hash inventory
exactly like generated candidates, so a mined name is never a guess either.

This module is a leaf: it must not import anything from the package at
module scope (the Obb import inside :func:`mine_obb_names` is local and
optional).
"""

import struct
import time
import zlib

__all__ = ["seb_resolved_name", "mine_obb_names", "mined_name_cache"]

_LITERALS = (
    "titlepage.iff",
    "bootup.iff",
    "gooeyglobal.iff",
    "gooeyfrontend.iff",
    "gooey_bootup.iff",
    "frontend.iff",
    "frontend_sync.iff",
    "frontendlegacy.iff",
    "frontend_legacy.iff",
    "frontendlegacy_sync.iff",
    "frontend_legacy_sync.iff",
    "frontend.bin",
    "global.iff",
    "loadingflow.iff",
    "loadingflowstatic.iff",
    "loadingsequence.bin",
    "englishbootup.iff",
    "english.iff",
    "defaultloadingscreen.iff",
    "loading_static.iff",
    "loading_highlight.iff",
    "loading_career_mode.iff",
    "loading_blacktop.iff",
    "loading_jordan_bootup.iff",
    "loading_flow_render.iff",
    "gooeyoverlaysstatic.iff",
    "logo_2k_square.iff",
    "playerfullpage.iff",
    "teamfullpage.iff",
    "startinglineup3d.iff",
    "titlecardoverlay.iff",
    "wipesprite.iff",
    "wipeteammatchup.iff",
    "teamwipe.iff",
    "studioshow.iff",
    "studioshowwipes.iff",
    "loading_audio.iff",
    "newscorebug.iff",
    "nbaball.iff",
    "ababall.iff",
    "euroball.iff",
    "blackball.iff",
    "worldball.iff",
    "gamedata.iff",
    "gamedataextra.iff",
    "cloth.iff",
    "crowd.iff",
    "crowd_assets.iff",
    "arena.iff",
    "arenadata.iff",
    "playerhead.iff",
    "playerbody.iff",
    "jukeboxmusic.bin",
    "logos_large.iff",
    "logos_medium.iff",
    "logos_small.iff",
    "logos_tiny.iff",
    "logos_large.cdf",
    "logos_medium.cdf",
    "logos_small.cdf",
    "logos_tiny.cdf",
    "streetgamedata.iff",
    "streetscrowd.iff",
    "streetcrowd.iff",
    "mina_crowd.iff",
    "sleeved_wishbone.iff",
    "teams.bin",
    "cwdstrloop_gym.bin",
    "aistreet.bin",
    "asstreet.bin",
    "loadingsequencelebron.bin",
    "loadingsequencejz.bin",
    "loadingvgo_ts.bin",
    "env_amb.bin",
    "paplayers.bin",
    "aplayers.bin",
    "cwdstrloop_inside.bin",
    "loadm.bin",
    "cwdstrsfx_inside.bin",
    "loadingvo.bin",
    "loadingvo_ps.bin",
    "loadingvo_ts.bin",
    "palines.bin",
    "lines.bin",
    "lines_cs.bin",
    "lines_ps.bin",
    "lines_ts.bin",
    "lines_cs_patch.bin",
    "lines_ps_patch.bin",
    "lines_ts_patch.bin",
    "lines_patch.bin",
    "overlayaudio.bin",
    "loadedaudio.iff",
    "pa_audio_set.iff",
    "patchableaudio.iff",
    "pcarmtats.cdf",
    "pcchest.cdf",
    "pcface.cdf",
    "pcface_lo.cdf",
    "pcfacehair.cdf",
    "pchair.cdf",
    "pchead_afro.iff",
    "pchead_afro_hat.iff",
    "pchead_afro_hb.iff",
    "online_player_info.iff",
    "opening_intro.iff",
    "overlay_static.iff",
    "overlay_street_static.iff",
    "crowddata.bin",
    "crowdsfx.bin",
    "crowd_audio.bin",
    "crowd_music.bin",
    "loadingsequence_ts.bin",
    "loadingsequencevgo.bin",
    "loadingvo_jz.bin",
    "loadingvo_lebron.bin",
    "loadingaudio.bin",
    "menuaudio.bin",
    "menu_audio.bin",
    "streetaudio.bin",
    "teamdata.bin",
    "teaminfo.bin",
    "playerinfo.bin",
    "playerdata.bin",
    "paudio.bin",
    "audiolines.bin",
    "audiolookup.bin",
    "soundbank.bin",
    "soundbanks.bin",
    "voicebank.bin",
    "voicebanks.bin",
    "pa_audio_999.iff",
)

_AUDIO_HINTS = (
    "audio",
    "sfx",
    "amb",
    "music",
    "sound",
    "voice",
    "paudio",
    "chatter",
    "jukebox",
    "lines",
    "loadingvo",
    "cwdstr",
    "env_amb",
)


def _is_audio_literal(name: str) -> bool:
    stem = name.rsplit(".", 1)[0]
    return any((hint in stem for hint in _AUDIO_HINTS))


_RANGE_1K = 1000
_RANGE_10K = 10000


def _build_seb_map() -> dict[int, tuple[str, str, str, int]]:
    built = {}

    def add(name: str, category: str, subcategory: str, ident: int) -> None:
        built[zlib.crc32(name.encode("ascii"))] = (name, category, subcategory, ident)

    for lit in _LITERALS:
        cat = "audio" if _is_audio_literal(lit) else "data"
        add(lit, cat, "system", -1)
        add(lit.upper(), cat, "system", -1)

    for i in range(_RANGE_1K):
        add(f"""pa_audio_{i:03d}.iff""", "audio", "pa_audio", i)
        add(f"""pa_audio_{i}.iff""", "audio", "pa_audio", i)
        add(f"""PA_AUDIO_{i:03d}.IFF""", "audio", "pa_audio", i)
        if i < 100:
            add(f"""PA_AUDIO_{i:02d}.IFF""", "audio", "pa_audio", i)
        add(f"""audio_{i:03d}.iff""", "audio", "audio_bank", i)
        add(f"""audio_{i}.iff""", "audio", "audio_bank", i)
        add(f"""audio_420{i:03d}.iff""", "audio", "audio_bank", i)
        add(f"""audio_424{i:03d}.iff""", "audio", "audio_bank", i)
        add(f"""audio_plyr_{i:05d}.iff""", "audio", "audio_bank", i)

    for i in range(_RANGE_10K):
        add(f"""png{i:04d}.iff""", "texture_bank", "face_bank", i)
        add(f"""png{i:04d}_hi.iff""", "texture_bank", "face_bank_hi", i)
        add(f"""png{i:04d}_lo.iff""", "texture_bank", "face_bank_lo", i)
        add(f"""face{i:04d}.iff""", "texture_bank", "face_bank", i)
        add(f"""face{i:04d}_hi.iff""", "texture_bank", "face_bank_hi", i)
        add(f"""face{i:04d}_lo.iff""", "texture_bank", "face_bank_lo", i)

    uniform_side = {"a": "away", "h": "home"}
    alt_side = {"a": "away_alt", "h": "home_alt"}
    for i in range(_RANGE_1K):
        for c in "abcdefgh":
            add(f"""u{c}{i:03d}.iff""", "uniform", uniform_side.get(c, "alt"), i)
            add(f"""u{c}x{i:03d}.iff""", "uniform", alt_side.get(c, "alt"), i)
        add(f"""ux{i:03d}.iff""", "uniform", "alternate", i)
        add(f"""uax{i:03d}.iff""", "uniform", "away_alt", i)
        add(f"""uay{i:03d}.iff""", "uniform", "alt", i)
        add(f"""uhx{i:03d}.iff""", "uniform", "home_alt", i)
        for n in range(1, 10):
            for c in "abcdefgh":
                sub = {"a": "retro_away", "h": "retro_home"}.get(c, "retro_alt")
                add(f"""r{n}{c}{i:03d}.iff""", "uniform", sub, i)
            add(f"""r{n}x{i:03d}.iff""", "uniform", "retro_alt", i)

    for i in range(_RANGE_1K):
        add(f"""s{i:03d}.iff""", "shader", "shader_bank", i)

    for i in range(_RANGE_1K):
        add(f"""team_{i:03d}.iff""", "data", "team_table", i)
        add(f"""team{i:03d}.iff""", "data", "team_table", i)
        add(f"""logo{i:03d}.iff""", "logo", "team_logo", i)
        add(f"""logo{i:03d}_wm.iff""", "logo", "team_logo_wm", i)
        add(f"""logo_{i:03d}.iff""", "logo", "team_logo", i)
        add(f"""logo_{i:03d}_wm.iff""", "logo", "team_logo_wm", i)
        add(f"""crowd{i:03d}.iff""", "crowd", "crowd_asset", i)
        add(f"""crowd_{i:03d}.iff""", "crowd", "crowd_asset", i)
        add(f"""arena{i:03d}.iff""", "arena", "venue", i)
        add(f"""arenadata{i:03d}.iff""", "arena", "venue_data", i)
        add(f"""stadium{i:03d}.iff""", "arena", "venue", i)
        add(f"""stadiumassets{i:03d}.iff""", "arena", "venue_assets", i)
        add(f"""floor{i:03d}.iff""", "court", "floor", i)
        add(f"""court{i:03d}.iff""", "court", "court", i)
        add(f"""court_{i:03d}.iff""", "court", "court", i)
        add(f"""floor_{i:03d}.iff""", "court", "floor", i)
        add(f"""ads{i:03d}.iff""", "arena", "ads", i)
        add(f"""ads_{i:03d}.iff""", "arena", "ads", i)
        add(f"""sponsor_{i:03d}.iff""", "arena", "sponsor", i)
        add(f"""dorna{i:03d}.iff""", "arena", "dorna", i)
        add(f"""DORNA{i:03d}.IFF""", "arena", "dorna", i)
        add(f"""dorna{i:03d}.cdf""", "arena", "dorna", i)
        add(f"""dorna_{i:03d}.iff""", "arena", "dorna", i)
        add(f"""dornas_{i:03d}.iff""", "arena", "dorna", i)
        add(f"""jumbotron_team_{i:03d}.iff""", "arena", "jumbotron", i)
        add(f"""jumbotron_generic_{i:03d}.iff""", "arena", "jumbotron", i)
        add(f"""teamwipe_{i:03d}.iff""", "arena", "wipe", i)
        add(f"""wipeteammatchup_{i:03d}.iff""", "arena", "wipe", i)
    return built


_SEB_BY_HASH: dict[int, tuple[str, str, str, int]] | None = None


def _seb_map() -> dict[int, tuple[str, str, str, int]]:
    global _SEB_BY_HASH
    if _SEB_BY_HASH is None:
        _SEB_BY_HASH = _build_seb_map()
    return _SEB_BY_HASH


def seb_resolved_name(name_hash: int) -> tuple[str, str, str, int] | None:
    """Fallback resolution: exact CRC32 match against SebTool candidates."""
    return _seb_map().get(name_hash)


_MINE_EXT = (
    ".iff",
    ".bin",
    ".cdf",
    ".ros",
    ".ogg",
    ".wav",
    ".mp3",
    ".dds",
    ".n2km",
    ".png",
    ".jpg",
)

_MINE_RAW_MAX = 1048576
_MINE_OPEN_MAX = 2097152
_MINE_DECOMP_BUDGET = 4194304
_MINE_MAX_ENTRIES = 600
_MINE_TIME_BUDGET = 8.0
_MINE_MIN_RUN = 3
_MINE_MAX_LEN = 160


def _printable(byte_val: int) -> bool:
    return 32 <= byte_val <= 126


def _extract_runs(data: bytes) -> set:
    """ASCII + UTF-16LE printable runs (m643's dual-encoding scan)."""
    found = set()
    n = len(data)
    start = None
    for i in range(n):
        if _printable(data[i]):
            if start is None:
                start = i
            continue

        if start is not None and _MINE_MIN_RUN <= i - start <= _MINE_MAX_LEN:
            found.add(data[start:i].decode("ascii", "ignore"))
        start = None

    if start is not None and _MINE_MIN_RUN <= n - start <= _MINE_MAX_LEN:
        found.add(data[start:].decode("ascii", "ignore"))
    i = 0
    while i + 1 < n:
        if _printable(data[i]) and data[i + 1] == 0:
            j = i
            buf = bytearray()
            while j + 1 < n and _printable(data[j]) and data[j + 1] == 0:
                buf.append(data[j])
                j += 2
            if _MINE_MIN_RUN <= len(buf) <= _MINE_MAX_LEN:
                found.add(buf.decode("ascii", "ignore"))
            i = j
        else:
            i += 1
    return found


def _mine_filter(raw: str) -> bool:
    """m645's filename acceptance test (basename, ext, charset, no spaces)."""
    s = raw.strip()
    cut = max(s.rfind("/"), s.rfind("\\"))
    if cut >= 0:
        s = s[cut + 1:]

    if not _MINE_MIN_RUN <= len(s) <= _MINE_MAX_LEN:
        return False

    if not s.lower().endswith(_MINE_EXT):
        return False

    for ch in s:
        if not _printable(ord(ch) & 255):
            return False

    if " " in s or "=" in s or ":" in s:
        return False
    return True


def _parse_zlib_blocks(data: bytes, budget: list):
    """Yield decompressed payloads from ZLIB-block data (TKM's obb layout)."""
    pos = 0
    n = len(data)
    while pos + 16 <= n:
        if data[pos:pos + 4] != b"ZLIB":
            break
        _unpacked, stored, _flags = struct.unpack_from(">III", data, pos + 4)
        packed = stored - 16
        if packed <= 0 or pos + stored > n:
            break

        try:
            out = zlib.decompress(data[pos + 16:pos + stored])
        except zlib.error:
            break
        budget[0] -= len(out)
        if budget[0] < 0:
            break
        yield out
        pos += stored


def mine_obb_names(obb_path: str, entry_hashes: set, progress=None) -> dict:
    'Mine filenames out of small entries; CRC32-verify against the archive.\n\n    Only hashes present in ``entry_hashes`` are reported.  Returns\n    ``{"cache": {hash: name}, "mined": strings_seen, "scanned": entries}``.\n    Deterministic per archive; wrap with :func:`mined_name_cache`.\n    '
    t0 = time.monotonic()
    from pathlib import Path
    path = Path(obb_path)
    cache = {}
    strings_seen = set()
    try:
        from .obb import Obb
        obb_obj = Obb(path)
    except Exception:
        return {"cache": cache, "mined": 0, "scanned": 0}
    candidates = sorted(((e.offset, e.length, obb_obj.stored_size(e)) for e in obb_obj.entries if 0 < e.length <= _MINE_RAW_MAX), key=lambda item: item[1])[:_MINE_MAX_ENTRIES]
    budget = [_MINE_DECOMP_BUDGET]
    TYPE_COMPRESSED = b"\x94\xed;\xff"
    TYPE_ZLIB = b"ZLIB"
    scanned = 0
    with path.open("rb") as f:
        for offset, length, stored in candidates:
            if time.monotonic() - t0 > _MINE_TIME_BUDGET or budget[0] <= 0:
                break
            if stored > _MINE_OPEN_MAX:
                continue
            try:
                f.seek(offset)
                head = f.read(4)
                if len(head) < 4:
                    continue
                if head == TYPE_COMPRESSED:
                    f.seek(offset)
                    raw = f.read(min(length, _MINE_OPEN_MAX))
                    if raw[:4] != TYPE_COMPRESSED:
                        continue
                    rel = struct.unpack_from("<I", raw, 4)[0]
                    if not 8 <= rel < len(raw):
                        continue
                    payload = next(_parse_zlib_blocks(raw[rel:], budget), b"")
                elif head == TYPE_ZLIB:
                    raw = f.read(min(stored, _MINE_OPEN_MAX))
                    payload = next(_parse_zlib_blocks(raw, budget), b"")
                else:
                    payload = f.read(min(length, _MINE_RAW_MAX))
                    budget[0] -= len(payload)
            except Exception:
                continue
            scanned += 1
            if not payload:
                continue
            for cand in _extract_runs(payload):
                if not _mine_filter(cand):
                    continue
                strings_seen.add(cand)
                low = cand.lower()
                for spelling in (low, cand, cand.upper()):
                    h = zlib.crc32(spelling.encode("ascii")) & 4294967295
                    if h in entry_hashes and h not in cache:
                        cache[h] = spelling
            if progress is not None and scanned % 200 == 0:
                try:
                    progress(scanned, len(candidates))
                except Exception:
                    pass
    return {"cache": cache, "mined": len(strings_seen), "scanned": scanned}


_MINED_CACHE: dict = {}


def mined_name_cache(obb_path: str, entry_hashes: set, progress=None) -> dict:
    """Memoised wrapper around :func:`mine_obb_names` (per path+size+mtime)."""
    from pathlib import Path
    key_path = Path(obb_path)
    try:
        stat = key_path.stat()
        key = (str(key_path), stat.st_size, stat.st_mtime)
    except OSError:
        key = (str(key_path), 0, 0.0)
    cached = _MINED_CACHE.get(key)
    if cached is not None:
        return cached
    result = mine_obb_names(str(key_path), entry_hashes, progress)
    _MINED_CACHE[key] = result
    return result
