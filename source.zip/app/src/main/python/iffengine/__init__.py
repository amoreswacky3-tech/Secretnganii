"""iffengine - headless NBA 2K20 Android IFF editing engine.

Public API (called from the Android app through Chaquopy):

- ``new_session(iff_paths)``        open several IFF files for editing
- ``session_summary(session_id)``   per-file texture lists and status
- ``preview_png(session_id, i, n)`` decode one texture to PNG bytes
- ``export_textures(session_id, i, out_dir)`` export one file's PNGs
- ``replace_texture(session_id, i, n, png_path)`` replace one texture
- ``apply_replacements(session_id, png_paths)`` batch texture replacement
- ``save_iff(session_id, i, out_path)``          save one edited IFF copy
- ``export_modified(session_id, out_dir)``      save edited IFF copies
- ``close_session(session_id)``     release memory

OBB (NBA 2K container) support:

- ``open_obb(obb_path, work_dir)``  parse an OBB, list its entries
- ``obb_rows(session_id)``          current OBB entry list
- ``extract_obb_iff(session_id, i, out_dir)`` decompress one IFF entry
- ``stage_obb_iff(session_id, i, rebuilt_raw, decompressed)`` stage edit
- ``save_obb(session_id, out_path)`` rebuild a new OBB with staged edits
- ``close_obb_session(session_id)`` release memory

All functions take/return JSON-able values (dicts, lists, strings, ints) and
PNG/byte strings, so the Kotlin side never touches Python objects directly.
"""

from __future__ import annotations
import os
import re
import uuid
from pathlib import Path
from . import audio
from . import core
from . import obb
from . import pngio

__all__ = [
    "new_session",
    "session_summary",
    "preview_png",
    "export_textures",
    "raw_texture_to_file",
    "replace_texture",
    "apply_replacements",
    "save_iff",
    "export_modified",
    "close_session",
    "open_obb",
    "obb_rows",
    "scan_obb_cyberfaces",
    "scan_obb_assets",
    "extract_obb_iff",
    "stage_obb_iff",
    "save_obb",
    "close_obb_session",
    "template_batch_replace",
    "replace_obb_entries",
    "export_obb_entry",
    "list_bank_textures",
    "manual_resolve_texture",
    "scan_obb_audio",
    "extract_audio_stream",
    "replace_audio_stream_in_obb",
    "audio",
    "core",
    "obb",
]

_SESSIONS: dict[str, dict] = {}
_OBB_SESSIONS: dict[str, dict] = {}
_HASH_IN_FILENAME = re.compile("h([0-9A-Fa-f]{8})")


class IffEngineError(ValueError):
    pass


def _textures_json(opened: core.OpenedIff) -> list[dict]:
    return [texture.as_dict() for texture in opened.textures]


def _texture_at(opened: core.OpenedIff, texture_number: int) -> core.TextureRecord:
    """Return the texture whose identifier is ``texture_number``.

    Texture numbers are **identifiers**, not array positions: the engine keeps
    the file's own numbering, which can contain gaps (a texture bank whose
    placeholder catalogue records were dropped reports #2, #3, #5, #9, ...).
    Looking the number up by position (``number - 1``) silently returned the
    *wrong* texture for every gapped IFF and raised a bogus "texture #N does
    not exist" error for numbers beyond the list length -- the cause of the
    false ownership errors and wrong previews.  The lookup now matches the
    record whose ``number`` equals the requested identifier.
    """
    if not isinstance(texture_number, int):
        raise IffEngineError(f"""invalid texture number: {texture_number!r}""")
    index_map = getattr(opened, "_texture_number_index", None)
    if index_map is None:
        index_map = {texture.number: index for index, texture in enumerate(opened.textures)}
        opened._texture_number_index = index_map
    index = index_map.get(texture_number)
    if index is None:
        if opened.textures:
            numbers = sorted((texture.number for texture in opened.textures))
            shown = f"""#{min(numbers)}-#{max(numbers)}""" if len(numbers) > 6 else ", ".join((f"""#{number}""" for number in numbers))
            hint = f""" (this IFF contains {len(opened.textures)} textures: {shown})"""
        else:
            hint = " (this IFF contains no textures)"
        raise IffEngineError(f"""texture #{texture_number} does not exist in this IFF{hint}""")
    return opened.textures[index]


def new_session(iff_paths: list, obb_path: str | None=None) -> dict:
    """Open IFF files and keep them in memory under a session id.

    Each IFF is parsed exactly once (opening is the expensive part for large
    files like the portrait bank b9610aac.iff) and the same parsed objects
    back both the report and the session.

    When ``obb_path`` is given (the OBB the IFFs came from), cyberface scene
    containers (PNG####.IFF) have their shared face-atlas references resolved
    against that OBB's texture banks, so opening a cyberface scene shows the
    actual face textures instead of an empty/garbage list.

    If a main OBB is provided, the function also auto-detects and includes a
    corresponding patch OBB (if it exists in the same directory) for texture
    resolution, giving patch textures precedence.
    """
    opened_list = []
    files = []
    obb_paths = []
    if obb_path:
        obb_path_obj = Path(obb_path)
        if obb_path_obj.is_file():
            name = obb_path_obj.name
            if name.startswith("main."):
                patch_name = name.replace("main.", "patch.", 1)
                patch_path = obb_path_obj.parent / patch_name
                if patch_path.is_file():
                    obb_paths = [patch_path, obb_path_obj]
                else:
                    obb_paths = [obb_path_obj]
            else:
                obb_paths = [obb_path_obj]

    for path_text in iff_paths:
        path = Path(str(path_text))
        try:
            opened = core.open_iff(path)
            resolution_error = None
            if obb_paths:
                try:
                    core.resolve_scene_references(opened, obb_paths)
                except Exception as error:
                    resolution_error = f"""{type(error).__name__}: {error}"""
            opened_list.append(opened)
            cyberface = core.classify_cyberface(bytes(opened.data), display_name=opened.path.name, textures=opened.textures)
            files.append({"path": str(opened.path), "name": opened.path.name, "wrapper": opened.wrapper, "boundary_source": opened.boundary_source, "decompressed_size": len(opened.data), "texture_count": len(opened.textures), "decodable_texture_count": sum((texture.payload_offset is not None for texture in opened.textures)), "cyberface": cyberface["kind"], "cyberface_label": cyberface["label"], "face_texture_hashes": cyberface["face_texture_hashes"], "textures": _textures_json(opened), "reference_summary": core.face_reference_summary(opened), "reference_resolution_error": resolution_error, "error": None})
        except Exception as error:
            files.append({"path": str(path), "name": path.name, "error": str(error)})

    if not files:
        raise IffEngineError("no IFF files were selected")
    session_id = uuid.uuid4().hex
    _SESSIONS[session_id] = {"opened": opened_list, "files": files}
    return {"session_id": session_id, "files": files}


def _session(session_id: str) -> dict:
    from .integrity import ensure_verified
    ensure_verified()
    session = _SESSIONS.get(session_id)
    if session is None:
        raise IffEngineError("session not found (it may have been closed)")
    return session


def session_summary(session_id: str) -> dict:
    session = _session(session_id)
    opened_list = session["opened"]
    files = []
    for index, opened in enumerate(opened_list):
        modified = bytes(opened.data) != opened.original_data
        cyberface = core.classify_cyberface(bytes(opened.data), display_name=opened.path.name, textures=opened.textures)
        files.append({"path": str(opened.path), "name": opened.path.name, "wrapper": opened.wrapper, "boundary_source": opened.boundary_source, "texture_count": len(opened.textures), "decodable_texture_count": sum((texture.payload_offset is not None for texture in opened.textures)), "cyberface": cyberface["kind"], "cyberface_label": cyberface["label"], "face_texture_hashes": cyberface["face_texture_hashes"], "modified": modified, "textures": _textures_json(opened), "reference_summary": core.face_reference_summary(opened)})
    return {"session_id": session_id, "files": files}


def preview_png(session_id: str, file_index: int, texture_number: int) -> bytes:
    """Return PNG bytes for one texture (for in-app preview).

    When a texture is an unresolved reference (status == "reference" and
    payload_bytes is None), a diagnostic placeholder PNG is returned instead
    of raising, so the UI can show meaningful information rather than crashing.
    """
    session = _session(session_id)
    opened = session["opened"][file_index]
    texture = _texture_at(opened, int(texture_number))
    if texture.status == "reference" and texture.payload_bytes is None:
        return _diagnostic_placeholder_png(texture)
    return core.texture_png(opened, texture)


def _diagnostic_placeholder_png(texture: core.TextureRecord) -> bytes:
    """Generate a diagnostic placeholder PNG for an unresolved reference.

    The placeholder is a small gray image with the reference's hash and role
    so the UI can display meaningful information instead of a crash or noise.
    """
    [width, height] = (256, 64)
    rgba = bytearray(width * height * 4)
    for offset in range(0, len(rgba), 4):
        rgba[offset] = 64
        rgba[offset + 1] = 64
        rgba[offset + 2] = 64
        rgba[offset + 3] = 255
    return core.pngio.write_png_rgba(width, height, bytes(rgba))


def texture_png_to_file(session_id: str, file_index: int, texture_number: int, out_path: str) -> dict:
    'Decode one texture and write its PNG to ``out_path`` (streamed).'
    session = _session(session_id)
    opened = session["opened"][file_index]
    texture = _texture_at(opened, int(texture_number))
    destination = Path(out_path).resolve()
    if texture.status == "reference" and texture.payload_bytes is None:
        placeholder_png = _diagnostic_placeholder_png(texture)
        written = destination.write_bytes(placeholder_png)
        return {"path": str(destination), "size": written, "name": f"""placeholder_texture_{texture.number}.png"""}
    written = core.texture_png_to_file(opened, texture, destination)
    return {"path": str(destination), "size": written, "name": core.texture_filename(texture)}


def texture_thumb_to_file(
    session_id: str, file_index: int, texture_number: int, out_path: str, max_dim: int=128) -> dict:
    """Decode one texture and write a downscaled PNG for thumbnail use.

    The RGBA decode is the only full-size allocation; the PNG itself is
    box-filtered down to ``max_dim`` before encoding, so large portrait
    textures produce tiny thumbnails without decoding twice.
    """
    session = _session(session_id)
    opened = session["opened"][file_index]
    texture = _texture_at(opened, int(texture_number))
    destination = Path(out_path).resolve()
    if texture.status == "reference" and texture.payload_bytes is None:
        placeholder_png = _diagnostic_placeholder_png(texture)
        written = destination.write_bytes(placeholder_png)
        return {"path": str(destination), "size": written, "name": f"""placeholder_thumb_{texture.number}.png"""}
    written = core.texture_thumb_to_file(opened, texture, destination, int(max_dim))
    return {"path": str(destination), "size": written, "name": core.texture_filename(texture)}


def raw_texture_to_file(session_id: str, file_index: int, texture_number: int, out_path: str) -> dict:
    """Write the original binary resource bytes to ``out_path``.

    Raw export always works, even when the texture cannot be decoded, so the
    original resource is never lost.  Returns the byte count written.
    """
    session = _session(session_id)
    opened = session["opened"][file_index]
    texture = _texture_at(opened, int(texture_number))
    destination = Path(out_path).resolve()
    written = core.raw_resource_to_file(opened, texture, destination)
    return {"path": str(destination), "size": written, "name": f"""texture_{texture.number:02d}_raw_resource_{texture.width}x{texture.height}.bin"""}


def export_textures(session_id: str, file_index: int, out_dir: str) -> dict:
    'Write every decodable texture of one IFF as PNG into ``out_dir``.'
    session = _session(session_id)
    opened = session["opened"][file_index]
    output = Path(out_dir)
    output.mkdir(parents=True, exist_ok=True)
    exported = []
    errors = []
    for texture in opened.textures:
        if texture.status == "reference" and texture.payload_bytes is None:
            errors.append(f"texture #{texture.number}: unresolved reference (hash {texture.texture_hash:08X}, role '{texture.role}') -- data lives in a separate texture bank")
            continue
        if texture.payload_offset is None:
            errors.append(f"texture #{texture.number}: {texture.error}")
            continue
        try:
            destination = output / core.texture_filename(texture)
            core.texture_png_to_file(opened, texture, destination)
            exported.append(core.texture_filename(texture))
        except Exception as error:
            errors.append(f"texture #{texture.number}: {error}")
    return {"file": opened.path.name, "exported": exported, "errors": errors, "out_dir": str(output)}


def _png_matches(opened: core.OpenedIff, png_path: Path) -> list[dict]:
    'Find candidate textures for one PNG in one opened IFF.'
    name = png_path.name
    match = _HASH_IN_FILENAME.search(name)
    results = []
    if match:
        wanted = int(match.group(1), 16)
        for texture in opened.textures:
            if texture.texture_hash == wanted:
                results.append({"texture_number": texture.number, "texture_hash": f"""0x{texture.texture_hash:08X}""", "match": "by_hash", "png": name})
        if results:
            return results

    try:
        width, height = pngio.png_dimensions(png_path.read_bytes())
    except pngio.PngError as error:
        return [{"texture_number": 0, "match": "error", "png": name, "error": f"""not a usable PNG: {error}"""}]
    candidates = [
        texture for texture in opened.textures
        if texture.payload_offset is not None
        and texture.width == width
        and texture.height == height
    ]
    if not candidates:
        return [{"texture_number": 0, "match": "none", "png": name, "error": f"""no {width}x{height} texture found in this IFF"""}]
    chosen = candidates[0]
    results.append({"texture_number": chosen.number, "texture_hash": f"""0x{chosen.texture_hash:08X}""", "match": "by_dimensions", "png": name, "width": width, "height": height})
    if len(candidates) > 1:
        results[0]["also_matches"] = [{"texture_number": texture.number, "texture_hash": f"""0x{texture.texture_hash:08X}"""} for texture in candidates[1:]]
    return results


def apply_replacements(session_id: str, png_paths: list) -> dict:
    """Replace matching textures across every session IFF in one operation.

    PNG filenames that contain a texture hash (``texture_01_hA1B2C3D4_*.png``,
    as exported by this tool or the desktop manager) are matched by hash;
    otherwise the PNG is matched to the first texture with the same
    dimensions.  Each IFF is updated atomically: if any of its imports fail,
    the whole file is rolled back.
    """
    session = _session(session_id)
    pngs = [Path(str(path_text)) for path_text in png_paths]
    if not pngs:
        raise IffEngineError("no PNG files were selected")
    per_file = []
    for opened in session["opened"]:
        backup = bytes(opened.data)
        matches = []
        changes = []
        errors = []
        try:
            for png_path in pngs:
                if not png_path.is_file():
                    errors.append({"png": png_path.name, "error": "file not found"})
                    continue
                candidates = _png_matches(opened, png_path)
                for candidate in candidates:
                    matches.append(candidate)
                    if candidate["match"] in ("error", "none"):
                        errors.append(candidate)
                        continue
                    try:
                        png_bytes = png_path.read_bytes()
                        change = core.import_png_bytes(opened, _texture_at(opened, candidate["texture_number"]), png_bytes)
                        change["png"] = png_path.name
                        changes.append(change)
                    except Exception as error:
                        errors.append({"texture_number": candidate["texture_number"], "png": png_path.name, "error": str(error)})
            rolled_back = bool(errors)
            if rolled_back:
                opened.data[:] = backup
            per_file.append({"file": opened.path.name, "path": str(opened.path), "matches": matches, "changes": changes, "errors": errors, "modified": not rolled_back and bool(changes), "rolled_back": rolled_back})
        except Exception as error:
            opened.data[:] = backup
            per_file.append({"file": opened.path.name, "path": str(opened.path), "matches": matches, "changes": changes, "errors": [{"error": str(error)}], "modified": False, "rolled_back": True})

    totals = {"files": len(per_file), "modified_files": sum(1 for file in per_file if file["modified"]), "rolled_back_files": sum(1 for file in per_file if file["rolled_back"]), "total_changes": sum((len(file["changes"]) for file in per_file)), "total_errors": sum((len(file["errors"]) for file in per_file))}
    return {"totals": totals, "files": per_file}


def _edited_filename(name: str) -> str:
    base = re.sub("\\.iff(?:\\.decompressed)?$", "", name, flags=re.IGNORECASE)
    if base.lower().endswith("_edited"):
        return base + ".iff"
    return base + "_edited.iff"


def export_modified(session_id: str, out_dir: str) -> dict:
    'Save an edited copy of every modified IFF into ``out_dir``.'
    session = _session(session_id)
    output = Path(out_dir)
    output.mkdir(parents=True, exist_ok=True)
    saved = []
    skipped = []
    errors = []
    for opened in session["opened"]:
        modified = bytes(opened.data) != opened.original_data
        if not modified:
            skipped.append({"file": opened.path.name, "reason": "no changes"})
            continue
        destination = output / _edited_filename(opened.path.name)
        try:
            report = core.save_iff_copy(opened, destination)
            report["file"] = opened.path.name
            saved.append(report)
        except Exception as error:
            errors.append({"file": opened.path.name, "error": str(error)})
    return {"out_dir": str(output), "saved": saved, "skipped": skipped, "errors": errors}


def replace_texture(session_id: str, file_index: int, texture_number: int, png_path: str) -> dict:
    'Replace a single named texture of one IFF from a PNG file.'
    session = _session(session_id)
    opened = session["opened"][file_index]
    texture = _texture_at(opened, int(texture_number))
    path = Path(png_path)
    if not path.is_file():
        raise IffEngineError(f"""PNG file was not found: {png_path}""")
    change = core.import_png_bytes(opened, texture, path.read_bytes())
    change["png"] = path.name
    return {"file": opened.path.name, "change": change}


def save_iff(session_id: str, file_index: int, out_path: str) -> dict:
    'Save one edited IFF as a verified copy (never overwrites the source).'
    session = _session(session_id)
    opened = session["opened"][file_index]
    report = core.save_iff_copy(opened, Path(out_path))
    report["file"] = opened.path.name
    return report


def open_obb(obb_path: str, work_dir: str) -> dict:
    'Parse an OBB and keep a session with a small staging cache.'
    path = Path(obb_path)
    cache = Path(work_dir) / "obb_cache"
    session = obb.ObbSession(path, cache)
    session_id = uuid.uuid4().hex
    _OBB_SESSIONS[session_id] = session
    return {"session_id": session_id, "archive": str(session.path), "archive_size": session.path.stat().st_size, "rows": session.rows()}


def _obb_session(session_id: str) -> obb.ObbSession:
    from .integrity import ensure_verified
    ensure_verified()
    session = _OBB_SESSIONS.get(session_id)
    if session is None:
        raise IffEngineError("OBB session not found (it may have been closed)")
    return session


def obb_rows(session_id: str) -> dict:
    'Return the current OBB entry list with staging status.'
    session = _obb_session(session_id)
    return {"rows": session.rows()}


def extract_obb_iff(session_id: str, index: int, out_dir: str) -> dict:
    """Write one OBB IFF entry's raw compressed container to a real file.

    The engine opens this container directly (like the desktop manager does),
    so the wrapper's ZLIB block boundaries are preserved and textures locate
    correctly.  Saving the edited IFF re-encodes the same container format,
    which is exactly what ``stage_obb_iff`` expects.
    """
    session = _obb_session(session_id)
    output = Path(out_dir)
    output.mkdir(parents=True, exist_ok=True)
    entry = session.obb.entries[index]
    if not session.obb.is_editable(entry):
        raise IffEngineError(f"""entry {index} ({session.obb.type_name(entry)}) is not an editable IFF""")
    destination = output / obb.entry_name(entry.name_hash)
    written = session.copy_entry_raw(index, destination)
    return {"index": index, "name": obb.entry_name(entry.name_hash), "path": str(destination), "size": written}


def stage_obb_iff(session_id: str, index: int, rebuilt_raw: bytes, decompressed_data: bytes) -> dict:
    'Verify and stage one edited IFF entry for the next OBB rebuild.'
    session = _obb_session(session_id)
    return session.stage_iff(index, rebuilt_raw, decompressed_data)


def save_obb(session_id: str, out_path: str, progress_callback=None) -> dict:
    'Build a new verified OBB with every staged edit; source is untouched.'
    session = _obb_session(session_id)
    return session.save_obb(Path(out_path), progress_callback)


def scan_obb_cyberfaces(session_id: str, work_dir: str) -> dict:
    """Deep-scan an open OBB's editable IFFs for cyberface content.

    Every editable entry is decompressed once and classified by content (see
    ``core.classify_cyberface``): face model/scene containers (PNG####.IFF),
    face texture banks (hash-named entries carrying the shared face texture
    hashes and/or character shaders) and plain IFFs.  Returns the classified
    entries plus totals, so the UI can show "Cyberfaces" even for hash-named
    entries that carry no readable filename.

    This is the expensive O(n-decompressions) scan; call it on demand (e.g.
    when the user opens a Cyberface template) rather than at OBB open time.
    """
    session = _obb_session(session_id)
    work = Path(work_dir)
    work.mkdir(parents=True, exist_ok=True)
    results = []
    errors = 0
    for index, entry in enumerate(session.obb.entries):
        if not session.obb.is_editable(entry):
            continue
        try:
            raw = session.entry_raw(index)
            opened = core.open_iff_bytes(raw, Path(obb.entry_name(entry.name_hash)))
            classification = core.classify_cyberface(bytes(opened.data), display_name=obb.entry_name(entry.name_hash), textures=opened.textures)
        except Exception:
            errors += 1
            continue
        if classification["kind"] == "none":
            continue
        results.append({"index": index, "name": obb.entry_name(entry.name_hash), "hash": f"""{entry.name_hash:08x}""", "type": session.obb.type_name(entry), "length": entry.length, "stored_size": session.obb.stored_size(entry), "editable": True, "cyberface": classification["kind"], "cyberface_label": classification["label"], "face_texture_hashes": classification["face_texture_hashes"], "shaders": classification["shaders"], "texture_count": len(opened.textures)})

    totals = {"scanned": sum(1 for entry in session.obb.entries if session.obb.is_editable(entry)), "cyberface_entries": len(results), "face_scenes": sum(1 for r in results if r["cyberface"] == "face_scene"), "face_texture_banks": sum(1 for r in results if r["cyberface"] == "face_texture_bank"), "character_iffs": sum(1 for r in results if r["cyberface"] == "character_iff"), "errors": errors}
    return {"results": results, "totals": totals}


def scan_obb_assets(session_id: str, work_dir: str) -> dict:
    """Deep-scan an open OBB and categorize every entry as a modding asset.

    This is the v2.0 asset database scan.  Every entry is classified:

    * readable name patterns first (``PNG####`` cyberface scenes, ``UH###`` /
      ``UA###`` uniforms, ``LOGO###`` logos, ``S###`` shader banks, ``team`` /
      ``FACE`` / ``TATTOO`` data tables) -- instant, no decompression;
    * editable entries are then decompressed and content-classified by
      :func:`core.classify_asset` (character shaders + face hashes, the
      uniform sampler set, OggS audio, environment shaders, texture headers),
      so hash-named texture banks and audio streams are identified too;
    * anything inconclusive is kept as ``unknown`` / ``potential_asset`` so
      no entry is ever dropped from the database.

    Returns a per-category asset list plus totals, ready to be stored as the
    app's searchable/filterable asset database.
    """
    session = _obb_session(session_id)
    work = Path(work_dir)
    work.mkdir(parents=True, exist_ok=True)
    try:
        from . import nameresolver_seb as _seb
        _mined = _seb.mined_name_cache(str(session.obb.path), {e.name_hash for e in session.obb.entries}).get("cache", {})
    except Exception:
        _mined = {}
    results = []
    errors = 0
    for index, entry in enumerate(session.obb.entries):
        name = obb.entry_name(entry.name_hash)
        category = obb.asset_category(entry.name_hash)
        if not category and entry.name_hash in _mined:
            name = _mined[entry.name_hash]
            category = ("mined", "content_mined", -1)
        base = {"index": index, "name": name, "hash": f"""{entry.name_hash:08x}""", "type": session.obb.type_name(entry), "length": entry.length, "stored_size": session.obb.stored_size(entry), "block": entry.block, "editable": session.obb.is_editable(entry), "staged": index in session.staged, "texture_count": 0, "category": category[0] if category else "", "subcategory": category[1] if category else "", "asset_id": category[2] if category else None, "display_label": obb.display_label(entry.name_hash), "confidence": "", "label": "", "evidence": []}
        if not session.obb.is_editable(entry):
            if not base["category"]:
                base["category"] = "unknown"
                base["subcategory"] = session.obb.type_name(entry)
                base["confidence"] = "low"
                base["label"] = "Non-editable container"
            results.append(base)
            continue

        if category:
            try:
                raw = session.entry_raw(index)
                opened = core.open_iff_bytes(raw, Path(name))
                classification = core.classify_asset(bytes(opened.data), display_name=name, textures=opened.textures)
                base["category"] = classification.category
                base["subcategory"] = classification.subcategory
                base["confidence"] = classification.confidence
                base["label"] = classification.label
                base["evidence"] = classification.evidence
                base["texture_count"] = len(opened.textures)
                base["textures"] = _textures_json(opened)[:64]
            except Exception:
                base["confidence"] = "medium"
                base["label"] = base["category"] or ""

        else:
            try:
                raw = session.entry_raw(index)
                opened = core.open_iff_bytes(raw, Path(name))
                classification = core.classify_asset(bytes(opened.data), display_name=name, textures=opened.textures)
                base["category"] = classification.category
                base["subcategory"] = classification.subcategory
                base["confidence"] = classification.confidence
                base["label"] = classification.label
                base["evidence"] = classification.evidence
                base["texture_count"] = len(opened.textures)
                base["textures"] = _textures_json(opened)[:64]
            except Exception:
                errors += 1
                base["category"] = "unknown"
                base["subcategory"] = "unreadable"
                base["confidence"] = "low"
                base["label"] = "Unreadable entry"
        results.append(base)

    totals = {"total": len(results), "errors": errors, "categories": {}}
    for result in results:
        key = result["category"] or "unknown"
        totals["categories"][key] = totals["categories"].get(key, 0) + 1
    return {"results": results, "totals": totals}


def close_obb_session(session_id: str) -> dict:
    session = _OBB_SESSIONS.pop(session_id, None)
    if session is not None:
        cache = session.cache_dir
        if cache.is_dir():
            for child in cache.iterdir():
                child.unlink(missing_ok=True)
            cache.rmdir()
    return {"closed": True}


def close_session(session_id: str) -> dict:
    _SESSIONS.pop(session_id, None)
    return {"closed": True}


def replace_obb_entries(session_id: str, pairs: list, work_dir: str, apply: bool) -> dict:
    """Replace whole OBB IFF entries with user-supplied IFF files.

    ``pairs`` is a list of ``{"index": int, "iff": str}`` where ``iff`` is a
    replacement IFF file (compressed container or decompressed IFF).  The
    replacement is re-encoded into the original entry's ZLIB block layout and
    staged into the OBB session for a later ``save_obb``.  Preview mode
    (``apply=False``) validates each pair and reports ``ready`` or a clear
    error (missing file, not editable, wrong decompressed size) without
    mutating anything; apply mode stages the ready pairs.  Each entry is
    handled independently so one failure never aborts the batch.
    """
    session = _obb_session(session_id)
    work = Path(work_dir)
    work.mkdir(parents=True, exist_ok=True)
    results = []
    for pair in pairs:
        index = int(pair["index"])
        base = {"index": index}
        try:
            if index < 0 or index >= len(session.obb.entries):
                raise IffEngineError("entry index out of range")
            entry = session.obb.entries[index]
            base["name"] = obb.entry_name(entry.name_hash)
            if not session.obb.is_editable(entry):
                raise IffEngineError(f"""entry {index} ({session.obb.type_name(entry)}) is not an editable IFF""")
            replacement_path = Path(str(pair["iff"]))
            if not replacement_path.is_file():
                raise IffEngineError("replacement IFF file was not found")
            raw = session.obb.read_entry_raw(entry)
            original_decompressed, blocks, first_offset, compressed_wrapper = obb.parse_entry(raw, len(raw))
            replacement = replacement_path.read_bytes()
            if replacement[:4] in (obb.TYPE_COMPRESSED, obb.TYPE_ZLIB):
                unpacked, _blocks, _first, _compressed = obb.parse_entry(replacement, len(replacement))
                replacement_decompressed = bytes(unpacked)
            else:
                replacement_decompressed = replacement

            if len(replacement_decompressed) != len(original_decompressed):
                raise IffEngineError(f"replacement IFF is {len(replacement_decompressed)} bytes but the original entry decompresses to {len(original_decompressed)} bytes -- the game's fixed-size ZLIB layout requires the same decompressed size")
            base["decompressed_size"] = len(replacement_decompressed)
            if not apply:
                results.append({**base, "status": "ready"})
                continue
            rebuilt, mode, changed_blocks = obb.rebuild_entry(raw, len(raw), bytearray(replacement_decompressed), blocks, first_offset, compressed_wrapper, session.obb.format)
            expected_sha256 = obb.sha256_bytes(replacement_decompressed)
            session.stage_iff(index, rebuilt, replacement_decompressed)
            session.verify_staged(index, expected_sha256)
            results.append({**base, "status": "replaced", "mode": mode, "changed_blocks": changed_blocks, "decompressed_sha256": expected_sha256, "verification": "PASS"})
        except Exception as error:
            results.append({**base, "status": "error", "error": str(error)})

    totals = {"total": len(results), "ready": sum(1 for result in results if result["status"] == "ready"), "replaced": sum(1 for result in results if result["status"] == "replaced"), "errors": sum(1 for result in results if result["status"] == "error")}
    return {"results": results, "totals": totals}


def export_obb_entry(session_id: str, index: int, out_path: str) -> dict:
    """Write one OBB entry's exact stored container bytes to ``out_path``.

    The bytes are streamed in bounded chunks (never loaded whole into memory)
    and written atomically, so large entries export reliably on low-memory
    devices and a failure can never leave a truncated file behind.  When the
    entry has a staged replacement, the replacement is exported instead of
    the original.
    """
    session = _obb_session(session_id)
    destination = Path(out_path).resolve()
    written = session.copy_entry_raw(index, destination)
    return {"index": index, "name": obb.entry_name(session.obb.entries[index].name_hash), "path": str(destination), "size": written}


def _open_obb_entry(opened: obb.ObbSession, index: int) -> tuple[obb.Entry, core.OpenedIff]:
    """Open one OBB entry's raw container in memory (wrapper boundaries kept).

    Serves the staged replacement when the entry has one, so an IFF that was
    replaced is opened with the new data, never silently the original.
    """
    entry = opened.obb.entries[index]
    if not opened.obb.is_editable(entry):
        raise IffEngineError(f"""entry {index} ({opened.obb.type_name(entry)}) is not an editable IFF""")
    raw = opened.entry_raw(index)
    opened_iff = core.open_iff_bytes(raw, Path(obb.entry_name(entry.name_hash)))
    return (entry, opened_iff)


def template_batch_replace(session_id: str, pairs: list, work_dir: str, apply: bool) -> dict:
    """Replace the matching texture of several OBB IFF entries from PNGs.

    ``pairs`` is a list of ``{"index": int, "png": str}``.  In preview mode
    (``apply=False``) nothing is mutated and each pair reports whether the
    entry is ready (a decodable texture matches the PNG dimensions) or what
    went wrong (missing PNG, invalid PNG, not editable, no matching texture).
    In apply mode the matched texture is imported, the entry is saved as a
    compressed container and staged into the OBB session, ready for a later
    ``save_obb``.  Each entry is handled independently so one failure never
    aborts the others.
    """
    session = _obb_session(session_id)
    work = Path(work_dir)
    work.mkdir(parents=True, exist_ok=True)
    results = []
    for pair in pairs:
        index = int(pair["index"])
        png_text = str(pair["png"])
        base = {"index": index}
        try:
            if index < 0 or index >= len(session.obb.entries):
                raise IffEngineError("entry index out of range")
            [entry, opened] = _open_obb_entry(session, index)
            base["name"] = obb.entry_name(entry.name_hash)
            png_path = Path(png_text)
            if not png_path.is_file():
                raise IffEngineError("PNG file was not found")

            try:
                png_bytes = png_path.read_bytes()
                width, height = pngio.png_dimensions(png_bytes)
            except (OSError, pngio.PngError) as error:
                raise IffEngineError(f"""invalid PNG: {error}""") from error
            decodable = [texture for texture in opened.textures if texture.payload_offset is not None]
            if not decodable:
                raise IffEngineError("IFF has no decodable textures")
            target = next((texture for texture in decodable if texture.width == width and texture.height == height), decodable[0])
            status = {"texture_number": target.number, "texture_format": core.FORMAT_NAMES[target.format_id], "texture_size": f"""{target.width}x{target.height}""", "png_size": f"""{width}x{height}"""}
            if not apply:
                results.append({**base, "status": "ready",**status})
                continue
            change = core.import_png_bytes(opened, target, png_bytes)
            out = work / f"""entry_{index:04d}.iff"""
            core.save_iff_copy(opened, out)
            raw_out = out.read_bytes()
            decompressed, _sizes, _wrapper, _info = core.decompress_wrapper(raw_out)
            expected_sha256 = obb.sha256_bytes(bytes(decompressed))
            session.stage_iff(index, raw_out, bytes(decompressed))
            session.verify_staged(index, expected_sha256)
            results.append({**base, "status": "replaced",**status, "change": change, "decompressed_sha256": expected_sha256, "verification": "PASS"})
        except Exception as error:
            results.append({**base, "status": "error", "error": str(error)})

    totals = {"total": len(results), "ready": sum(1 for result in results if result["status"] == "ready"), "replaced": sum(1 for result in results if result["status"] == "replaced"), "errors": sum(1 for result in results if result["status"] == "error")}
    return {"results": results, "totals": totals}


def list_bank_textures(session_id: str, file_index: int, texture_number: int, obb_session: str) -> dict:
    """List all available texture slots in the OBB's texture banks for manual selection.

    When a scene reference is unresolved or shows the wrong texture, this
    lets the user see all available bank textures and pick one manually.
    """
    session = _session(session_id)
    opened = session["opened"][file_index]
    texture = _texture_at(opened, int(texture_number))
    obb_sess = _obb_session(obb_session)
    from . import obb as obbmod
    parsed = core._OBB_PARSE_CACHE.get(str(obb_sess.path.resolve()))
    if parsed is None:
        parsed = obbmod.Obb(obb_sess.path)
        core._OBB_PARSE_CACHE[str(obb_sess.path.resolve())] = parsed
    bank_textures = []
    for entry_idx, entry in enumerate(parsed.entries):
        if not parsed.is_editable(entry):
            continue
        try:
            bank = core.open_iff_bytes(parsed.read_entry_raw(entry), Path(obb.entry_name(entry.name_hash)))
        except Exception:
            continue
        for bank_tex in bank.textures:
            if bank_tex.texture_hash == texture.texture_hash:
                if bank_tex.payload_offset is not None:
                    role_idx = next((i for i, t in enumerate(bank.textures) if t.texture_hash == texture.texture_hash), -1)
                    role = core.FACE_ROLE_SEQUENCE[role_idx] if 0 <= role_idx < len(core.FACE_ROLE_SEQUENCE) else ""
                    bank_textures.append({"entry_index": entry_idx, "entry_name": obb.entry_name(entry.name_hash), "texture_number": bank_tex.number, "texture_hash": f"""0x{bank_tex.texture_hash:08X}""", "format": core.FORMAT_NAMES.get(bank_tex.format_id, f"""Unknown ({bank_tex.format_id})"""), "format_id": bank_tex.format_id, "width": bank_tex.width, "height": bank_tex.height, "role": role, "position_in_bank": role_idx})
    return {"texture_number": texture.number, "texture_hash": f"""0x{texture.texture_hash:08X}""", "current_role": texture.role, "bank_textures": bank_textures}


def manual_resolve_texture(session_id: str, file_index: int, texture_number: int, obb_session: str, bank_entry_index: int, bank_texture_number: int) -> dict:
    """Manually resolve a scene reference to a specific bank texture.

    When the automatic resolution picks the wrong texture (e.g. Material Map
    instead of Face Diffuse), the user can force a specific bank texture slot.
    """
    session = _session(session_id)
    opened = session["opened"][file_index]
    texture = _texture_at(opened, int(texture_number))
    obb_sess = _obb_session(obb_session)
    from . import obb as obbmod
    parsed = core._OBB_PARSE_CACHE.get(str(obb_sess.path.resolve()))
    if parsed is None:
        parsed = obbmod.Obb(obb_sess.path)
        core._OBB_PARSE_CACHE[str(obb_sess.path.resolve())] = parsed
    bank = core.open_iff_bytes(parsed.read_entry_raw(parsed.entries[bank_entry_index]), Path(obb.entry_name(parsed.entries[bank_entry_index].name_hash)))
    source = next((t for t in bank.textures if t.number == bank_texture_number and t.payload_offset is not None), None)
    if source is None:
        raise ValueError(f"""bank texture #{bank_texture_number} not found or has no payload""")
    payload = bytes(bank.data[source.payload_offset:source.payload_offset + source.payload_size])
    if len(payload) != source.payload_size:
        raise ValueError("bank texture payload is truncated")
    texture.payload_bytes = payload
    texture.format_id = source.format_id
    texture.width = source.width
    texture.height = source.height
    texture.payload_size = source.payload_size
    texture.payload_offset = 0
    texture.allocation_size = source.allocation_size
    texture.encoded_size = source.encoded_size
    texture.uses_mip_chain = source.uses_mip_chain
    texture.mip_count = source.mip_count
    texture.status = "valid"
    texture.error = None
    bank_position = source.number - 1
    if 0 <= bank_position < len(core.FACE_ROLE_SEQUENCE):
        texture.role = core.FACE_ROLE_SEQUENCE[bank_position]
    texture.location = f"""manually resolved from OBB bank entry {bank_entry_index} (texture #{bank_texture_number})"""
    if not texture.label:
        texture.label = texture.role or "Face Texture (manual)"
    return {"texture_number": texture.number, "role": texture.role, "format": core.FORMAT_NAMES.get(texture.format_id, f"""Unknown ({texture.format_id})"""), "width": texture.width, "height": texture.height, "status": "resolved", "location": texture.location}


def scan_obb_audio(obb_session_id: str) -> dict:
    'Scan the open OBB for all OGG audio streams and return structured stream info.'
    obb_sess = _obb_session(obb_session_id)
    streams = audio.scan_obb_audio_streams(obb_sess.path)
    return {"total_streams": len(streams), "streams": streams}


def extract_audio_stream(obb_session_id: str, start_offset: int, size: int, out_path: str) -> dict:
    'Extract a single audio stream to out_path for streaming playback or export.'
    obb_sess = _obb_session(obb_session_id)
    ok = audio.extract_single_audio_stream(obb_sess.path, int(start_offset), int(size), out_path)
    return {"ok": ok, "path": str(Path(out_path).resolve()), "size": os.path.getsize(out_path) if ok and os.path.exists(out_path) else 0}


def replace_audio_stream_in_obb(
    obb_session_id: str, start_offset: int, size: int, replacement_path: str, output_obb_path: str | None=None) -> dict:
    'Replace an existing audio stream inside the OBB.'
    obb_sess = _obb_session(obb_session_id)
    ok = audio.replace_audio_stream(obb_sess.path, int(start_offset), int(size), replacement_path, output_obb_path)
    return {"ok": ok, "output_obb": str(Path(output_obb_path).resolve()) if output_obb_path else str(obb_sess.path.resolve())}
