"""Safely apply Issue #2 error isolation to the current refactored core.

Optional maintenance only: run on an isolated copy, not on accepted app sources.
Usage: python fix_issue2.py [path/to/core.py] (default: ./core.py).
Unsupported layouts are refused without writing. Repeated application is a no-op.
"""
import ast
import copy
import os
from pathlib import Path
import stat
import sys
import tempfile

MARKER = '# issue2-safe-refactored-v1: setup and individual-reference isolation'


def fail(message):
    raise ValueError(message)


def is_return(node, name):
    return isinstance(node, ast.Return) and isinstance(node.value, ast.Name) and node.value.id == name


def is_assign(node, name):
    return isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == name


def guard(body, fallback):
    return ast.Try(body=body, handlers=[ast.ExceptHandler(type=ast.Name(id='Exception', ctx=ast.Load()), name=None, body=[fallback])], orelse=[], finalbody=[])


def matches_guard(node, fallback):
    if not isinstance(node, ast.Try):
        return False
    expected = guard(node.body, fallback)
    return ast.dump(node, include_attributes=False) == ast.dump(expected, include_attributes=False)


def transform(source):
    tree = ast.parse(source)
    functions = {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
    wrapper = functions.get('resolve_scene_references')
    helper = functions.get('_resolve_scene_references_in_obb')
    if wrapper is None or helper is None:
        fail('Unsupported layout: expected current public wrapper and refactored OBB helper')
    if MARKER in source:
        # A marker alone is not sufficient: verify all three guards before a no-op.
        loops = [n for n in helper.body if isinstance(n, ast.For) and isinstance(n.iter, ast.Name) and n.iter.id == 'references']
        setup = [n for n in helper.body if matches_guard(n, ast.Return(value=ast.Constant(value=0)))]
        if (len(loops) != 1 or len(loops[0].body) != 1 or not matches_guard(loops[0].body[0], ast.Continue())
                or len(setup) != 1 or not matches_guard(wrapper.body[-1], ast.Return(value=ast.Constant(value=0)))):
            fail('Repair marker present but expected guards absent; refusing inconsistent source')
        return source, False
    imports = [i for i, n in enumerate(helper.body) if isinstance(n, ast.ImportFrom) and n.level == 1 and n.module is None
               and len(n.names) == 1 and n.names[0].name == 'obb' and n.names[0].asname == 'obbmod']
    counts = [i for i, n in enumerate(helper.body) if is_assign(n, 'count') and isinstance(n.value, ast.Constant) and n.value.value == 0]
    loops = [i for i, n in enumerate(helper.body) if isinstance(n, ast.For) and isinstance(n.target, ast.Name)
             and n.target.id == 'texture' and isinstance(n.iter, ast.Name) and n.iter.id == 'references' and not n.orelse]
    if len(imports) != 1 or len(counts) != 1 or len(loops) != 1:
        fail('Unsupported helper structure: unique import/count/reference loop required')
    start, count, loop = imports[0] + 1, counts[0], loops[0]
    if not (start < count and loop == count + 1 and loop + 2 == len(helper.body) and is_return(helper.body[-1], 'count')):
        fail('Unsupported helper statement order')
    resolved = helper.body[start]
    if not (is_assign(resolved, 'resolved') and ast.dump(resolved.value) == ast.dump(ast.parse('obb_path.resolve()', mode='eval').body)):
        fail('Unsupported initialization: expected resolved = obb_path.resolve() immediately after import')
    last = wrapper.body[-1]
    expected_return = ast.parse('return _resolve_scene_references_in_obb(opened, Path(str(obb_path)))').body[0]
    if ast.dump(last) != ast.dump(expected_return):
        fail('Unsupported wrapper single-path dispatch')
    expected = copy.deepcopy(tree)
    expected_functions = {n.name: n for n in expected.body if isinstance(n, ast.FunctionDef)}
    eh = expected_functions[helper.name]
    eh.body[loop].body = [guard(eh.body[loop].body, ast.Continue())]
    eh.body[start:count] = [guard(eh.body[start:count], ast.Return(value=ast.Constant(value=0)))]
    ew = expected_functions[wrapper.name]
    ew.body[-1:] = [guard([ew.body[-1]], ast.Return(value=ast.Constant(value=0)))]
    lines = source.splitlines(keepends=True)
    newline = '\r\n' if '\r\n' in source else '\n'
    spans = [(helper.body[start].lineno - 1, helper.body[count - 1].end_lineno, 4, 'return 0'),
             (helper.body[loop].body[0].lineno - 1, helper.body[loop].body[-1].end_lineno, 8, 'continue'),
             (last.lineno - 1, last.end_lineno, 4, 'return 0')]
    for first, end, indent, fallback in sorted(spans, reverse=True):
        body = ['    ' + line if line.strip() else line for line in lines[first:end]]
        if body and not body[-1].endswith(('\r', '\n')):
            body[-1] += newline
        lines[first:end] = [' ' * indent + 'try:' + newline, *body,
                            ' ' * indent + 'except Exception:  # noqa: BLE001 - Issue #2 isolation' + newline,
                            ' ' * (indent + 4) + fallback + newline]
    output = MARKER + newline + ''.join(lines)
    actual = ast.parse(output)
    if ast.dump(actual, include_attributes=False) != ast.dump(expected, include_attributes=False):
        fail('Internal validation failed: transformed AST differs from intended guards')
    compile(output, '<repaired-core>', 'exec')
    return output, True


def main():
    if len(sys.argv) > 2:
        print('Usage: python fix_issue2.py [path/to/core.py]', file=sys.stderr)
        return 1
    path = Path(sys.argv[1] if len(sys.argv) == 2 else 'core.py')
    temporary = None
    try:
        if path.is_symlink():
            fail('Refusing a symbolic-link target')
        original = path.read_bytes()
        output, changed = transform(original.decode('utf-8'))
        if not changed:
            print('Issue #2 already applied; unchanged.')
            return 0
        # All parsing and semantic-shape checks precede an atomic replacement.
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix='.issue2-', delete=False) as file:
            temporary = Path(file.name)
            file.write(output.encode('utf-8'))
        os.chmod(temporary, stat.S_IMODE(path.stat().st_mode))
        if path.read_bytes() != original:
            fail('Target changed during repair; refusing overwrite')
        os.replace(temporary, path)
        temporary = None
        print('Issue #2 safely applied: initialization preserved; setup/reference failures isolated.')
        return 0
    except (OSError, ValueError, SyntaxError, UnicodeError) as error:
        print(f'ERROR: {error}; target not written.', file=sys.stderr)
        return 1
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


if __name__ == '__main__':
    sys.exit(main())
